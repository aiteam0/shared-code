#!/usr/bin/env python3
"""
SQLAlchemy 데이터베이스 조회 도구

DB 로깅 시스템에 저장된 데이터를 조회하고 분석하는 스크립트입니다.
"""

import os
import sys
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
import json

# 프로젝트 루트를 Python 경로에 추가
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def init_db_connection():
    """데이터베이스 연결 초기화"""
    try:
        from db_logger import init_database, get_db_session
        from db_logger.models import Conversation, SearchLog, AgentAction, SystemLog
        
        # 데이터베이스 초기화
        init_database()
        print("✅ 데이터베이스 연결 성공")
        return True
    except Exception as e:
        print(f"❌ 데이터베이스 연결 실패: {e}")
        return False

def show_database_stats():
    """데이터베이스 통계 정보 표시"""
    print("\n" + "="*60)
    print("📊 데이터베이스 통계")
    print("="*60)
    
    try:
        from db_logger import get_db_session
        from db_logger.models import Conversation, SearchLog, AgentAction, SystemLog
        from sqlalchemy import func, distinct
        
        with get_db_session() as session:
            if session is None:
                print("❌ 데이터베이스 세션을 가져올 수 없습니다.")
                return
            
            # 전체 통계
            total_conversations = session.query(Conversation).count()
            total_searches = session.query(SearchLog).count()
            total_actions = session.query(AgentAction).count()
            total_system_logs = session.query(SystemLog).count()
            
            print(f"💬 총 대화 수: {total_conversations:,}")
            print(f"🔍 총 검색 수: {total_searches:,}")
            print(f"🤖 총 에이전트 행동 수: {total_actions:,}")
            print(f"📋 총 시스템 로그 수: {total_system_logs:,}")
            
            # 세션 통계
            unique_sessions = session.query(distinct(Conversation.session_id)).count()
            print(f"🆔 고유 세션 수: {unique_sessions:,}")
            
            # 모드별 통계
            print("\n📈 모드별 대화 통계:")
            mode_stats = session.query(
                Conversation.mode,
                func.count(Conversation.id).label('count')
            ).group_by(Conversation.mode).all()
            
            for mode, count in mode_stats:
                print(f"   {mode}: {count:,}개")
            
            # 검색 타입별 통계
            if total_searches > 0:
                print("\n🔍 검색 타입별 통계:")
                search_stats = session.query(
                    SearchLog.search_type,
                    func.count(SearchLog.id).label('count')
                ).group_by(SearchLog.search_type).all()
                
                for search_type, count in search_stats:
                    print(f"   {search_type}: {count:,}개")
            
            # 최근 활동
            recent_conversation = session.query(Conversation.timestamp).order_by(
                Conversation.timestamp.desc()
            ).first()
            
            if recent_conversation:
                print(f"\n⏰ 최근 활동: {recent_conversation[0]}")
            
    except Exception as e:
        print(f"❌ 통계 조회 실패: {e}")

def list_recent_sessions(limit: int = 10):
    """최근 세션 목록 표시"""
    print(f"\n" + "="*60)
    print(f"📋 최근 {limit}개 세션")
    print("="*60)
    
    try:
        from db_logger import get_db_session
        from db_logger.models import Conversation
        from sqlalchemy import func, desc
        
        with get_db_session() as session:
            if session is None:
                print("❌ 데이터베이스 세션을 가져올 수 없습니다.")
                return []
            
            # 세션별 최근 활동 시간과 대화 수 조회
            recent_sessions = session.query(
                Conversation.session_id,
                func.max(Conversation.timestamp).label('last_activity'),
                func.count(Conversation.id).label('message_count'),
                func.min(Conversation.mode).label('mode')  # 첫 번째 모드
            ).group_by(Conversation.session_id).order_by(
                desc('last_activity')
            ).limit(limit).all()
            
            session_list = []
            for i, (session_id, last_activity, msg_count, mode) in enumerate(recent_sessions, 1):
                print(f"{i:2d}. 세션: {session_id[:20]}...")
                print(f"    📅 마지막 활동: {last_activity}")
                print(f"    💬 메시지 수: {msg_count}")
                print(f"    🎯 모드: {mode}")
                print()
                
                session_list.append({
                    'session_id': session_id,
                    'last_activity': last_activity,
                    'message_count': msg_count,
                    'mode': mode
                })
            
            return session_list
            
    except Exception as e:
        print(f"❌ 세션 목록 조회 실패: {e}")
        return []

def show_session_details(session_id: str):
    """특정 세션의 상세 정보 표시"""
    print(f"\n" + "="*60)
    print(f"🔍 세션 상세 정보: {session_id[:30]}...")
    print("="*60)
    
    try:
        from db_logger import (
            get_session_conversations, 
            get_search_history, 
            get_agent_actions,
            get_session_summary
        )
        
        # 세션 요약
        summary = get_session_summary(session_id)
        if summary:
            print("📊 세션 요약:")
            print(f"   💬 대화 수: {summary.get('conversation_count', 0)}")
            print(f"   🔍 검색 수: {summary.get('search_count', 0)}")
            print(f"   🤖 에이전트 행동 수: {summary.get('action_count', 0)}")
            print(f"   ⏰ 첫 활동: {summary.get('first_activity', 'N/A')}")
            print(f"   ⏰ 마지막 활동: {summary.get('last_activity', 'N/A')}")
        
        # 대화 내역
        conversations = get_session_conversations(session_id)
        if conversations:
            print(f"\n💬 대화 내역 ({len(conversations)}개):")
            for i, conv in enumerate(conversations[-10:], 1):  # 최근 10개만 표시
                timestamp = conv['timestamp'][:19] if conv['timestamp'] else 'N/A'
                role_icon = "👤" if conv['role'] == 'user' else "🤖"
                content_preview = conv['content'][:100] + "..." if len(conv['content']) > 100 else conv['content']
                print(f"   {i:2d}. {role_icon} [{timestamp}] {content_preview}")
        
        # 검색 이력
        searches = get_search_history(session_id)
        if searches:
            print(f"\n🔍 검색 이력 ({len(searches)}개):")
            for i, search in enumerate(searches[:5], 1):  # 최근 5개만 표시
                timestamp = search['timestamp'][:19] if search['timestamp'] else 'N/A'
                search_type = search['search_type']
                query = search['query'][:50] + "..." if len(search['query']) > 50 else search['query']
                print(f"   {i:2d}. [{timestamp}] {search_type}: {query}")
        
        # 에이전트 행동
        actions = get_agent_actions(session_id)
        if actions:
            print(f"\n🤖 에이전트 행동 ({len(actions)}개):")
            for i, action in enumerate(actions[:5], 1):  # 최근 5개만 표시
                timestamp = action['timestamp'][:19] if action['timestamp'] else 'N/A'
                action_type = action['action_type']
                tool_name = action['tool_name'] or 'N/A'
                duration = f"{action['duration']:.2f}s" if action['duration'] else 'N/A'
                print(f"   {i:2d}. [{timestamp}] {action_type} - {tool_name} ({duration})")
        
    except Exception as e:
        print(f"❌ 세션 상세 정보 조회 실패: {e}")

def search_conversations(keyword: str, limit: int = 20):
    """대화 내용에서 키워드 검색"""
    print(f"\n" + "="*60)
    print(f"🔍 키워드 검색: '{keyword}' (최대 {limit}개)")
    print("="*60)
    
    try:
        from db_logger import get_db_session
        from db_logger.models import Conversation
        from sqlalchemy import desc
        
        with get_db_session() as session:
            if session is None:
                print("❌ 데이터베이스 세션을 가져올 수 없습니다.")
                return
            
            # 키워드가 포함된 대화 검색
            results = session.query(Conversation).filter(
                Conversation.content.contains(keyword)
            ).order_by(desc(Conversation.timestamp)).limit(limit).all()
            
            if not results:
                print(f"'{keyword}'가 포함된 대화를 찾을 수 없습니다.")
                return
            
            print(f"📋 검색 결과: {len(results)}개 발견")
            print()
            
            for i, conv in enumerate(results, 1):
                timestamp = conv.timestamp.strftime('%Y-%m-%d %H:%M:%S') if conv.timestamp else 'N/A'
                role_icon = "👤" if conv.role == 'user' else "🤖"
                session_short = conv.session_id[:15] + "..." if len(conv.session_id) > 15 else conv.session_id
                
                # 키워드 하이라이트 (간단한 방식)
                content = conv.content
                highlighted = content.replace(keyword, f"**{keyword}**")
                content_preview = highlighted[:200] + "..." if len(highlighted) > 200 else highlighted
                
                print(f"{i:2d}. {role_icon} [{timestamp}] 세션: {session_short}")
                print(f"    모드: {conv.mode}")
                print(f"    내용: {content_preview}")
                print()
                
    except Exception as e:
        print(f"❌ 키워드 검색 실패: {e}")

def show_search_analytics():
    """검색 분석 정보 표시"""
    print(f"\n" + "="*60)
    print("📈 검색 분석")
    print("="*60)
    
    try:
        from db_logger import get_db_session
        from db_logger.models import SearchLog
        from sqlalchemy import func, desc
        
        with get_db_session() as session:
            if session is None:
                print("❌ 데이터베이스 세션을 가져올 수 없습니다.")
                return
            
            # 가장 많이 검색된 쿼리 TOP 10
            print("🔥 인기 검색 쿼리 TOP 10:")
            top_queries = session.query(
                SearchLog.query,
                func.count(SearchLog.id).label('count')
            ).group_by(SearchLog.query).order_by(
                desc('count')
            ).limit(10).all()
            
            for i, (query, count) in enumerate(top_queries, 1):
                query_preview = query[:50] + "..." if len(query) > 50 else query
                print(f"   {i:2d}. ({count:2d}회) {query_preview}")
            
            # 검색 타입별 평균 결과 수 (results가 있는 경우)
            print(f"\n📊 검색 타입별 통계:")
            type_stats = session.query(
                SearchLog.search_type,
                func.count(SearchLog.id).label('total_searches'),
                func.avg(func.length(SearchLog.results)).label('avg_result_size')
            ).group_by(SearchLog.search_type).all()
            
            for search_type, total, avg_size in type_stats:
                avg_size_kb = (avg_size or 0) / 1024
                print(f"   {search_type}: {total}회 검색, 평균 결과 크기: {avg_size_kb:.1f}KB")
            
            # 최근 24시간 검색 활동
            yesterday = datetime.now() - timedelta(days=1)
            recent_searches = session.query(SearchLog).filter(
                SearchLog.timestamp >= yesterday
            ).count()
            
            print(f"\n⏰ 최근 24시간 검색: {recent_searches}회")
            
    except Exception as e:
        print(f"❌ 검색 분석 실패: {e}")

def export_session_data(session_id: str, output_file: str = None):
    """세션 데이터를 JSON 파일로 내보내기"""
    if output_file is None:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_file = f"session_export_{session_id[:8]}_{timestamp}.json"
    
    print(f"\n📤 세션 데이터 내보내기: {session_id[:30]}...")
    
    try:
        from db_logger import (
            get_session_conversations, 
            get_search_history, 
            get_agent_actions,
            get_session_summary
        )
        
        # 모든 세션 데이터 수집
        export_data = {
            'session_id': session_id,
            'export_timestamp': datetime.now().isoformat(),
            'summary': get_session_summary(session_id),
            'conversations': get_session_conversations(session_id),
            'searches': get_search_history(session_id),
            'agent_actions': get_agent_actions(session_id)
        }
        
        # JSON 파일로 저장
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 데이터 내보내기 완료: {output_file}")
        print(f"   💬 대화: {len(export_data['conversations'])}개")
        print(f"   🔍 검색: {len(export_data['searches'])}개")
        print(f"   🤖 행동: {len(export_data['agent_actions'])}개")
        
    except Exception as e:
        print(f"❌ 데이터 내보내기 실패: {e}")

def interactive_menu():
    """대화형 메뉴"""
    while True:
        print("\n" + "="*60)
        print("🗄️  SQLAlchemy DB 조회 도구")
        print("="*60)
        print("1. 📊 데이터베이스 통계")
        print("2. 📋 최근 세션 목록")
        print("3. 🔍 세션 상세 정보")
        print("4. 🔍 키워드 검색")
        print("5. 📈 검색 분석")
        print("6. 📤 세션 데이터 내보내기")
        print("7. 🚪 종료")
        print()
        
        try:
            choice = input("선택하세요 (1-7): ").strip()
            
            if choice == '1':
                show_database_stats()
                
            elif choice == '2':
                limit = input("표시할 세션 수 (기본 10): ").strip()
                limit = int(limit) if limit.isdigit() else 10
                sessions = list_recent_sessions(limit)
                
            elif choice == '3':
                session_id = input("세션 ID를 입력하세요: ").strip()
                if session_id:
                    show_session_details(session_id)
                else:
                    print("❌ 세션 ID를 입력해주세요.")
                    
            elif choice == '4':
                keyword = input("검색할 키워드를 입력하세요: ").strip()
                if keyword:
                    limit = input("최대 결과 수 (기본 20): ").strip()
                    limit = int(limit) if limit.isdigit() else 20
                    search_conversations(keyword, limit)
                else:
                    print("❌ 키워드를 입력해주세요.")
                    
            elif choice == '5':
                show_search_analytics()
                
            elif choice == '6':
                session_id = input("내보낼 세션 ID를 입력하세요: ").strip()
                if session_id:
                    output_file = input("출력 파일명 (엔터시 자동 생성): ").strip()
                    output_file = output_file if output_file else None
                    export_session_data(session_id, output_file)
                else:
                    print("❌ 세션 ID를 입력해주세요.")
                    
            elif choice == '7':
                print("👋 프로그램을 종료합니다.")
                break
                
            else:
                print("❌ 잘못된 선택입니다. 1-7 사이의 숫자를 입력하세요.")
                
        except KeyboardInterrupt:
            print("\n👋 프로그램을 종료합니다.")
            break
        except Exception as e:
            print(f"❌ 오류 발생: {e}")
        
        input("\n계속하려면 엔터를 누르세요...")

def main():
    """메인 함수"""
    print("🚀 SQLAlchemy DB 조회 도구 시작")
    
    # 환경 변수 설정
    os.environ["DB_LOGGING_ENABLED"] = "true"
    if not os.environ.get("DB_PATH"):
        os.environ["DB_PATH"] = "logs/interactions.db"
    
    # 데이터베이스 연결 확인
    if not init_db_connection():
        print("❌ 데이터베이스에 연결할 수 없습니다.")
        print("💡 다음을 확인해주세요:")
        print("   - SQLAlchemy가 설치되어 있는지")
        print("   - 데이터베이스 파일이 존재하는지")
        print("   - DB_PATH 환경 변수가 올바른지")
        return
    
    # 명령행 인수 처리
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == 'stats':
            show_database_stats()
        elif command == 'sessions':
            limit = int(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2].isdigit() else 10
            list_recent_sessions(limit)
        elif command == 'search' and len(sys.argv) > 2:
            keyword = sys.argv[2]
            limit = int(sys.argv[3]) if len(sys.argv) > 3 and sys.argv[3].isdigit() else 20
            search_conversations(keyword, limit)
        elif command == 'analytics':
            show_search_analytics()
        elif command == 'export' and len(sys.argv) > 2:
            session_id = sys.argv[2]
            output_file = sys.argv[3] if len(sys.argv) > 3 else None
            export_session_data(session_id, output_file)
        else:
            print("❌ 알 수 없는 명령어입니다.")
            print("사용법:")
            print("  python db_viewer.py stats")
            print("  python db_viewer.py sessions [limit]")
            print("  python db_viewer.py search <keyword> [limit]")
            print("  python db_viewer.py analytics")
            print("  python db_viewer.py export <session_id> [output_file]")
    else:
        # 대화형 모드
        interactive_menu()

if __name__ == "__main__":
    main()
