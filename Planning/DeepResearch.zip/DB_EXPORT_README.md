# 📊 SQLAlchemy DB Export 도구

`db_logger` 폴더의 SQLAlchemy 데이터베이스를 pandas DataFrame으로 조회하고 다양한 형식으로 export하는 도구입니다.

## 🚀 빠른 시작

### 1. 의존성 설치
```bash
pip install -r requirements_export.txt
```

### 2. 기본 사용법
```bash
# 모든 테이블을 CSV로 export
python db_exporter.py

# 특정 테이블을 Excel로 export
python db_exporter.py --table conversations --format excel

# 테이블 정보만 확인
python db_exporter.py --info

# 샘플 데이터 확인
python db_exporter.py --sample
```

## 📋 주요 기능

### 지원하는 테이블
- `conversations`: 사용자-에이전트 대화 내역
- `search_logs`: 검색 로그
- `agent_actions`: 에이전트 행동 로그  
- `system_logs`: 시스템 로그

### 지원하는 Export 형식
- **CSV**: 기본 형식, 범용성 좋음
- **Excel**: .xlsx 형식, 데이터 분석에 적합
- **JSON**: 구조화된 데이터, API 연동용
- **Parquet**: 고성능 압축 형식, 빅데이터 처리용

## 🛠️ 명령행 옵션

```bash
python db_exporter.py [옵션]

옵션:
  --table, -t {conversations,search_logs,agent_actions,system_logs,all}
                        Export할 테이블 (기본: all)
  --format, -f {csv,excel,json,parquet}
                        Export 형식 (기본: csv)
  --limit, -l LIMIT     최대 레코드 수 제한
  --session-id, -s SESSION_ID
                        특정 세션 ID만 필터링
  --start-date START_DATE
                        시작 날짜 (YYYY-MM-DD 또는 YYYY-MM-DD HH:MM:SS)
  --end-date END_DATE   종료 날짜 (YYYY-MM-DD 또는 YYYY-MM-DD HH:MM:SS)
  --sample              샘플 데이터만 출력 (export 안함)
  --info                테이블 정보만 출력
```

## 📝 사용 예제

### 1. 기본 Export
```bash
# 모든 테이블을 CSV로 export
python db_exporter.py

# 대화 테이블만 Excel로 export
python db_exporter.py --table conversations --format excel
```

### 2. 데이터 필터링
```bash
# 특정 세션의 대화만 export
python db_exporter.py --table conversations --session-id "session_123"

# 최근 100개 검색 로그만 export
python db_exporter.py --table search_logs --limit 100

# 특정 날짜 범위의 데이터
python db_exporter.py --table agent_actions \
  --start-date "2024-01-01" \
  --end-date "2024-01-31" \
  --format json
```

### 3. 데이터 확인
```bash
# 테이블 정보 확인
python db_exporter.py --info

# 샘플 데이터 미리보기
python db_exporter.py --table conversations --sample
```

## 🐍 프로그래밍 방식 사용

```python
from db_exporter import DatabaseExporter

# Exporter 초기화
exporter = DatabaseExporter()
exporter.connect()

# DataFrame으로 조회
df = exporter.query_table_to_dataframe('conversations', limit=100)

# 데이터 분석
print(f"총 레코드 수: {len(df)}")
print(f"세션 수: {df['session_id'].nunique()}")

# Export
exporter.export_dataframe(df, 'my_export', 'excel')
```

## 📁 출력 파일

모든 export된 파일은 `exports/` 디렉토리에 저장됩니다:

```
exports/
├── conversations_20241201_143022.csv
├── search_logs_20241201_143023.xlsx
└── agent_actions_20241201_143024.json
```

파일명 형식: `{테이블명}_{YYYYMMDD_HHMMSS}.{확장자}`

## 🔧 환경 설정

데이터베이스 로깅이 활성화되어 있어야 합니다:

```bash
# 환경 변수 설정
export DB_LOGGING_ENABLED=true
export DB_PATH=logs/interactions.db  # 선택적
```

또는 `.env` 파일에:
```
DB_LOGGING_ENABLED=true
DB_PATH=logs/interactions.db
```

## 📊 데이터 분석 예제

### 대화 패턴 분석
```python
# 시간대별 활동 분포
df['hour'] = pd.to_datetime(df['timestamp']).dt.hour
hourly_stats = df.groupby('hour').size()

# 역할별 메시지 길이
role_lengths = df.groupby('role')['content'].str.len().mean()

# 세션 지속 시간
session_durations = df.groupby('session_id')['timestamp'].agg(['min', 'max'])
session_durations['duration'] = session_durations['max'] - session_durations['min']
```

### 검색 패턴 분석
```python
# 인기 검색어
popular_queries = df['query'].value_counts().head(10)

# 검색 타입별 성공률
success_rates = df.groupby('search_type')['results'].apply(lambda x: x.notna().mean())
```

## 🚨 주의사항

1. **메모리 사용량**: 대용량 데이터의 경우 `--limit` 옵션을 사용하세요
2. **파일 크기**: Excel 형식은 대용량 데이터에 적합하지 않을 수 있습니다
3. **개인정보**: Export된 파일에는 민감한 정보가 포함될 수 있으니 주의하세요
4. **백업**: 중요한 데이터는 정기적으로 백업하세요

## 🔍 문제 해결

### 일반적인 오류들

**1. "db_logger 모듈을 찾을 수 없습니다"**
```bash
# PYTHONPATH에 현재 디렉토리 추가
export PYTHONPATH="${PYTHONPATH}:."
python db_exporter.py
```

**2. "DB 로깅이 비활성화되어 있습니다"**
```bash
export DB_LOGGING_ENABLED=true
```

**3. "ModuleNotFoundError: No module named 'pandas'"**
```bash
pip install -r requirements_export.txt
```

**4. Excel export 오류**
```bash
pip install openpyxl
```

## 📈 성능 팁

1. **대용량 데이터**: Parquet 형식 사용 권장
2. **빠른 조회**: 필요한 컬럼만 선택
3. **메모리 절약**: `--limit` 옵션으로 데이터 양 제한
4. **병렬 처리**: 여러 테이블을 동시에 처리 가능

## 📞 지원

문제가 발생하거나 기능 요청이 있으시면:
1. 오류 메시지와 함께 이슈 등록
2. 사용한 명령어와 환경 정보 포함
3. 데이터베이스 상태 확인: `python db_exporter.py --info` 