"""
LLM Factory - 다양한 LLM 모델 생성 및 관리
YAML 설정을 기반으로 LLM 모델을 생성하고 fallback 로직을 처리합니다.
"""

import os
import yaml
from pathlib import Path
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass
from enum import Enum

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_openai import ChatOpenAI, AzureChatOpenAI
from langchain_ollama import ChatOllama

from logging_config import get_logger

logger = get_logger(__name__)


class ModelType(Enum):
    """지원되는 모델 타입"""
    OPENAI = "openai"
    AZURE_OPENAI = "azure_openai"
    OLLAMA = "ollama"


@dataclass
class ModelCapabilities:
    """모델 capability 정의"""
    multimodal: bool = False
    tool_calling: bool = False
    reasoning: bool = False


@dataclass
class ModelConfig:
    """모델 설정 정보"""
    name: str
    type: ModelType
    model_name: str
    display_name: str
    provider: str
    config: Dict[str, Any]
    env_vars: List[str]
    capabilities: ModelCapabilities
    description: str
    fallback: Dict[str, Any]


class LLMFactory:
    """LLM 모델 생성 팩토리"""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        LLM Factory 초기화
        
        Args:
            config_path: YAML 설정 파일 경로 (기본값: config/models.yaml)
        """
        if config_path is None:
            config_path = Path(__file__).parent.parent / "config" / "models.yaml"
        
        self.config_path = Path(config_path)
        self.config = self._load_config()
        self.models = self._parse_models()
        self.fallback_config = self.config.get("fallback", {})
        
        logger.info(f"LLM Factory 초기화 완료 - {len(self.models)}개 모델 로드")
    
    def _load_config(self) -> Dict[str, Any]:
        """YAML 설정 파일 로드"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            logger.info(f"설정 파일 로드 완료: {self.config_path}")
            return config
        except FileNotFoundError:
            logger.error(f"설정 파일을 찾을 수 없습니다: {self.config_path}")
            raise
        except yaml.YAMLError as e:
            logger.error(f"YAML 파일 파싱 에러: {e}")
            raise
    
    def _parse_models(self) -> Dict[str, ModelConfig]:
        """YAML 설정에서 모델 정보 파싱"""
        models = {}
        
        for model_name, model_data in self.config.get("models", {}).items():
            try:
                capabilities = ModelCapabilities(
                    multimodal=model_data.get("capabilities", {}).get("multimodal", False),
                    tool_calling=model_data.get("capabilities", {}).get("tool_calling", False),
                    reasoning=model_data.get("capabilities", {}).get("reasoning", False)
                )
                
                config = ModelConfig(
                    name=model_name,
                    type=ModelType(model_data["type"]),
                    model_name=model_data["model_name"],
                    display_name=model_data["display_name"],
                    provider=model_data["provider"],
                    config=model_data.get("config", {}),
                    env_vars=model_data.get("env_vars", []),
                    capabilities=capabilities,
                    description=model_data.get("description", ""),
                    fallback=model_data.get("fallback", {})
                )
                
                models[model_name] = config
                
            except (KeyError, ValueError) as e:
                logger.error(f"모델 '{model_name}' 설정 파싱 에러: {e}")
                continue
        
        return models
    
    def get_available_models(self) -> List[ModelConfig]:
        """사용 가능한 모델 목록 반환"""
        return list(self.models.values())
    
    def get_model_names(self) -> List[str]:
        """모델명 목록 반환 (Streamlit selectbox용)"""
        return [config.display_name for config in self.models.values()]
    
    def get_model_config(self, model_name: str) -> ModelConfig:
        """모델 설정 정보 반환"""
        if model_name not in self.models:
            raise ValueError(f"알 수 없는 모델: {model_name}")
        
        return self.models[model_name]
    
    def create_llm(self, model_name: str) -> BaseChatModel:
        """
        LLM 모델 생성
        
        Args:
            model_name: 생성할 모델명
            
        Returns:
            생성된 LLM 모델 인스턴스
            
        Raises:
            ValueError: 알 수 없는 모델이거나 필수 환경변수가 누락된 경우
        """
        if model_name not in self.models:
            raise ValueError(f"알 수 없는 모델: {model_name}")
        
        config = self.models[model_name]
        
        # 환경변수 확인
        self._check_env_vars(config)
        
        # 모델 타입별 생성
        if config.type == ModelType.OPENAI:
            return self._create_openai_model(config)
        elif config.type == ModelType.AZURE_OPENAI:
            return self._create_azure_openai_model(config)
        elif config.type == ModelType.OLLAMA:
            return self._create_ollama_model(config)
        else:
            raise ValueError(f"지원하지 않는 모델 타입: {config.type}")
    
    def _check_env_vars(self, config: ModelConfig) -> None:
        """필수 환경변수 확인"""
        missing_vars = []
        
        for var in config.env_vars:
            if not os.environ.get(var):
                missing_vars.append(var)
        
        if missing_vars:
            raise ValueError(f"필수 환경변수가 누락되었습니다: {missing_vars}")
    
    def _create_openai_model(self, config: ModelConfig) -> ChatOpenAI:
        """OpenAI 모델 생성"""
        model_config = config.config.copy()
        model_config["model"] = config.model_name
        
        logger.info(f"OpenAI 모델 생성: {config.name}")
        return ChatOpenAI(**model_config)
    
    def _create_azure_openai_model(self, config: ModelConfig) -> AzureChatOpenAI:
        """Azure OpenAI 모델 생성"""
        model_config = config.config.copy()
        
        # 환경변수에서 Azure 설정 읽기
        azure_config = {
            "azure_endpoint": os.environ.get("AZURE_OPENAI_ENDPOINT"),
            "api_key": os.environ.get("AZURE_OPENAI_API_KEY"),
            "azure_deployment": model_config.get("azure_deployment") or os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME"),
            "api_version": model_config.get("api_version", "2024-02-01"),
            "temperature": model_config.get("temperature", 0.1),
            "max_tokens": model_config.get("max_tokens")
        }
        
        # None 값 제거
        azure_config = {k: v for k, v in azure_config.items() if v is not None}
        
        logger.info(f"Azure OpenAI 모델 생성: {config.name}")
        return AzureChatOpenAI(**azure_config)
    
    def _create_ollama_model(self, config: ModelConfig) -> ChatOllama:
        """Ollama 모델 생성"""
        model_config = config.config.copy()
        model_config["model"] = config.model_name
    
        model_fallback = config.fallback.copy()
        model_fallback["model"] = config.model_name
        
        logger.info(f"Ollama 모델 생성: {config.name}")
        return ChatOllama(**model_config).with_fallbacks(ChatOllama(**model_fallback))
    
    def get_fallback_for_capability(self, current_model: str, required_capability: str) -> BaseChatModel:
        """
        특정 capability이 필요할 때 fallback 모델 반환
        
        Args:
            current_model: 현재 모델명
            required_capability: 필요한 capability ("multimodal" 또는 "tool_calling")
            
        Returns:
            Fallback LLM 모델 인스턴스
        """
        fallback_model_name = self.fallback_config.get(required_capability)
        
        if not fallback_model_name:
            raise ValueError(f"Fallback 모델이 설정되지 않았습니다: {required_capability}")
        
        logger.info(f"Fallback 모델 사용: {current_model} -> {fallback_model_name} (for {required_capability})")
        return self.create_llm(fallback_model_name)
    
    def has_capability(self, model_name: str, capability: str) -> bool:
        """
        모델이 특정 capability을 지원하는지 확인
        
        Args:
            model_name: 모델명
            capability: 확인할 capability
            
        Returns:
            capability 지원 여부
        """
        if model_name not in self.models:
            return False
        
        config = self.models[model_name]
        return getattr(config.capabilities, capability, False)
    
    def get_model_for_task(self, task_type: str, preferred_model: Optional[str] = None) -> BaseChatModel:
        """
        특정 태스크에 적합한 모델 반환 (capability 기반 자동 선택 또는 fallback)
        
        Args:
            task_type: 태스크 타입 ("multimodal", "tool_calling", "reasoning")
            preferred_model: 선호 모델 (없으면 자동 선택)
            
        Returns:
            태스크에 적합한 LLM 모델 인스턴스
        """
        # 선호 모델이 있고 해당 capability을 지원하면 사용
        if preferred_model and self.has_capability(preferred_model, task_type):
            return self.create_llm(preferred_model)
        
        # Fallback 모델 사용
        return self.get_fallback_for_capability(preferred_model or "unknown", task_type)
    
    def get_models_by_capability(self, capability: str) -> List[ModelConfig]:
        """
        특정 capability을 지원하는 모든 모델 반환
        
        Args:
            capability: 확인할 capability
            
        Returns:
            해당 capability을 지원하는 모델 목록
        """
        return [
            config for config in self.models.values()
            if getattr(config.capabilities, capability, False)
        ]
    
    def get_model_info(self, model_name: str) -> Dict[str, Any]:
        """
        모델의 상세 정보 반환 (Streamlit UI 표시용)
        
        Args:
            model_name: 모델명
            
        Returns:
            모델 정보 딕셔너리
        """
        if model_name not in self.models:
            return {}
        
        config = self.models[model_name]
        return {
            "name": config.name,
            "display_name": config.display_name,
            "provider": config.provider,
            "type": config.type.value,
            "capabilities": {
                "multimodal": config.capabilities.multimodal,
                "tool_calling": config.capabilities.tool_calling,
                "reasoning": config.capabilities.reasoning
            },
            "description": config.description,
            "env_vars_required": config.env_vars,
            "env_vars_missing": [var for var in config.env_vars if not os.environ.get(var)]
        }
    
    @staticmethod
    def get_singleton() -> 'LLMFactory':
        """
        싱글톤 인스턴스 반환 (성능 최적화용)
        """
        if not hasattr(LLMFactory, '_singleton'):
            LLMFactory._singleton = LLMFactory()
        return LLMFactory._singleton
