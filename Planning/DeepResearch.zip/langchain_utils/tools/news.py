import feedparser
from urllib.parse import quote
from typing import List, Dict, Optional
import logging

# kiwi 라이브러리 import
try:
    from kiwipiepy import Kiwi
    KIWI_AVAILABLE = True
except ImportError:
    KIWI_AVAILABLE = False
    logging.warning("kiwipiepy가 설치되지 않았습니다. 기본 키워드 처리를 사용합니다.")

class GoogleNews:
    """
    Kiwi 형태소 분석기를 활용한 향상된 구글 뉴스 검색 클래스
    """

    def __init__(self, use_morphological_analysis: bool = True):
        """
        GoogleNews 클래스를 초기화합니다.
        
        Args:
            use_morphological_analysis (bool): 형태소 분석을 사용할지 여부
        """
        self.base_url = "https://news.google.com/rss"
        self.use_morphological_analysis = use_morphological_analysis and KIWI_AVAILABLE
        
        if self.use_morphological_analysis:
            try:
                self.kiwi = Kiwi()
                logging.info("Kiwi 형태소 분석기가 초기화되었습니다.")
            except Exception as e:
                logging.error(f"Kiwi 초기화 실패: {e}")
                self.use_morphological_analysis = False
                self.kiwi = None
        else:
            self.kiwi = None

    def extract_keywords(self, text: str) -> List[str]:
        """
        텍스트에서 의미있는 키워드를 추출합니다.
        
        Args:
            text (str): 분석할 텍스트
            
        Returns:
            List[str]: 추출된 키워드 리스트
        """
        if not self.use_morphological_analysis or not text:
            # Kiwi를 사용할 수 없는 경우 간단한 공백 분리
            return [word.strip() for word in text.split() if len(word.strip()) > 1]
        
        try:
            # Kiwi를 사용한 형태소 분석
            tokens = self.kiwi.tokenize(text)
            keywords = []
            
            for token in tokens:
                # 의미있는 품사만 선택
                if self._is_meaningful_pos(token.tag):
                    # 동사/형용사의 경우 어간만 추출
                    if token.tag.startswith(('VV', 'VA')):
                        # 어간 추출 (원형으로 복원)
                        keyword = self._extract_stem(token.form, token.tag)
                    else:
                        keyword = token.form
                    
                    # 유효한 키워드인지 확인
                    if self._is_valid_keyword(keyword):
                        keywords.append(keyword)
            
            # 중복 제거하면서 순서 유지
            unique_keywords = []
            seen = set()
            for keyword in keywords:
                if keyword not in seen:
                    unique_keywords.append(keyword)
                    seen.add(keyword)
                    
            return unique_keywords
            
        except Exception as e:
            logging.error(f"키워드 추출 중 오류 발생: {e}")
            # 실패 시 기본 분리 방식 사용
            return [word.strip() for word in text.split() if len(word.strip()) > 1]

    def _is_meaningful_pos(self, tag: str) -> bool:
        """
        검색에 의미있는 품사인지 판단합니다.
        
        Args:
            tag (str): 품사 태그
            
        Returns:
            bool: 의미있는 품사 여부
        """
        # 검색에 유용한 품사들
        meaningful_tags = [
            'NNG',  # 일반명사
            'NNP',  # 고유명사
            'NNB',  # 의존명사
            'VV',   # 동사
            'VA',   # 형용사
            'SN',   # 숫자
            'SL',   # 외국어
        ]
        
        # 조사, 어미, 부호 등은 제외
        exclude_prefixes = ['JK', 'JX', 'JC', 'E', 'SF', 'SP', 'SS', 'SE']
        
        # 제외할 품사인지 확인
        for prefix in exclude_prefixes:
            if tag.startswith(prefix):
                return False
                
        # 의미있는 품사인지 확인
        for meaningful_tag in meaningful_tags:
            if tag.startswith(meaningful_tag):
                return True
                
        return False

    def _extract_stem(self, form: str, tag: str) -> str:
        """
        동사/형용사의 어간을 추출합니다.
        
        Args:
            form (str): 형태소 형태
            tag (str): 품사 태그
            
        Returns:
            str: 추출된 어간
        """
        # 간단한 어간 추출 로직
        # 실제로는 더 복잡한 처리가 필요할 수 있음
        if len(form) > 1:
            # 동사/형용사 어미 제거 시도
            common_endings = ['다', '어', '아', '여', '야', '하', '시']
            for ending in common_endings:
                if form.endswith(ending) and len(form) > len(ending):
                    return form[:-len(ending)]
        return form

    def _is_valid_keyword(self, keyword: str) -> bool:
        """
        유효한 키워드인지 검증합니다.
        
        Args:
            keyword (str): 검증할 키워드
            
        Returns:
            bool: 유효한 키워드 여부
        """
        # 길이 검증
        if len(keyword) < 1:
            return False
            
        # 단일 문자 필터링 (숫자/영문 제외)
        if len(keyword) == 1 and not (keyword.isdigit() or keyword.isalpha()):
            return False
            
        # 의미없는 단어 필터링
        stop_words = ['것', '수', '때', '등', '중', '후', '전', '간', '내', '외']
        if keyword in stop_words:
            return False
            
        return True

    def create_optimized_query(self, text: str) -> str:
        """
        입력 텍스트를 분석하여 최적화된 검색 쿼리를 생성합니다.
        
        Args:
            text (str): 원본 검색 텍스트
            
        Returns:
            str: 최적화된 검색 쿼리
        """
        if not self.use_morphological_analysis:
            return text
            
        keywords = self.extract_keywords(text)
        
        # 키워드가 없으면 원본 텍스트 반환
        if not keywords:
            return text
            
        # 상위 5개 키워드만 사용 (너무 많으면 검색 결과가 제한적일 수 있음)
        selected_keywords = keywords[:5]
        
        # 키워드들을 공백으로 연결
        optimized_query = ' '.join(selected_keywords)
        
        logging.info(f"원본 쿼리: '{text}' -> 최적화된 쿼리: '{optimized_query}'")
        logging.info(f"추출된 키워드: {keywords}")
        
        return optimized_query

    def _fetch_news(self, url: str, k: int = 3) -> List[Dict[str, str]]:
        """
        주어진 URL에서 뉴스를 가져옵니다.

        Args:
            url (str): 뉴스를 가져올 URL
            k (int): 가져올 뉴스의 최대 개수 (기본값: 3)

        Returns:
            List[Dict[str, str]]: 뉴스 제목과 링크를 포함한 딕셔너리 리스트
        """
        try:
            news_data = feedparser.parse(url)
            return [
                {"title": entry.title, "link": entry.link, 'published': entry.published, 'summary': entry.summary}
                for entry in news_data.entries[:k]
            ]
        except Exception as e:
            logging.error(f"뉴스 데이터 파싱 중 오류 발생: {e}")
            return []

    def _collect_news(self, news_list: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """
        뉴스 리스트를 정리하여 반환합니다.

        Args:
            news_list (List[Dict[str, str]]): 뉴스 정보를 포함한 딕셔너리 리스트

        Returns:
            List[Dict[str, str]]: URL과 내용을 포함한 딕셔너리 리스트
        """
        if not news_list:
            print("해당 키워드의 뉴스가 없습니다.")
            return []

        result = []
        for news in news_list:
            result.append({"url": news["link"], "content": news["title"], "published": news["published"], "summary": news["summary"]})

        return result

    def search_latest(self, k: int = 3) -> List[Dict[str, str]]:
        """
        최신 뉴스를 검색합니다.

        Args:
            k (int): 검색할 뉴스의 최대 개수 (기본값: 3)

        Returns:
            List[Dict[str, str]]: URL과 내용을 포함한 딕셔너리 리스트
        """
        url = f"{self.base_url}?hl=ko&gl=KR&ceid=KR:ko"
        news_list = self._fetch_news(url, k)
        return self._collect_news(news_list)

    def search_by_keyword(
        self, keyword: Optional[str] = None, k: int = 3, optimize_query: bool = True
    ) -> List[Dict[str, str]]:
        """
        키워드로 뉴스를 검색합니다. (Kiwi 형태소 분석 기반 최적화 지원)

        Args:
            keyword (Optional[str]): 검색할 키워드 (기본값: None)
            k (int): 검색할 뉴스의 최대 개수 (기본값: 3)
            optimize_query (bool): 쿼리 최적화 사용 여부 (기본값: True)

        Returns:
            List[Dict[str, str]]: URL과 내용을 포함한 딕셔너리 리스트
        """
        if keyword:
            # 쿼리 최적화 적용
            if optimize_query and self.use_morphological_analysis:
                search_keyword = self.create_optimized_query(keyword)
            else:
                search_keyword = keyword
                
            encoded_keyword = quote(search_keyword)
            url = f"{self.base_url}/search?q={encoded_keyword}&hl=ko&gl=KR&ceid=KR:ko"
        else:
            url = f"{self.base_url}?hl=ko&gl=KR&ceid=KR:ko"
            
        news_list = self._fetch_news(url, k)
        return self._collect_news(news_list)

    def get_analysis_info(self) -> Dict[str, any]:
        """
        현재 설정 및 형태소 분석기 정보를 반환합니다.
        
        Returns:
            Dict[str, any]: 분석기 정보
        """
        return {
            "kiwi_available": KIWI_AVAILABLE,
            "morphological_analysis_enabled": self.use_morphological_analysis,
            "kiwi_initialized": self.kiwi is not None
        }


# 기존 GoogleNews 클래스와의 호환성을 위한 별칭
GoogleNews = GoogleNews


# 사용 예제
if __name__ == "__main__":
    # 향상된 뉴스 검색기 초기화
    news_searcher = GoogleNews(use_morphological_analysis=True)
    
    # 분석기 정보 출력
    print("=== 분석기 정보 ===")
    info = news_searcher.get_analysis_info()
    for key, value in info.items():
        print(f"{key}: {value}")
    print()
    
    # 키워드 추출 테스트
    test_queries = [
        "삼성전자의 주가가 상승했습니다",
        "비트코인 가격이 급등하고 있어요",
        "한국 축구 대표팀이 승리했다",
        "부동산 정책에 대한 논의가 필요하다"
    ]
    
    print("=== 키워드 추출 테스트 ===")
    for query in test_queries:
        keywords = news_searcher.extract_keywords(query)
        optimized = news_searcher.create_optimized_query(query)
        print(f"원본: {query}")
        print(f"키워드: {keywords}")
        print(f"최적화: {optimized}")
        print("-" * 50)
    
    # 실제 뉴스 검색 테스트
    print("\n=== 뉴스 검색 테스트 ===")
    results = news_searcher.search_by_keyword("삼성전자의 주가 상승", k=3)
    
    print(f"검색 결과 ({len(results)}개):")
    for i, result in enumerate(results, 1):
        print(f"{i}. {result['content']}")
        print(f"   URL: {result['url']}")
        print()