# Docker 실행 가이드

이 문서는 DeepResearch 프로젝트를 Docker로 실행하는 방법을 설명합니다.

## 사전 준비

### 1. 환경변수 설정
`.env` 파일을 프로젝트 루트에 생성하고 다음 환경변수들을 설정하세요:

```bash
# OpenAI API 설정
OPENAI_API_KEY=your_openai_api_key_here

# LangSmith 설정 (선택사항)
LANGCHAIN_TRACING_V2=true
LANGCHAIN_ENDPOINT=https://api.smith.langchain.com
LANGCHAIN_API_KEY=your_langsmith_api_key_here
LANGCHAIN_PROJECT=H-Deepsearch

# Tavily API 설정 (웹 검색용)
TAVILY_API_KEY=your_tavily_api_key_here

# 로깅 설정
LOG_LEVEL=INFO
LOG_TO_FILE=true
```

## Docker 실행 방법

### 방법 1: Docker Compose 사용 (권장)

```bash
# 이미지 빌드 및 컨테이너 실행
docker-compose up --build

# 백그라운드 실행
docker-compose up -d --build

# 컨테이너 중지
docker-compose down
```

### 방법 2: Docker 명령어 직접 사용

```bash
# 이미지 빌드
docker build -t deepresearch-app .

# 컨테이너 실행
docker run -p 8501:8501 --env-file .env deepresearch-app

# 백그라운드 실행
docker run -d -p 8501:8501 --env-file .env --name deepresearch deepresearch-app
```

## 접속 방법

애플리케이션이 실행되면 다음 URL로 접속할 수 있습니다:
- http://localhost:8501

## 주요 특징

### 포함된 기능
- ✅ Streamlit 웹 애플리케이션
- ✅ LangChain 기반 AI 에이전트
- ✅ 웹 검색 및 뉴스 검색
- ✅ RAG (Retrieval-Augmented Generation)
- ✅ 딥 리서치 기능
- ✅ 데이터베이스 로깅

### 제외된 구성요소
- ❌ langchain_utils (별도 관리)
- ❌ 테스트 파일들
- ❌ 개발 도구 설정
- ❌ 로그 파일들

## 볼륨 마운트

Docker Compose를 사용하는 경우 다음 디렉토리들이 마운트됩니다:
- `./logs:/app/logs` - 로그 파일 저장
- `./config:/app/config` - 설정 파일

## 트러블슈팅

### 1. 포트 충돌
8501 포트가 이미 사용 중인 경우:
```bash
# 다른 포트 사용
docker run -p 8502:8501 --env-file .env deepresearch-app
```

### 2. 환경변수 문제
환경변수가 제대로 로드되지 않는 경우:
```bash
# 환경변수 직접 전달
docker run -p 8501:8501 -e OPENAI_API_KEY=your_key deepresearch-app
```

### 3. 메모리 부족
대용량 모델 사용시 메모리 제한 증가:
```bash
docker run -p 8501:8501 --memory=4g --env-file .env deepresearch-app
```

## 개발 모드

개발 중인 코드를 실시간으로 반영하려면:
```bash
docker run -p 8501:8501 -v $(pwd):/app --env-file .env deepresearch-app
```

## 로그 확인

```bash
# 실행 중인 컨테이너 로그 확인
docker-compose logs -f

# 또는
docker logs -f deepresearch
```

## 정리

```bash
# 컨테이너 및 이미지 정리
docker-compose down --rmi all --volumes

# 또는
docker stop deepresearch
docker rm deepresearch
docker rmi deepresearch-app
``` 