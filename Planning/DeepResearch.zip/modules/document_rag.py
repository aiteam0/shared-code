"""
문서 RAG 기능을 위한 수정된 모듈
Docling chunking 에러를 해결하기 위해 여러 fallback 방식을 적용

주요 수정사항:
1. Docling chunking 에러 우회: 직접 DocumentConverter 사용하여 Markdown 변환 후 별도 chunking
2. 다중 Fallback 시스템: Docling -> PyMuPDF4LLM -> PyPDF2 순서로 시도
3. 에러 메시지 벡터스토어 저장 방지: 실패한 파일은 완전히 제외
4. 지능적 문서 검증: 의미 없는 내용이나 에러 메시지 자동 필터링
5. 구조화된 청킹: Markdown 헤더 기반 분할 후 크기 기반 추가 분할
6. 벡터 DB 초기화 기능: 새로운 문서 업로드 시 기존 데이터 자동 초기화
7. 상태 모니터링: 벡터스토어 현재 상태 확인 기능

새로운 기능:
- reset_vectorstore(): 기존 벡터 DB 완전 초기화
- process_and_index_files(reset_existing=True): 새 문서 업로드 시 기존 데이터 자동 제거
- get_vectorstore_status(): 현재 벡터스토어 상태 정보 반환
- 고유한 collection name으로 데이터 격리

설치 필요 패키지:
- pip install pymupdf4llm PyPDF2 (선택사항, PDF 처리 개선용)
"""

import os
import tempfile
from typing import List, Optional, Any
from pathlib import Path

from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter, MarkdownHeaderTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings
from langchain_core.retrievers import BaseRetriever

# Docling imports
from docling.document_converter import DocumentConverter
from docling.datamodel.base_models import InputFormat
from docling.datamodel.pipeline_options import PdfPipelineOptions
from docling.document_converter import PdfFormatOption

from logging_config import get_logger

logger = get_logger(__name__)


class DocumentRAG:
    """문서 RAG 처리 클래스 - Docling chunking 에러 해결"""
    
    def __init__(self, embedding_model: str = "text-embedding-3-small", chunk_size: int = 1000, chunk_overlap: int = 200):
        """
        Args:
            embedding_model: OpenAI 임베딩 모델명
            chunk_size: 문서 청킹 크기
            chunk_overlap: 청킹 오버랩 크기
        """
        self.embedding_model = embedding_model
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.embeddings = OpenAIEmbeddings(model=embedding_model)
        
        # 텍스트 스플리터 초기화
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            length_function=len,
        )
        
        # Markdown 헤더 기반 스플리터
        self.markdown_splitter = MarkdownHeaderTextSplitter(
            headers_to_split_on=[
                ("#", "Header_1"),
                ("##", "Header_2"), 
                ("###", "Header_3"),
                ("####", "Header_4"),
            ],
            strip_headers=False
        )
        
        # Docling DocumentConverter 초기화
        self.doc_converter = self._init_docling_converter()
        
        self.vectorstore: Optional[Chroma] = None
        self.retriever: Optional[BaseRetriever] = None
        logger.info(f"DocumentRAG 초기화 완료 - embedding_model: {embedding_model}")
    
    def _init_docling_converter(self) -> DocumentConverter:
        """Docling DocumentConverter 초기화"""
        try:
            # PDF 파이프라인 옵션 설정
            pipeline_options = PdfPipelineOptions()
            pipeline_options.do_ocr = False  # OCR 비활성화로 속도 향상
            pipeline_options.do_table_structure = True  # 테이블 구조 인식 유지
            
            converter = DocumentConverter(
                format_options={
                    InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)
                }
            )
            logger.info("Docling DocumentConverter 초기화 완료")
            return converter
        except Exception as e:
            logger.error(f"Docling DocumentConverter 초기화 실패: {e}")
            return DocumentConverter()  # 기본 설정으로 fallback
    
    def process_uploaded_file(self, uploaded_file) -> List[Document]:
        """
        업로드된 파일을 처리하여 Document 객체 리스트 반환
        여러 fallback 방식을 사용하여 안정성 확보
        
        Args:
            uploaded_file: Streamlit의 UploadedFile 객체
            
        Returns:
            List[Document]: 처리된 문서 리스트
        """
        try:
            # 임시 파일 생성
            with tempfile.NamedTemporaryFile(delete=False, suffix=f".{uploaded_file.name.split('.')[-1]}") as tmp_file:
                tmp_file.write(uploaded_file.getvalue())
                tmp_file_path = tmp_file.name
            
            logger.info(f"파일 업로드 완료: {uploaded_file.name} -> {tmp_file_path}")
            
            file_extension = uploaded_file.name.split('.')[-1].lower()
            
            # 방법 1: 직접 Docling DocumentConverter 사용 (chunking 우회)
            try:
                documents = self._process_with_direct_docling(tmp_file_path, uploaded_file.name, uploaded_file.type)
                if documents:
                    logger.info(f"직접 Docling 변환 성공: {len(documents)}개 문서")
                    return documents
            except Exception as e:
                logger.warning(f"직접 Docling 변환 실패: {e}")
            
            # 방법 2: PyMuPDF fallback (PDF 전용)
            if file_extension == 'pdf':
                try:
                    documents = self._process_with_pymupdf(tmp_file_path, uploaded_file.name, uploaded_file.type)
                    if documents:
                        logger.info(f"PyMuPDF 변환 성공: {len(documents)}개 문서")
                        return documents
                except Exception as e:
                    logger.warning(f"PyMuPDF 변환 실패: {e}")
            
            # 방법 3: 단순 텍스트 추출
            try:
                documents = self._process_with_simple_text(tmp_file_path, file_extension, uploaded_file.name, uploaded_file.type)
                if documents:
                    logger.info(f"단순 텍스트 추출 성공: {len(documents)}개 문서")
                    return documents
            except Exception as e:
                logger.warning(f"단순 텍스트 추출 실패: {e}")
            
            raise Exception("모든 문서 처리 방법이 실패했습니다.")
            
        except Exception as e:
            logger.error(f"파일 처리 중 오류 발생: {e}", exc_info=True)
            raise e
        finally:
            # 임시 파일 정리
            if 'tmp_file_path' in locals():
                try:
                    os.unlink(tmp_file_path)
                except:
                    pass
    
    def _process_with_direct_docling(self, file_path: str, file_name: str, file_type: str) -> List[Document]:
        """
        직접 Docling DocumentConverter를 사용하여 Markdown 변환 후 별도 chunking
        """
        try:
            # Docling으로 문서 변환
            result = self.doc_converter.convert(file_path)
            
            # Markdown으로 내보내기 (chunking 없이)
            markdown_content = result.document.export_to_markdown()
            
            if not markdown_content or len(markdown_content.strip()) == 0:
                raise Exception("Markdown 변환 결과가 비어있음")
            
            # Markdown 헤더 기반으로 먼저 분할
            try:
                header_splits = self.markdown_splitter.split_text(markdown_content)
                logger.info(f"Markdown 헤더 분할 완료: {len(header_splits)}개 청크")
            except:
                # 헤더 분할 실패 시 전체 문서를 하나의 Document로 처리
                header_splits = [Document(page_content=markdown_content)]
                logger.info("Markdown 헤더 분할 실패, 전체 문서로 처리")
            
            # 각 헤더 섹션을 추가로 크기 기반 분할
            final_documents = []
            for doc in header_splits:
                if len(doc.page_content) > self.chunk_size:
                    # 큰 섹션은 추가 분할
                    sub_splits = self.text_splitter.split_documents([doc])
                    final_documents.extend(sub_splits)
                else:
                    final_documents.append(doc)
            
            # 메타데이터 추가
            for doc in final_documents:
                doc.metadata.update({
                    "source": file_name,
                    "file_type": file_type,
                    "processing_method": "direct_docling"
                })
            
            return final_documents
            
        except Exception as e:
            logger.error(f"직접 Docling 처리 실패: {e}")
            raise e
    
    def _process_with_pymupdf(self, file_path: str, file_name: str, file_type: str) -> List[Document]:
        """
        PyMuPDF4LLM을 사용한 PDF 처리 (fallback)
        """
        try:
            import pymupdf4llm
            
            # PDF를 Markdown으로 변환
            markdown_content = pymupdf4llm.to_markdown(file_path)
            
            if not markdown_content or len(markdown_content.strip()) == 0:
                raise Exception("PyMuPDF Markdown 변환 결과가 비어있음")
            
            # Markdown 분할
            try:
                header_splits = self.markdown_splitter.split_text(markdown_content)
                logger.info(f"PyMuPDF Markdown 헤더 분할 완료: {len(header_splits)}개 청크")
            except:
                header_splits = [Document(page_content=markdown_content)]
                logger.info("PyMuPDF Markdown 헤더 분할 실패, 전체 문서로 처리")
            
            # 추가 크기 기반 분할
            final_documents = []
            for doc in header_splits:
                if len(doc.page_content) > self.chunk_size:
                    sub_splits = self.text_splitter.split_documents([doc])
                    final_documents.extend(sub_splits)
                else:
                    final_documents.append(doc)
            
            # 메타데이터 추가
            for doc in final_documents:
                doc.metadata.update({
                    "source": file_name,
                    "file_type": file_type,
                    "processing_method": "pymupdf4llm"
                })
            
            return final_documents
            
        except ImportError:
            logger.error("PyMuPDF4LLM이 설치되지 않음. pip install pymupdf4llm으로 설치하세요.")
            raise Exception("PyMuPDF4LLM이 설치되지 않음")
        except Exception as e:
            logger.error(f"PyMuPDF 처리 실패: {e}")
            raise e
    
    def _process_with_simple_text(self, file_path: str, file_extension: str, file_name: str, file_type: str) -> List[Document]:
        """
        단순 텍스트 추출 (최종 fallback)
        """
        try:
            text_content = ""
            
            if file_extension in ['txt', 'md']:
                with open(file_path, 'r', encoding='utf-8') as f:
                    text_content = f.read()
            elif file_extension == 'pdf':
                # PyPDF2를 사용한 간단한 텍스트 추출
                try:
                    import PyPDF2
                    with open(file_path, 'rb') as f:
                        reader = PyPDF2.PdfReader(f)
                        text_content = "\n".join([page.extract_text() for page in reader.pages])
                except ImportError:
                    logger.warning("PyPDF2가 설치되지 않음")
                    raise Exception("PyPDF2가 설치되지 않아 텍스트 추출 불가")
            else:
                raise Exception(f"지원되지 않는 파일 형식: {file_extension}")
            
            # 텍스트 내용 검증
            if not text_content or len(text_content.strip()) == 0:
                raise Exception("추출된 텍스트가 비어있음")
            
            # 의미 있는 텍스트인지 확인 (너무 짧거나 특수문자만 있는 경우 제외)
            cleaned_text = text_content.strip()
            if len(cleaned_text) < 50:  # 50자 미만이면 의미 있는 내용이 아닐 가능성
                raise Exception("추출된 텍스트가 너무 짧음 (50자 미만)")
            
            # 텍스트 분할
            documents = self.text_splitter.create_documents([text_content])
            
            # 메타데이터 추가
            for doc in documents:
                doc.metadata.update({
                    "source": file_name,
                    "file_type": file_type,
                    "processing_method": "simple_text"
                })
            
            return documents
            
        except Exception as e:
            logger.error(f"단순 텍스트 처리 실패: {e}")
            raise e
    
    def split_documents(self, documents: List[Document]) -> List[Document]:
        """
        문서를 작은 청크로 분할 (이미 분할된 경우 그대로 반환)
        
        Args:
            documents: 분할할 문서 리스트
            
        Returns:
            List[Document]: 분할된 문서 청크 리스트
        """
        try:
            # 문서가 이미 적절한 크기로 분할되었는지 확인
            large_docs = [doc for doc in documents if len(doc.page_content) > self.chunk_size * 1.5]
            
            if not large_docs:
                logger.info(f"문서가 이미 적절히 분할됨: {len(documents)}개 청크")
                return documents
            
            # 큰 문서만 추가 분할
            split_docs = []
            for doc in documents:
                if len(doc.page_content) > self.chunk_size * 1.5:
                    sub_docs = self.text_splitter.split_documents([doc])
                    split_docs.extend(sub_docs)
                else:
                    split_docs.append(doc)
            
            logger.info(f"문서 분할 완료: {len(documents)}개 문서 -> {len(split_docs)}개 청크")
            return split_docs
        except Exception as e:
            logger.error(f"문서 분할 중 오류 발생: {e}", exc_info=True)
            raise e
    
    def reset_vectorstore(self):
        """
        기존 벡터스토어와 retriever를 완전히 초기화
        새로운 문서 업로드 시 기존 데이터를 모두 제거
        """
        try:
            if self.vectorstore:
                # 기존 vectorstore의 collection 삭제
                try:
                    self.vectorstore.delete_collection()
                    logger.info("기존 벡터스토어 collection 삭제 완료")
                except Exception as e:
                    logger.warning(f"벡터스토어 collection 삭제 중 오류 (무시): {e}")
            
            # 인스턴스 변수 초기화
            self.vectorstore = None
            self.retriever = None
            logger.info("벡터스토어 및 retriever 초기화 완료")
            
        except Exception as e:
            logger.error(f"벡터스토어 초기화 중 오류 발생: {e}")
            # 오류가 발생해도 인스턴스 변수는 초기화
            self.vectorstore = None
            self.retriever = None

    def create_vectorstore(self, documents: List[Document], reset_existing: bool = True) -> Chroma:
        """
        문서들로부터 벡터스토어 생성
        
        Args:
            documents: 벡터화할 문서 리스트
            reset_existing: 기존 벡터스토어를 초기화할지 여부
            
        Returns:
            Chroma: 생성된 벡터스토어
        """
        try:
            # 기존 벡터스토어 초기화 (선택적)
            if reset_existing:
                self.reset_vectorstore()
                logger.info("기존 벡터스토어 초기화 후 새로운 벡터스토어 생성")
            
            # 고유한 collection name 생성 (타임스탬프 기반)
            import time
            collection_name = f"document_rag_{int(time.time())}"
            
            # 메모리 내 Chroma 벡터스토어 생성
            vectorstore = Chroma.from_documents(
                documents=documents,
                embedding=self.embeddings,
                collection_name=collection_name
            )
            
            self.vectorstore = vectorstore
            self.retriever = vectorstore.as_retriever(
                search_type="similarity",
                search_kwargs={"k": 5}
            )
            
            logger.info(f"새로운 벡터스토어 생성 완료: {len(documents)}개 문서, collection: {collection_name}")
            return vectorstore
            
        except Exception as e:
            logger.error(f"벡터스토어 생성 중 오류 발생: {e}", exc_info=True)
            raise e
    
    def search_documents(self, query: str, k: int = 5) -> List[Document]:
        """
        쿼리와 유사한 문서 검색
        
        Args:
            query: 검색 쿼리
            k: 반환할 문서 수
            
        Returns:
            List[Document]: 검색된 문서 리스트
        """
        if not self.retriever:
            logger.warning("벡터스토어가 초기화되지 않았습니다.")
            return []
        
        try:
            results = self.retriever.invoke(query)
            logger.info(f"문서 검색 완료: '{query}' -> {len(results)}개 결과")
            return results[:k]
        except Exception as e:
            logger.error(f"문서 검색 중 오류 발생: {e}", exc_info=True)
            return []
    
    def process_and_index_files(self, uploaded_files, reset_existing: bool = True) -> int:
        """
        업로드된 파일들을 처리하고 인덱싱
        실패한 파일은 벡터스토어에 포함하지 않음
        
        Args:
            uploaded_files: Streamlit UploadedFile 객체들의 리스트
            reset_existing: 기존 벡터스토어를 초기화할지 여부 (기본값: True)
            
        Returns:
            int: 처리된 총 문서 청크 수
        """
        try:
            # 새로운 문서 업로드 시작 시 로깅
            logger.info(f"새로운 문서 업로드 시작: {len(uploaded_files)}개 파일")
            if reset_existing:
                logger.info("기존 벡터 DB 및 관련 데이터 초기화 예정")
            
            all_documents = []
            successful_files = []
            failed_files = []
            
            for uploaded_file in uploaded_files:
                logger.info(f"파일 처리 시작: {uploaded_file.name}")
                try:
                    documents = self.process_uploaded_file(uploaded_file)
                    
                    # 유효한 문서만 추가 (빈 문서나 에러 메시지 제외)
                    valid_documents = []
                    for doc in documents:
                        if not is_error_content(doc.page_content, doc.metadata):
                            valid_documents.append(doc)
                    
                    if valid_documents:
                        all_documents.extend(valid_documents)
                        successful_files.append(uploaded_file.name)
                        logger.info(f"파일 처리 완료: {uploaded_file.name} -> {len(valid_documents)}개 유효 청크")
                    else:
                        failed_files.append(uploaded_file.name)
                        logger.warning(f"파일에서 유효한 내용을 추출할 수 없음: {uploaded_file.name}")
                        
                except Exception as e:
                    failed_files.append(uploaded_file.name)
                    logger.error(f"파일 처리 실패: {uploaded_file.name} - {e}")
                    # 에러 메시지를 벡터스토어에 저장하지 않고 로그만 남김
                    continue
            
            # 결과 보고
            logger.info(f"파일 처리 결과: 성공 {len(successful_files)}개, 실패 {len(failed_files)}개")
            if successful_files:
                logger.info(f"성공한 파일: {', '.join(successful_files)}")
            if failed_files:
                logger.warning(f"실패한 파일: {', '.join(failed_files)}")
            
            if all_documents:
                # 기존 벡터스토어 초기화 후 새로운 벡터스토어 생성
                self.create_vectorstore(all_documents, reset_existing=reset_existing)
                logger.info(f"새로운 벡터스토어 생성 완료: {len(all_documents)}개 유효 청크")
                if reset_existing:
                    logger.info("기존 문서들이 모두 제거되고 새로운 문서들로 벡터 DB가 교체되었습니다.")
                return len(all_documents)
            else:
                # 유효한 문서가 없어도 기존 벡터스토어 초기화 (요청된 경우)
                if reset_existing:
                    self.reset_vectorstore()
                    logger.info("유효한 새 문서가 없어 기존 벡터스토어만 초기화되었습니다.")
                logger.warning("처리 가능한 문서가 없습니다.")
                return 0
                
        except Exception as e:
            logger.error(f"파일 처리 및 인덱싱 중 오류 발생: {e}", exc_info=True)
            raise e
    
    def get_context_for_query(self, query: str) -> str:
        """
        쿼리에 대한 컨텍스트 문서들을 검색하여 문자열로 반환
        에러 메시지나 무의미한 내용은 제외
        
        Args:
            query: 검색 쿼리
            
        Returns:
            str: 검색된 문서들의 내용을 결합한 컨텍스트
        """
        try:
            relevant_docs = self.search_documents(query)
            if not relevant_docs:
                return ""
            
            context_parts = []
            valid_doc_count = 0
            
            for doc in relevant_docs:
                # 에러 메시지나 무의미한 내용 필터링
                if not is_error_content(doc.page_content, doc.metadata):
                    valid_doc_count += 1
                    source = doc.metadata.get("source", "Unknown")
                    processing_method = doc.metadata.get("processing_method", "unknown")
                    context_parts.append(f"[문서 {valid_doc_count} - {source} ({processing_method})]\n{doc.page_content.strip()}")
            
            if not context_parts:
                logger.warning(f"검색된 문서가 모두 무효한 내용임: '{query}'")
                return ""
            
            context = "\n\n".join(context_parts)
            logger.info(f"컨텍스트 생성 완료: {valid_doc_count}개 유효 문서, {len(context)} 문자")
            return context
            
        except Exception as e:
            logger.error(f"컨텍스트 생성 중 오류 발생: {e}", exc_info=True)
            return ""


    def clean_vectorstore(self):
        """
        벡터스토어에서 에러 메시지나 무의미한 내용을 제거
        기존에 저장된 잘못된 문서들을 정리할 때 사용
        실제로는 reset_vectorstore()를 호출하여 완전 초기화
        """
        if not self.vectorstore:
            logger.warning("벡터스토어가 초기화되지 않았습니다.")
            return
        
        try:
            logger.info("벡터스토어 정리 시작: 기존 데이터 모두 제거")
            self.reset_vectorstore()
            logger.info("벡터스토어 정리 완료: 새로운 문서를 업로드하세요.")
            
        except Exception as e:
            logger.error(f"벡터스토어 정리 중 오류 발생: {e}")

    def get_vectorstore_status(self) -> dict:
        """
        현재 벡터스토어 상태 정보 반환
        
        Returns:
            dict: 벡터스토어 상태 정보
        """
        status = {
            "has_vectorstore": self.vectorstore is not None,
            "has_retriever": self.retriever is not None,
            "document_count": 0,
            "collection_name": None
        }
        
        try:
            if self.vectorstore:
                # Chroma collection 정보 확인
                collection = self.vectorstore._collection
                if collection:
                    status["collection_name"] = collection.name
                    status["document_count"] = collection.count()
                    
        except Exception as e:
            logger.warning(f"벡터스토어 상태 확인 중 오류: {e}")
        
        return status


def create_document_rag() -> DocumentRAG:
    """DocumentRAG 인스턴스 생성 팩토리 함수"""
    return DocumentRAG()


# 에러 메시지 패턴들 (추가 필터링용)
ERROR_MESSAGE_PATTERNS = [
    "처리할 수 없습니다",
    "지원되지 않는 형식",
    "파일이 손상",
    "텍스트를 추출할 수 없음",
    "변환 결과가 비어있음",
    "fallback_error"
]


def is_error_content(content: str, metadata: dict = None) -> bool:
    """
    문서 내용이 에러 메시지인지 확인
    
    Args:
        content: 문서 내용
        metadata: 문서 메타데이터
        
    Returns:
        bool: 에러 메시지이면 True
    """
    if not content or len(content.strip()) < 50:
        return True
    
    content_lower = content.lower()
    
    # 에러 메시지 패턴 확인
    for pattern in ERROR_MESSAGE_PATTERNS:
        if pattern in content_lower:
            return True
    
    # 메타데이터에서 에러 표시 확인
    if metadata:
        processing_method = metadata.get("processing_method", "")
        if "error" in processing_method.lower():
            return True
    
    # 대괄호로 시작하는 에러 메시지 형태 확인
    if content.strip().startswith('[') and content.strip().endswith(']'):
        return True
    
    return False


# 선택적 dependencies 확인
def check_optional_dependencies():
    """선택적 의존성 패키지 확인"""
    dependencies = {
        "pymupdf4llm": "PDF 처리 개선을 위해 설치 권장",
        "PyPDF2": "PDF 텍스트 추출 fallback을 위해 설치 권장"
    }
    
    missing = []
    for package, description in dependencies.items():
        try:
            __import__(package)
        except ImportError:
            missing.append(f"{package}: {description}")
    
    if missing:
        logger.warning("선택적 의존성이 누락됨:")
        for item in missing:
            logger.warning(f"  - {item}")
        logger.warning("pip install pymupdf4llm PyPDF2로 설치할 수 있습니다.")


# 모듈 임포트 시 의존성 확인
if __name__ != "__main__":
    check_optional_dependencies()