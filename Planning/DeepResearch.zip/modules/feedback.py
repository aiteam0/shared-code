from typing import List
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel
from langchain_utils.llm_factory import LLMFactory
from logging_config import get_logger
import os

logger = get_logger(__name__)

class FeedbackResponse(BaseModel):
    questions: List[str]


def generate_feedback_questions(
    query: str, 
    model_name: str = "gpt-4o-mini", 
    max_feedbacks: int = 3
) -> List[str]:
    """
    연구 방향을 명확히 하기 위한 후속 질문을 생성합니다.
    
    Args:
        query: 초기 연구 질문
        model_name: 사용할 LLM 모델명
        max_feedbacks: 최대 피드백 질문 수
        
    Returns:
        생성된 피드백 질문 리스트
    """
    logger.info(f"피드백 질문 생성 시작 - 주제: {query[:50]}...")
    
    try:
        # LLM Factory를 사용하여 모델 생성
        try:
            factory = LLMFactory()
            model = factory.create_llm(model_name)
        except (ValueError, FileNotFoundError) as e:
            logger.warning(f"LLM Factory 사용 실패, 기본 모델 사용: {e}")
            model = ChatOpenAI(
                model=model_name,
                openai_api_key=os.getenv("OPENAI_API_KEY")
            )
        
        # 구조화된 출력을 위한 모델 설정
        structured_model = model.with_structured_output(FeedbackResponse)
        
        # 프롬프트 템플릿 생성
        prompt_template = ChatPromptTemplate.from_messages([
            ("system", """당신은 전문 연구원입니다. 사용자의 연구 주제를 더 구체적이고 깊이 있게 탐구할 수 있도록 도와주는 후속 질문을 생성하는 것이 목표입니다."""),
            ("human", """
사용자가 다음과 같은 연구 주제를 제시했습니다: "{query}"

더 정확하고 깊이 있는 리서치를 위해 사용자에게 물어볼 후속 질문을 최대 {max_feedbacks}개 생성해주세요.

다음 기준으로 질문을 생성하세요:
1. 연구의 목적과 범위를 명확히 하는 질문
2. 특정 관점이나 측면에 집중할지 확인하는 질문  
3. 대상 독자나 사용 목적을 파악하는 질문
4. 시간적, 지역적 범위를 구체화하는 질문

원래 질문이 이미 충분히 구체적이고 명확하다면 빈 배열을 반환해도 됩니다.

질문은 한국어로 생성하고, 각 질문은 명확하고 구체적이어야 합니다.
            """)
        ])
        
        # 체인 생성 및 실행
        chain = prompt_template | structured_model
        response = chain.invoke({
            "query": query,
            "max_feedbacks": max_feedbacks
        })
        
        questions = response.questions if response else []
        
        logger.info(f"피드백 질문 {len(questions)}개 생성 완료")
        for i, question in enumerate(questions, 1):
            logger.debug(f"질문 {i}: {question}")
        
        return questions
        
    except Exception as e:
        logger.error(f"피드백 질문 생성 실패: {e}", exc_info=True)
        return []


def combine_query_with_feedback(
    initial_query: str, 
    feedback_questions: List[str], 
    feedback_answers: List[str]
) -> str:
    """
    초기 질문과 피드백 질문/답변을 결합하여 정제된 연구 질문을 생성합니다.
    
    Args:
        initial_query: 초기 연구 질문
        feedback_questions: 피드백 질문 리스트
        feedback_answers: 피드백 답변 리스트
        
    Returns:
        결합된 연구 질문
    """
    logger.info("연구 질문 결합 시작")
    
    if not feedback_questions or not feedback_answers:
        logger.info("피드백이 없어 초기 질문을 그대로 반환")
        return initial_query
    
    try:
        combined_query = f"초기 질문: {initial_query}\n\n"
        
        for i, (question, answer) in enumerate(zip(feedback_questions, feedback_answers), 1):
            if answer.strip():  # 빈 답변은 제외
                combined_query += f"{i}. 질문: {question}\n"
                combined_query += f"   답변: {answer}\n\n"
        
        logger.info(f"연구 질문 결합 완료 - 총 길이: {len(combined_query)} 문자")
        logger.debug(f"결합된 질문: {combined_query[:200]}...")
        
        return combined_query.strip()
        
    except Exception as e:
        logger.error(f"연구 질문 결합 실패: {e}", exc_info=True)
        return initial_query 