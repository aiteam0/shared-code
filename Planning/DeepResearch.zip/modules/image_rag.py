"""
이미지 RAG 기능을 위한 모듈
LangChain과 LangGraph의 multimodal input 처리를 사용하여 이미지를 처리
"""

import base64
import io
from typing import List, Optional, Dict, Any, Union
from PIL import Image

from langchain_core.messages import HumanMessage, AIMessage
from langchain_core.documents import Document
from langchain_openai import ChatOpenAI
from langchain_utils.llm_factory import LLMFactory

from logging_config import get_logger

logger = get_logger(__name__)


class ImageRAG:
    """이미지 RAG 처리 클래스"""
    
    def __init__(self, model_name: str = "gpt-4o"):
        """
        Args:
            model_name: 멀티모달 처리를 위한 모델명
        """
        self.model_name = model_name
        
        # LLM Factory를 사용하여 멀티모달 지원 모델 생성
        try:
            factory = LLMFactory()
            # 멀티모달 capability 확인 후 모델 생성
            if factory.has_capability(model_name, "multimodal"):
                self.llm = factory.create_llm(model_name)
            else:
                # fallback to multimodal-capable model
                logger.warning(f"모델 {model_name}이 멀티모달을 지원하지 않음. fallback 모델 사용")
                self.llm = factory.get_fallback_for_capability(model_name, "multimodal")
        except (ValueError, FileNotFoundError) as e:
            logger.warning(f"LLM Factory 사용 실패, 기본 모델 사용: {e}")
            self.llm = ChatOpenAI(model=model_name, temperature=0)
            
        self.processed_images: List[Dict[str, Any]] = []
        logger.info(f"ImageRAG 초기화 완료 - model: {model_name}")
    
    def encode_image_to_base64(self, uploaded_file) -> str:
        """
        업로드된 이미지 파일을 base64로 인코딩
        
        Args:
            uploaded_file: Streamlit의 UploadedFile 객체
            
        Returns:
            str: base64로 인코딩된 이미지 문자열
        """
        try:
            # 이미지를 PIL로 열어서 처리
            image = Image.open(uploaded_file)
            
            # RGBA를 RGB로 변환 (필요한 경우)
            if image.mode == 'RGBA':
                image = image.convert('RGB')
            
            # 이미지 크기 조정 (OpenAI API 제한을 위해)
            max_size = 1024
            if max(image.size) > max_size:
                ratio = max_size / max(image.size)
                new_size = tuple(int(dim * ratio) for dim in image.size)
                image = image.resize(new_size, Image.Resampling.LANCZOS)
            
            # base64로 인코딩
            buffered = io.BytesIO()
            image.save(buffered, format="JPEG", quality=85)
            img_bytes = buffered.getvalue()
            img_base64 = base64.b64encode(img_bytes).decode()
            
            logger.info(f"이미지 인코딩 완료: {uploaded_file.name}, 크기: {image.size}")
            return img_base64
            
        except Exception as e:
            logger.error(f"이미지 인코딩 중 오류 발생: {e}", exc_info=True)
            raise e
    
    def analyze_image(self, uploaded_file, query: str = None) -> str:
        """
        이미지를 분석하고 설명을 생성
        
        Args:
            uploaded_file: Streamlit의 UploadedFile 객체
            query: 이미지에 대한 특정 질문 (선택사항)
            
        Returns:
            str: 이미지 분석 결과
        """
        try:
            # 이미지를 base64로 인코딩
            img_base64 = self.encode_image_to_base64(uploaded_file)
            
            # 멀티모달 메시지 생성
            if query:
                prompt = f"""이 이미지를 분석하고 다음 질문에 답해주세요: {query}

이미지에서 보이는 주요 요소들을 상세히 설명하고, 질문과 관련된 내용을 중심으로 답변해주세요."""
            else:
                prompt = """이 이미지를 자세히 분석하고 설명해주세요. 

다음 항목들을 포함해서 설명해주세요:
1. 이미지의 주요 내용과 객체들
2. 색상, 구성, 스타일 등의 시각적 특징
3. 텍스트가 있다면 그 내용
4. 이미지의 맥락이나 목적
5. 기타 중요한 세부사항들"""
            
            # 멀티모달 메시지 구성
            message = HumanMessage(
                content=[
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{img_base64}"}
                    }
                ]
            )
            
            # LLM으로 이미지 분석
            response = self.llm.invoke([message])
            analysis = response.content
            
            # 처리된 이미지 정보 저장
            image_info = {
                "filename": uploaded_file.name,
                "file_type": uploaded_file.type,
                "analysis": analysis,
                "base64": img_base64,
                "query": query
            }
            self.processed_images.append(image_info)
            
            logger.info(f"이미지 분석 완료: {uploaded_file.name}")
            return analysis
            
        except Exception as e:
            logger.error(f"이미지 분석 중 오류 발생: {e}", exc_info=True)
            raise e
    
    def process_multiple_images(self, uploaded_files, query: str = None) -> List[Dict[str, str]]:
        """
        여러 이미지를 일괄 처리
        
        Args:
            uploaded_files: Streamlit UploadedFile 객체들의 리스트
            query: 이미지들에 대한 공통 질문 (선택사항)
            
        Returns:
            List[Dict[str, str]]: 각 이미지의 분석 결과 리스트
        """
        results = []
        
        for uploaded_file in uploaded_files:
            try:
                logger.info(f"이미지 처리 시작: {uploaded_file.name}")
                analysis = self.analyze_image(uploaded_file, query)
                results.append({
                    "filename": uploaded_file.name,
                    "analysis": analysis
                })
            except Exception as e:
                logger.error(f"이미지 처리 실패: {uploaded_file.name} - {e}")
                results.append({
                    "filename": uploaded_file.name,
                    "analysis": f"이미지 처리 중 오류 발생: {str(e)}"
                })
        
        logger.info(f"전체 이미지 처리 완료: {len(results)}개")
        return results
    
    def search_images(self, query: str) -> List[Dict[str, Any]]:
        """
        처리된 이미지들 중에서 쿼리와 관련된 이미지 검색
        
        Args:
            query: 검색 쿼리
            
        Returns:
            List[Dict[str, Any]]: 관련된 이미지 정보 리스트
        """
        if not self.processed_images:
            logger.warning("처리된 이미지가 없습니다.")
            return []
        
        try:
            # 간단한 키워드 기반 검색 (향후 개선 가능)
            relevant_images = []
            query_lower = query.lower()
            
            for img_info in self.processed_images:
                analysis_lower = img_info["analysis"].lower()
                filename_lower = img_info["filename"].lower()
                
                # 분석 텍스트나 파일명에서 쿼리 키워드 검색
                if (query_lower in analysis_lower or 
                    query_lower in filename_lower or
                    any(word in analysis_lower for word in query_lower.split())):
                    relevant_images.append(img_info)
            
            logger.info(f"이미지 검색 완료: '{query}' -> {len(relevant_images)}개 결과")
            return relevant_images
            
        except Exception as e:
            logger.error(f"이미지 검색 중 오류 발생: {e}", exc_info=True)
            return []
    
    def get_image_context_for_query(self, query: str) -> str:
        """
        쿼리에 대한 이미지 컨텍스트를 검색하여 텍스트로 반환
        
        Args:
            query: 검색 쿼리
            
        Returns:
            str: 검색된 이미지들의 분석 내용을 결합한 컨텍스트
        """
        try:
            relevant_images = self.search_images(query)
            if not relevant_images:
                return ""
            
            context_parts = []
            for i, img_info in enumerate(relevant_images, 1):
                filename = img_info["filename"]
                analysis = img_info["analysis"]
                context_parts.append(f"[이미지 {i} - {filename}]\n{analysis}")
            
            context = "\n\n".join(context_parts)
            logger.info(f"이미지 컨텍스트 생성 완료: {len(relevant_images)}개 이미지, {len(context)} 문자")
            return context
            
        except Exception as e:
            logger.error(f"이미지 컨텍스트 생성 중 오류 발생: {e}", exc_info=True)
            return ""
    
    def create_multimodal_message(self, text: str, image_base64: str) -> HumanMessage:
        """
        텍스트와 이미지를 포함한 멀티모달 메시지 생성
        
        Args:
            text: 텍스트 내용
            image_base64: base64 인코딩된 이미지
            
        Returns:
            HumanMessage: 멀티모달 메시지
        """
        return HumanMessage(
            content=[
                {"type": "text", "text": text},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"}
                }
            ]
        )
    
    def get_processed_images_info(self) -> List[Dict[str, str]]:
        """
        처리된 이미지들의 정보 반환 (base64 제외)
        
        Returns:
            List[Dict[str, str]]: 이미지 정보 리스트
        """
        return [
            {
                "filename": img["filename"],
                "file_type": img["file_type"],
                "analysis": img["analysis"][:200] + "..." if len(img["analysis"]) > 200 else img["analysis"]
            }
            for img in self.processed_images
        ]
    
    def clear_processed_images(self):
        """처리된 이미지 목록 초기화"""
        self.processed_images = []
        logger.info("처리된 이미지 목록 초기화 완료")


def create_image_rag(model_name: str = "gpt-4o") -> ImageRAG:
    """ImageRAG 인스턴스 생성 팩토리 함수"""
    return ImageRAG(model_name=model_name) 