from typing import List, Dict, Any, TypedDict
from langchain_openai import ChatOpenAI
from langchain_core.tools import BaseTool
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langchain_core.messages import HumanMessage, AIMessage
from langchain_utils.llm_factory import LLMFactory

from .deep_research import (
    generate_feedback_questions, 
    deep_research, 
    generate_final_report,
)

# 로거 설정
try:
    from logging_config import get_logger
    logger = get_logger(__name__)
except ImportError:
    import logging
    logger = logging.getLogger(__name__)


class DeepResearchState(TypedDict):
    """딥리서치 상태 정의"""
    # 입력
    query: str
    breadth: int
    depth: int
    
    # 피드백 단계
    feedback_questions: List[str]
    feedback_answers: List[str]
    refined_query: str
    
    # 연구 단계
    research_result: Dict[str, Any]
    
    # 보고서 단계
    final_report: str
    
    # 메타데이터
    current_step: str
    error_message: str


class DeepResearchAgent:
    """LangGraph 기반 딥리서치 에이전트"""
    
    def __init__(self, model_name: str = "gpt-4o", tools: List[BaseTool] = None):
        """
        딥리서치 에이전트 초기화
        
        Args:
            model_name: 사용할 모델명
            tools: 검색 도구 목록
        """
        # LLM Factory를 사용하여 모델 생성 (Tool calling capability 확인)
        try:
            factory = LLMFactory()
            if factory.has_capability(model_name, "tool_calling"):
                self.model = factory.create_llm(model_name)
            else:
                logger.warning(f"모델 {model_name}이 tool calling을 지원하지 않음. fallback 모델 사용")
                self.model = factory.get_fallback_for_capability(model_name, "tool_calling")
        except (ValueError, FileNotFoundError) as e:
            logger.warning(f"LLM Factory 사용 실패, 기본 모델 사용: {e}")
            self.model = ChatOpenAI(model_name=model_name)
            
        self.tools = tools or []
        self.memory = MemorySaver()
        self.graph = self._build_graph()
    
    def _build_graph(self) -> StateGraph:
        """딥리서치 그래프 구성"""
        
        # 상태 그래프 생성
        workflow = StateGraph(DeepResearchState)
        
        # 노드 추가
        workflow.add_node("generate_feedback", self._generate_feedback_node)
        workflow.add_node("conduct_research", self._conduct_research_node)
        workflow.add_node("generate_report", self._generate_report_node)
        
        # 엣지 정의
        workflow.add_conditional_edges(
            START,
            self._should_generate_feedback,
            {
                "feedback": "generate_feedback",
                "research": "conduct_research"
            }
        )
        workflow.add_conditional_edges(
            "generate_feedback",
            self._should_skip_refine,
            {
                "research": "conduct_research"
            }
        )
        workflow.add_edge("conduct_research", "generate_report")
        workflow.add_edge("generate_report", END)
        
        # 그래프 컴파일
        return workflow.compile(checkpointer=self.memory)
    
    def _generate_feedback_node(self, state: DeepResearchState) -> Dict[str, Any]:
        """피드백 질문 생성 노드"""
        try:
            logger.info("=== 1단계: 피드백 질문 생성 ===")
            
            feedback_questions = generate_feedback_questions(
                query=state["query"],
                model=self.model,
                max_feedbacks=3
            )
            
            return {
                "feedback_questions": feedback_questions,
                "current_step": "feedback_generated"
            }
            
        except Exception as e:
            return {
                "feedback_questions": [],
                "current_step": "error",
                "error_message": f"피드백 질문 생성 중 오류: {str(e)}"
            }
    
    def _should_generate_feedback(self, state: DeepResearchState) -> str:
        """피드백 질문 생성 필요 여부 판단"""
        # 이미 피드백 답변이 있으면 피드백 질문 생성을 건너뛰고 바로 연구로 진행
        feedback_answers = state.get("feedback_answers", [])
        logger.info(f"피드백 답변 확인: {len(feedback_answers)}개")
        if feedback_answers and len(feedback_answers) > 0:
            logger.info("피드백 답변이 있어 바로 연구로 진행")
            return "research"
        else:
            logger.info("피드백 답변이 없어 피드백 질문 생성으로 진행")
            return "feedback"
    
    def _should_skip_refine(self, state: DeepResearchState) -> str:
        """refine 단계를 건너뛰고 바로 연구로 진행"""
        return "research"
    
    def _conduct_research_node(self, state: DeepResearchState) -> Dict[str, Any]:
        """딥리서치 수행 노드"""
        try:
            logger.info("=== 2단계: 딥리서치 수행 ===")
            
            # 피드백 답변이 있으면 쿼리 개선
            query = state["query"]
            feedback_questions = state.get("feedback_questions", [])
            feedback_answers = state.get("feedback_answers", [])
            
            logger.info(f"원본 쿼리: {query}")
            logger.info(f"피드백 질문 수: {len(feedback_questions)}")
            logger.info(f"피드백 답변 수: {len(feedback_answers)}")
            
            if feedback_questions and feedback_answers:
                # 피드백 답변을 포함한 정제된 쿼리 생성
                refined_query = f"초기 질문: {query}\n\n"
                for i, (question, answer) in enumerate(zip(feedback_questions, feedback_answers), 1):
                    if answer.strip():  # 빈 답변은 제외
                        refined_query += f"{i}. 질문: {question}\n"
                        refined_query += f"   답변: {answer}\n\n"
                query = refined_query.strip()
                logger.info(f"정제된 쿼리: {query[:200]}...")
            
            breadth = state.get("breadth", 2)
            depth = state.get("depth", 2)
            
            logger.info(f"연구 파라미터 - 폭: {breadth}, 깊이: {depth}")
            logger.info(f"사용 가능한 도구 수: {len(self.tools)}")
            
            for i, tool in enumerate(self.tools):
                logger.info(f"도구 {i+1}: {tool.name}")
            
            research_result = deep_research(
                query=query,
                tools=self.tools,
                model=self.model,
                breadth=breadth,
                depth=depth
            )
            
            logger.info(f"딥리서치 결과 - 학습내용: {len(research_result.learnings)}개, URL: {len(research_result.visited_urls)}개")
            
            return {
                "research_result": {
                    "learnings": research_result.learnings,
                    "visited_urls": research_result.visited_urls
                },
                "refined_query": query,  # 정제된 쿼리도 저장
                "current_step": "research_completed"
            }
            
        except Exception as e:
            logger.error(f"딥리서치 수행 중 오류: {e}")
            import traceback
            traceback.print_exc()
            return {
                "research_result": {"learnings": [], "visited_urls": []},
                "current_step": "error",
                "error_message": f"딥리서치 수행 중 오류: {str(e)}"
            }
    
    def _generate_report_node(self, state: DeepResearchState) -> Dict[str, Any]:
        """최종 보고서 생성 노드"""
        try:
            logger.info("=== 3단계: 최종 보고서 생성 ===")
            
            query = state.get("refined_query", state["query"])
            research_result = state.get("research_result", {})
            
            final_report = generate_final_report(
                query=query,
                learnings=research_result.get("learnings", []),
                visited_urls=research_result.get("visited_urls", []),
                model=self.model
            )
            
            return {
                "final_report": final_report,
                "current_step": "completed"
            }
            
        except Exception as e:
            return {
                "final_report": f"# 보고서 생성 실패\n\n오류: {str(e)}",
                "current_step": "error",
                "error_message": f"보고서 생성 중 오류: {str(e)}"
            }
    
    def run_research(
        self, 
        query: str, 
        breadth: int = 2, 
        depth: int = 2,
        feedback_answers: List[str] = None
    ) -> Dict[str, Any]:
        """
        딥리서치 실행
        
        Args:
            query: 연구 주제
            breadth: 연구 폭
            depth: 연구 깊이
            feedback_answers: 피드백 질문에 대한 답변
            
        Returns:
            딥리서치 결과
        """
        
        # 초기 상태 설정
        initial_state = {
            "query": query,
            "breadth": breadth,
            "depth": depth,
            "feedback_questions": [],
            "feedback_answers": feedback_answers or [],
            "refined_query": "",
            "research_result": {},
            "final_report": "",
            "current_step": "start",
            "error_message": ""
        }
        
        # 설정
        config = {"configurable": {"thread_id": "deep_research_session"}}
        
        try:
            # 그래프 실행
            result = self.graph.invoke(initial_state, config)
            return result
            
        except Exception as e:
            logger.error(f"딥리서치 실행 중 오류: {e}")
            return {
                **initial_state,
                "current_step": "error",
                "error_message": str(e),
                "final_report": f"# 딥리서치 실행 실패\n\n오류: {str(e)}"
            }
    
    def stream_research(
        self, 
        query: str, 
        breadth: int = 2, 
        depth: int = 2,
        feedback_answers: List[str] = None
    ):
        """
        딥리서치 스트리밍 실행
        
        Args:
            query: 연구 주제
            breadth: 연구 폭  
            depth: 연구 깊이
            feedback_answers: 피드백 질문에 대한 답변
            
        Yields:
            각 단계별 실행 결과
        """
        
        # 초기 상태 설정
        initial_state = {
            "query": query,
            "breadth": breadth,
            "depth": depth,
            "feedback_questions": [],
            "feedback_answers": feedback_answers or [],
            "refined_query": "",
            "research_result": {},
            "final_report": "",
            "current_step": "start",
            "error_message": ""
        }
        
        # 설정
        config = {"configurable": {"thread_id": "deep_research_session"}}
        
        try:
            # 그래프 스트리밍 실행
            for chunk in self.graph.stream(initial_state, config):
                yield chunk
                
        except Exception as e:
            logger.error(f"딥리서치 스트리밍 중 오류: {e}")
            yield {
                "error": {
                    **initial_state,
                    "current_step": "error",
                    "error_message": str(e)
                }
            } 