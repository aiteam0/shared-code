from typing import List
from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI


class FeedbackResponse(BaseModel):
    """피드백 질문 응답 스키마"""
    questions: List[str] = Field(description="후속 질문 목록")


def generate_feedback_questions(
    query: str, 
    model: ChatOpenAI, 
    max_feedbacks: int = 3
) -> List[str]:
    """
    연구 방향을 명확히 하기 위한 후속 질문을 생성합니다.
    
    Args:
        query: 사용자의 초기 질문
        model: OpenAI 모델 인스턴스
        max_feedbacks: 최대 질문 개수
        
    Returns:
        생성된 후속 질문 목록
    """
    
    prompt = f"""
    주어진 사용자 질문에 대해 연구 방향을 구체화하기 위한 후속 질문을 생성하세요.
    최대 {max_feedbacks}개의 질문을 생성하되, 원래 질문이 충분히 명확하다면 더 적게 생성해도 됩니다.
    
    사용자 질문: {query}
    
    후속 질문은 다음과 같은 목적을 가져야 합니다:
    - 연구 범위와 깊이를 구체화
    - 특정 관점이나 측면에 대한 관심도 파악
    - 연구 목적과 활용 방안 명확화
    
    한국어로 답변하세요.
    """
    
    try:
        # 구조화된 출력 사용
        structured_model = model.with_structured_output(FeedbackResponse)
        response = structured_model.invoke(prompt)
        
        if response and response.questions:
            print(f"주제 '{query}'에 대한 후속 질문 {len(response.questions)}개 생성됨")
            return response.questions
        else:
            print("후속 질문이 생성되지 않았습니다.")
            return []
            
    except Exception as e:
        print(f"오류: 후속 질문 생성 중 문제 발생: {e}")
        return [] 