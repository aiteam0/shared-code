import json
from typing import List, Dict, Optional, Any
from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from langchain_core.tools import BaseTool
from datetime import datetime

# 로거 설정
try:
    from logging_config import get_logger
    logger = get_logger(__name__)
except ImportError:
    import logging
    logger = logging.getLogger(__name__)


class SearchQuery(BaseModel):
    """검색 쿼리 스키마"""
    query: str = Field(description="검색할 키워드")
    research_goal: str = Field(description="이 검색의 연구 목적")


class SearchQueriesResponse(BaseModel):
    """검색 쿼리 응답 스키마"""
    queries: List[SearchQuery] = Field(description="생성된 검색 쿼리 목록")


class ResearchLearnings(BaseModel):
    """연구 학습 내용 스키마"""
    learnings: List[str] = Field(description="학습된 내용 목록")
    follow_up_questions: List[str] = Field(description="후속 연구 질문 목록")


class ResearchResult(BaseModel):
    """딥리서치 결과"""
    learnings: List[str]
    visited_urls: List[str]

def generate_search_queries(
    query: str,
    model: ChatOpenAI,
    num_queries: int = 3,
    learnings: Optional[List[str]] = None,
) -> List[SearchQuery]:
    """
    사용자의 쿼리를 바탕으로 검색 쿼리를 생성합니다.
    """

    current_date = datetime.now().strftime("%Y년 %m월 %d일")
    current_year = datetime.now().year
    
    prompt = f"""
    현재 날짜: {current_date} (연도: {current_year})
    
    다음 연구 주제를 조사하기 위한 검색 쿼리를 생성하세요.
    최대 {num_queries}개의 검색 쿼리를 생성하며, 각 쿼리는 고유하고 구체적이어야 합니다.
    
    중요한 지침:
    - 현재 연도는 {current_year}입니다
    - 시간에 민감한 정보의 경우 반드시 최신 정보를 검색하도록 하세요
    
    연구 주제: {query}
    """
    
    if learnings:
        prompt += f"\n\n이전 연구에서 얻은 학습 내용:\n{chr(10).join(learnings)}\n\n이를 바탕으로 더 구체적인 검색 쿼리를 생성하세요."
    
    try:
        structured_model = model.with_structured_output(SearchQueriesResponse)
        response = structured_model.invoke(prompt)
        
        if response and response.queries:
            logger.info(f"검색 쿼리 {len(response.queries)}개 생성됨")
            return response.queries[:num_queries]
        else:
            return []
            
    except Exception as e:
        logger.error(f"오류: 검색 쿼리 생성 중 문제 발생: {e}")
        return []


def process_search_results(
    query: str,
    search_results: str,
    model: ChatOpenAI,
    num_learnings: int = 5,
    num_follow_up_questions: int = 3,
) -> Dict[str, List[str]]:
    """
    검색 결과를 처리하여 학습 내용과 후속 질문을 추출합니다.
    
    Args:
        query: 검색 쿼리
        search_results: 검색 결과 JSON 문자열
        model: OpenAI 모델
        num_learnings: 추출할 학습 내용 개수
        num_follow_up_questions: 생성할 후속 질문 개수
        
    Returns:
        학습 내용과 후속 질문을 포함한 딕셔너리
    """
    try:
        logger.info(f"처리할 검색 결과 (첫 200자): {search_results[:200]}...")
        
        # JSON 문자열을 파싱 - 다양한 형태 지원
        results = []
        
        # 빈 문자열이나 None 체크
        if not search_results or not search_results.strip():
            logger.warning("검색 결과가 비어있습니다")
            return {"learnings": [], "follow_up_questions": []}
        
        search_results_trimmed = search_results.strip()
        
        try:
            if search_results_trimmed.startswith('['):
                # JSON 배열 형태
                results = json.loads(search_results_trimmed)
                if not isinstance(results, list):
                    results = [results]
            elif search_results_trimmed.startswith('{'):
                # 단일 JSON 객체 형태
                single_result = json.loads(search_results_trimmed)
                results = [single_result]
            else:
                # 일반 텍스트인 경우 직접 처리
                logger.info("JSON이 아닌 텍스트 형태의 검색 결과")
                results = [{"content": search_results_trimmed, "url": "", "title": "Text Result"}]
        except json.JSONDecodeError as json_error:
            logger.warning(f"초기 JSON 파싱 실패: {json_error}, 텍스트로 처리")
            # 여러 JSON 객체가 연결된 경우를 처리하려고 시도
            try:
                # 줄바꿈으로 분리된 JSON 객체들을 처리
                lines = search_results_trimmed.split('\n')
                results = []
                for line in lines:
                    line = line.strip()
                    if line and (line.startswith('[') or line.startswith('{')):
                        try:
                            parsed_line = json.loads(line)
                            if isinstance(parsed_line, list):
                                results.extend(parsed_line)
                            else:
                                results.append(parsed_line)
                        except json.JSONDecodeError:
                            continue
                
                if not results:
                    # 여전히 파싱할 수 없으면 텍스트로 처리
                    results = [{"content": search_results_trimmed, "url": "", "title": "Text Result"}]
                else:
                    logger.info(f"여러 JSON 객체 파싱 성공: {len(results)}개")
            except Exception as fallback_error:
                logger.warning(f"JSON 파싱 폴백도 실패: {fallback_error}, 최종 텍스트 처리")
                results = [{"content": search_results_trimmed, "url": "", "title": "Text Result"}]
        
        logger.info(f"파싱된 결과 수: {len(results)}")
        
        # 검색 결과 내용 추출
        contents = []
        for idx, result in enumerate(results):
            content = ""
            # 다양한 키에서 내용 추출 시도
            if isinstance(result, dict):
                content = result.get("content", "") or result.get("snippet", "") or result.get("description", "") or result.get("title", "")
            elif isinstance(result, str):
                content = result
            
            if content and len(content.strip()) > 0:
                contents.append(content[:1000])  # 각 결과를 1000자로 제한
                logger.info(f"결과 {idx+1} 추가: {content[:100]}...")
        
        if not contents:
            logger.info("유효한 검색 결과 내용이 없음")
            return {"learnings": [], "follow_up_questions": []}
        
        logger.info(f"처리할 내용 수: {len(contents)}")
        contents_str = "\n\n".join(f"<검색결과 {i+1}>\n{content}\n</검색결과>" for i, content in enumerate(contents))
        
        prompt = f"""
        다음은 검색 쿼리 "{query}"에 대한 검색 결과입니다.
        이 내용을 바탕으로 다음을 추출하세요:
        
        1. 핵심 학습 내용 (최대 {num_learnings}개)
        2. 후속 연구 질문 (최대 {num_follow_up_questions}개)
        
        각 학습 내용은 구체적이고 유용한 정보를 포함해야 합니다.
        후속 질문은 더 깊이 있는 연구를 위한 질문이어야 합니다.
        
        검색 결과:
        {contents_str}
        """
        
        structured_model = model.with_structured_output(ResearchLearnings)
        response = structured_model.invoke(prompt)
        
        if response and response.learnings:
            logger.info(f"추출된 학습 내용: {len(response.learnings)}개")
            logger.info(f"추출된 후속 질문: {len(response.follow_up_questions)}개")
            return {
                "learnings": response.learnings[:num_learnings],
                "follow_up_questions": response.follow_up_questions[:num_follow_up_questions],
            }
        else:
            logger.info("LLM이 학습 내용을 추출하지 못함")
            return {"learnings": [], "follow_up_questions": []}
            
    except json.JSONDecodeError as e:
        logger.error(f"JSON 파싱 오류: {e}")
        logger.error(f"파싱 실패한 내용: {search_results[:500]}...")
        # JSON 파싱 실패 시 텍스트로 직접 처리
        try:
            contents_str = f"<검색결과>\n{search_results[:2000]}\n</검색결과>"
            
            prompt = f"""
            다음은 검색 쿼리 "{query}"에 대한 검색 결과입니다.
            이 내용을 바탕으로 다음을 추출하세요:
            
            1. 핵심 학습 내용 (최대 {num_learnings}개)
            2. 후속 연구 질문 (최대 {num_follow_up_questions}개)
            
            검색 결과:
            {contents_str}
            """
            
            structured_model = model.with_structured_output(ResearchLearnings)
            response = structured_model.invoke(prompt)
            
            if response and response.learnings:
                return {
                    "learnings": response.learnings[:num_learnings],
                    "follow_up_questions": response.follow_up_questions[:num_follow_up_questions],
                }
        except Exception as fallback_e:
            logger.error(f"폴백 처리도 실패: {fallback_e}")
        
        return {"learnings": [], "follow_up_questions": []}
    except Exception as e:
        logger.error(f"오류: 검색 결과 처리 중 문제 발생: {e}")
        import traceback
        traceback.print_exc()
        return {"learnings": [], "follow_up_questions": []}


def deep_research(
    query: str,
    tools: List[BaseTool],
    model: ChatOpenAI,
    breadth: int = 2,
    depth: int = 2,
    learnings: Optional[List[str]] = None,
    visited_urls: Optional[List[str]] = None,
) -> ResearchResult:
    """
    재귀적 딥리서치를 수행합니다.
    
    Args:
        query: 연구 주제
        tools: 사용할 도구 목록 (웹 검색, 뉴스 검색 등)
        model: OpenAI 모델
        breadth: 연구 폭 (각 단계에서 생성할 쿼리 수)
        depth: 연구 깊이 (재귀 깊이)
        learnings: 기존 학습 내용
        visited_urls: 방문한 URL 목록
        
    Returns:
        딥리서치 결과
    """
    learnings = learnings or []
    visited_urls = visited_urls or []
    
    logger.info(f"\n=== 딥리서치 시작 (깊이: {depth}) ===")
    logger.info(f"연구 주제: {query}")
    
    # 검색 쿼리 생성
    search_queries = generate_search_queries(
        query=query,
        model=model,
        num_queries=breadth,
        learnings=learnings
    )
    
    logger.info(f"생성된 검색 쿼리: {len(search_queries)}개")
    
    for idx, search_query in enumerate(search_queries, 1):
        logger.info(f"\n--- 검색 {idx}: {search_query.query} ---")
        
        # 각 도구로 검색 수행
        all_search_results = []
        new_urls = []
        
        for tool in tools:
            try:
                # 도구 실행
                result = tool.invoke(search_query.query)
                if result:
                    # 결과 타입 확인 및 변환
                    if isinstance(result, list):
                        # 리스트인 경우 문자열로 변환
                        result_str = json.dumps(result, ensure_ascii=False)
                        all_search_results.append(result_str)
                        logger.info(f"도구 '{tool.name}' 실행 완료, 결과 길이: {len(result_str)} (리스트 변환)")
                        
                        # 리스트에서 URL 추출
                        for item in result:
                            if isinstance(item, dict):
                                url = item.get("url") or item.get("link") or item.get("source")
                                if url and url.strip():
                                    new_urls.append(url.strip())
                                    logger.info(f"URL 추출: {url}")
                    elif isinstance(result, str):
                        all_search_results.append(result)
                        logger.info(f"도구 '{tool.name}' 실행 완료, 결과 길이: {len(result)}")
                        
                        # 문자열에서 URL 추출 시도
                        try:
                            parsed_result = json.loads(result)
                            if isinstance(parsed_result, list):
                                for item in parsed_result:
                                    if isinstance(item, dict):
                                        url = item.get("url") or item.get("link") or item.get("source")
                                        if url and url.strip():
                                            new_urls.append(url.strip())
                                            logger.info(f"URL 추출: {url}")
                            elif isinstance(parsed_result, dict):
                                url = parsed_result.get("url") or parsed_result.get("link") or parsed_result.get("source")
                                if url and url.strip():
                                    new_urls.append(url.strip())
                                    logger.info(f"URL 추출: {url}")
                        except json.JSONDecodeError:
                            logger.info(f"도구 '{tool.name}' 결과는 JSON이 아님 (텍스트 결과)")
                            # JSON이 아닌 경우 URL 패턴 찾기
                            import re
                            url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
                            urls_found = re.findall(url_pattern, result)
                            new_urls.extend(urls_found)
                            logger.info(f"텍스트에서 URL {len(urls_found)}개 추출")
                    else:
                        # 기타 타입인 경우 문자열로 변환
                        result_str = str(result)
                        all_search_results.append(result_str)
                        logger.info(f"도구 '{tool.name}' 실행 완료, 결과 길이: {len(result_str)} (기타 타입 변환)")
                        
            except Exception as e:
                logger.error(f"도구 '{tool.name}' 실행 오류: {e}")
                continue
        
        # 검색 결과 통합 - JSON 배열들을 올바르게 병합
        if all_search_results:
            # 모든 JSON 문자열을 파싱하여 단일 배열로 병합
            combined_json_results = []
            
            for result in all_search_results:
                try:
                    if isinstance(result, str):
                        # JSON 문자열을 파싱
                        parsed_result = json.loads(result)
                        if isinstance(parsed_result, list):
                            combined_json_results.extend(parsed_result)
                        elif isinstance(parsed_result, dict):
                            combined_json_results.append(parsed_result)
                        else:
                            # JSON이 아닌 문자열인 경우 텍스트 결과로 처리
                            combined_json_results.append({
                                "title": "Text Result",
                                "url": "",
                                "content": str(parsed_result),
                                "score": 0.5
                            })
                    else:
                        # 문자열이 아닌 경우 텍스트로 변환
                        combined_json_results.append({
                            "title": "Non-JSON Result",
                            "url": "",
                            "content": str(result),
                            "score": 0.5
                        })
                except json.JSONDecodeError as e:
                    logger.warning(f"JSON 파싱 실패한 결과를 텍스트로 처리: {str(e)[:100]}")
                    # JSON 파싱 실패 시 텍스트 결과로 처리
                    combined_json_results.append({
                        "title": "Text Result",
                        "url": "",
                        "content": str(result)[:2000],  # 내용 길이 제한
                        "score": 0.5
                    })
                except Exception as e:
                    logger.error(f"결과 처리 중 오류: {e}")
                    continue
            
            # 통합된 결과를 JSON 문자열로 변환
            if combined_json_results:
                combined_results = json.dumps(combined_json_results, ensure_ascii=False)
                logger.info(f"통합된 검색 결과: {len(combined_json_results)}개")
            else:
                logger.warning("통합할 수 있는 검색 결과가 없습니다")
                combined_results = "[]"
            
            # 검색 결과 처리
            search_result = process_search_results(
                query=search_query.query,
                search_results=combined_results,
                model=model,
                num_follow_up_questions=breadth
            )
            
            logger.info(f"학습 내용 {len(search_result['learnings'])}개 추출")
            logger.info(f"새로운 URL {len(new_urls)}개 발견")
            
            # 결과 누적
            all_learnings = learnings + search_result["learnings"]
            all_urls = visited_urls + new_urls
            
            # 재귀적 딥리서치 (깊이가 남아있으면)
            if depth > 1 and search_result["follow_up_questions"]:
                next_query = f"이전 연구 목표: {search_query.research_goal}\n후속 연구 방향: {' '.join(search_result['follow_up_questions'])}"
                
                sub_result = deep_research(
                    query=next_query,
                    tools=tools,
                    model=model,
                    breadth=max(1, breadth // 2),  # 폭을 줄여서 재귀
                    depth=depth - 1,
                    learnings=all_learnings,
                    visited_urls=all_urls,
                )
                
                learnings = sub_result.learnings
                visited_urls = sub_result.visited_urls
            else:
                learnings = all_learnings
                visited_urls = all_urls
        else:
            logger.warning(f"검색 {idx}에서 유효한 결과가 없습니다.")
    
    # 중복 제거
    unique_learnings = list(dict.fromkeys(learnings))
    unique_urls = list(dict.fromkeys(visited_urls))
    
    logger.info(f"\n=== 딥리서치 완료 ===")
    logger.info(f"총 학습 내용: {len(unique_learnings)}개")
    logger.info(f"총 방문 URL: {len(unique_urls)}개")
    
    return ResearchResult(
        learnings=unique_learnings,
        visited_urls=unique_urls
    ) 