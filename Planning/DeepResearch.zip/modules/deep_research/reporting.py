from typing import List
from langchain_openai import ChatOpenAI
from datetime import datetime

# 로거 설정
try:
    from logging_config import get_logger
    logger = get_logger(__name__)
except ImportError:
    import logging
    logger = logging.getLogger(__name__)


def generate_final_report(
    query: str,
    learnings: List[str],
    visited_urls: List[str],
    model: ChatOpenAI,
) -> str:
    """
    딥리서치 결과를 바탕으로 최종 보고서를 생성합니다.
    
    Args:
        query: 연구 주제
        learnings: 학습 내용 목록
        visited_urls: 방문한 URL 목록
        model: OpenAI 모델
        
    Returns:
        마크다운 형식의 최종 보고서
    """
    
    # 현재 날짜
    current_date = datetime.now().strftime("%Y년 %m월 %d일")
    
    logger.info(f"보고서 생성 시작 - 학습 내용: {len(learnings)}개, URL: {len(visited_urls)}개")
    
    # 학습 내용과 URL 유효성 검사
    valid_learnings = [learning.strip() for learning in learnings if learning and learning.strip()]
    valid_urls = [url.strip() for url in visited_urls if url and url.strip()]
    
    logger.info(f"유효한 학습 내용: {len(valid_learnings)}개, 유효한 URL: {len(valid_urls)}개")
    
    # 학습 내용이 없는 경우 기본 보고서 생성
    if not valid_learnings:
        logger.info("학습 내용이 없음 - 기본 보고서 생성")
        report_header = f"""# 딥리서치 보고서

**연구 주제:** {query}  
**작성일:** {current_date}  
**총 참조 자료:** {len(valid_urls)}개  
**학습 내용:** 0개  

---

## 연구 결과

현재 연구 과정에서 충분한 학습 내용을 수집하지 못했습니다.

**가능한 원인:**
- 검색 도구의 연결 문제
- 검색 쿼리의 부적절성
- 외부 데이터 소스의 일시적 문제

**권장 사항:**
1. 검색 키워드를 더 구체적으로 변경해 보세요
2. 다른 시간에 다시 시도해 보세요
3. 네트워크 연결 상태를 확인해 보세요

"""
        
        if valid_urls:
            report_header += f"\n## 참조된 자료 출처\n\n"
            for i, url in enumerate(valid_urls, 1):
                report_header += f"[{i}] {url}  \n"
        
        return report_header
    
    # 학습 내용 정리
    learnings_text = ""
    for i, learning in enumerate(valid_learnings, 1):
        learnings_text += f"{i}. {learning}\n"
    
    # 출처 정리
    sources_text = ""
    for i, url in enumerate(valid_urls, 1):
        sources_text += f"[{i}] {url}\n"
    
    # 보고서 길이 조정 (학습 내용에 따라)
    min_length = max(3000, len(valid_learnings) * 500)  # 학습 내용당 최소 500자
    
    prompt = f"""
    다음 정보를 바탕으로 전문적이고 상세한 연구 보고서를 작성하세요.
    
    **연구 주제:** {query}
    
    **학습 내용 ({len(valid_learnings)}개):**
    {learnings_text}
    
    **보고서 작성 지침:**
    1. 마크다운 형식으로 작성
    2. 최소 {min_length}자 이상의 상세한 보고서
    3. 다음 구조를 따라 작성:
       - 제목 및 서론
       - 주요 발견 사항 (섹션별로 구분)
       - 종합 분석 및 토론
       - 결론 및 제언
    4. 학습 내용의 모든 정보를 활용
    5. 전문적이고 객관적인 톤으로 작성
    6. 각 섹션은 충분한 설명과 근거를 포함
    7. 번호가 매겨진 참조([1], [2] 등)를 사용하여 정보의 출처를 명시
    
    **주의사항:**
    - 학습 내용에 없는 정보는 추가하지 말 것
    - 모든 중요한 학습 내용을 보고서에 포함할 것
    - 논리적이고 체계적인 구성으로 작성할 것
    - 한국어로 작성할 것
    - 각 학습 내용을 충분히 설명하고 분석할 것
    
    보고서를 작성하세요.
    """
    
    try:
        logger.info("LLM을 사용하여 보고서 생성 중...")
        
        # 보고서 생성
        response = model.invoke(prompt)
        report_content = response.content
        
        # 출처 섹션 추가
        if valid_urls:
            report_content += f"\n\n## 출처\n\n"
            for i, url in enumerate(valid_urls, 1):
                report_content += f"[{i}] {url}  \n"
        
        # 메타데이터 추가
        report_header = f"""# 딥리서치 보고서

**연구 주제:** {query}  
**작성일:** {current_date}  
**총 참조 자료:** {len(valid_urls)}개  
**학습 내용:** {len(valid_learnings)}개  

---

"""
        
        final_report = report_header + report_content
        
        logger.info(f"보고서 생성 완료 (총 {len(final_report)}자)")
        return final_report
        
    except Exception as e:
        logger.error(f"오류: 보고서 생성 중 문제 발생: {e}")
        import traceback
        traceback.print_exc()
        
        # 오류 발생 시 기본 보고서 생성
        error_report = f"""# 딥리서치 보고서

**연구 주제:** {query}  
**작성일:** {current_date}  
**총 참조 자료:** {len(valid_urls)}개  
**학습 내용:** {len(valid_learnings)}개  

---

## 보고서 생성 오류

보고서 생성 중 오류가 발생했습니다: {str(e)}

### 수집된 학습 내용:

{learnings_text if learnings_text else "학습 내용이 없습니다."}

"""
        
        if valid_urls:
            error_report += f"\n### 참조 자료:\n\n"
            for i, url in enumerate(valid_urls, 1):
                error_report += f"[{i}] {url}  \n"
        
        return error_report 