import streamlit as st

# DB 로깅 import
try:
    from db_logger import log_search, log_agent_action
    DB_LOGGING_AVAILABLE = True
except ImportError:
    DB_LOGGING_AVAILABLE = False


def get_current_tool_message(tool_args, tool_call_id):
    """
    Get the tool message corresponding to the given tool call ID.

    Args:
        tool_args (list): List of tool arguments
        tool_call_id (str): ID of the tool call to find

    Returns:
        dict: Tool message if found, None otherwise
    """
    if tool_call_id:
        for tool_arg in tool_args:
            if tool_arg["tool_call_id"] == tool_call_id:
                return tool_arg
        return None
    else:
        return None


def format_search_result(results):
    """
    Format search results into a markdown string.

    Args:
        results (str): JSON string containing search results or plain text

    Returns:
        str: Formatted markdown string with search results
    """
    import json
    
    try:
        # Try to parse as JSON (for web search results)
        parsed_results = json.loads(results)

        answer = ""
        for result in parsed_results:
            answer += f'**[{result["title"]}]({result["url"]})**\n\n'
            answer += f'{result["content"]}\n\n'
            answer += f'신뢰도: {result["score"]}\n\n'
            answer += "\n-----\n"
        return answer
    except (json.JSONDecodeError, TypeError):
        # If not JSON, return as plain text (for RAG results)
        return results


def stream_handler(streamlit_container, agent_executor, inputs, config):
    """
    Handle streaming of agent execution results in a Streamlit container.

    Args:
        streamlit_container (streamlit.container): Streamlit container to display results
        agent_executor: Agent executor instance
        inputs: Input data for the agent
        config: Configuration settings

    Returns:
        tuple: (container, tool_args, agent_answer)
            - container: Streamlit container with displayed results
            - tool_args: List of tool arguments used
            - agent_answer: Final answer from the agent
    """
    
    def get_session_id():
        """세션 ID 가져오기"""
        if "thread_id" not in st.session_state:
            from langchain_utils.messages import random_uuid
            st.session_state["thread_id"] = random_uuid()
        return st.session_state["thread_id"]
    # Initialize result storage
    tool_args = []
    agent_answer = ""
    agent_message = None  # Pre-declare agent_message variable

    container = streamlit_container.container()
    with container:
        for chunk_msg, metadata in agent_executor.stream(
            inputs, config, stream_mode="messages"
        ):
            if hasattr(chunk_msg, "tool_calls") and chunk_msg.tool_calls:
                # Initialize tool call result
                tool_arg = {
                    "tool_name": "",
                    "tool_result": "",
                    "tool_call_id": chunk_msg.tool_calls[0]["id"],
                }
                # Save tool name
                tool_arg["tool_name"] = chunk_msg.tool_calls[0]["name"]
                if tool_arg["tool_name"]:
                    tool_args.append(tool_arg)

            if hasattr(chunk_msg, "tool_call_chunks") and chunk_msg.tool_call_chunks:
                if len(chunk_msg.tool_call_chunks) > 0:  # Add None check
                    # Accumulate tool call arguments
                    chunk_msg.tool_call_chunks[0]["args"]

            if metadata["langgraph_node"] == "tools":
                # Save tool execution results
                current_tool_message = get_current_tool_message(
                    tool_args, chunk_msg.tool_call_id
                )
                if current_tool_message:
                    current_tool_message["tool_result"] = chunk_msg.content
                    with st.status(f'✅ {current_tool_message["tool_name"]}'):
                        # Format results for both web search and RAG tools
                        formatted_result = format_search_result(
                                    current_tool_message["tool_result"]
                                )
                        st.markdown(formatted_result)
                        
                        # DB 로깅 추가
                        if DB_LOGGING_AVAILABLE:
                            try:
                                import json
                                session_id = get_session_id()
                                tool_name = current_tool_message["tool_name"]
                                
                                # 검색 타입 결정
                                search_type = "unknown"
                                if "web" in tool_name.lower():
                                    search_type = "web"
                                elif "news" in tool_name.lower():
                                    search_type = "news"
                                elif "rag" in tool_name.lower():
                                    search_type = "rag"
                                
                                # 검색 쿼리 추출 (inputs에서)
                                query = inputs.get("input", "") if isinstance(inputs, dict) else str(inputs)
                                
                                # 결과 파싱 시도
                                try:
                                    parsed_results = json.loads(current_tool_message["tool_result"])
                                    results_data = {"results": parsed_results, "formatted": formatted_result}
                                except:
                                    results_data = {"raw_result": current_tool_message["tool_result"], "formatted": formatted_result}
                                
                                # 검색 로그 저장
                                log_search(
                                    session_id=session_id,
                                    search_type=search_type,
                                    query=query,
                                    results=results_data,
                                    metadata={"tool_call_id": chunk_msg.tool_call_id}
                                )
                                
                            except Exception as e:
                                print(f"검색 로깅 실패: {e}")

            if metadata["langgraph_node"] == "agent":
                if chunk_msg.content:
                    if agent_message is None:
                        agent_message = st.empty()
                    # Accumulate agent message
                    agent_answer += chunk_msg.content
                    agent_message.markdown(agent_answer)

        return container, tool_args, agent_answer
