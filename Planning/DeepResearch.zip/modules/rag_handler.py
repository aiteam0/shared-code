"""
RAG 통합 핸들러
문서 RAG와 이미지 RAG를 통합하여 처리하는 모듈
"""

from typing import List, Dict, Any, Optional, Tuple
from langchain_core.messages import HumanMessage
from langchain_core.tools import BaseTool, tool
from langchain_core.runnables import RunnableConfig

from modules.document_rag import DocumentRAG
from modules.image_rag import ImageRAG
from logging_config import get_logger

logger = get_logger(__name__)


class RAGHandler:
    """문서와 이미지 RAG를 통합 처리하는 클래스"""
    
    def __init__(self, model_name: str = "gpt-4o"):
        """
        Args:
            model_name: 사용할 LLM 모델명
        """
        self.model_name = model_name
        self.document_rag: Optional[DocumentRAG] = None
        self.image_rag: Optional[ImageRAG] = None
        self.has_documents = False
        self.has_images = False
        # 파일 개수 추적
        self._document_count = 0
        self._image_count = 0
        logger.info(f"RAGHandler 초기화 완료 - model: {model_name}")
    
    def initialize_document_rag(self):
        """문서 RAG 초기화"""
        if not self.document_rag:
            self.document_rag = DocumentRAG()
            logger.info("DocumentRAG 초기화 완료")
    
    def initialize_image_rag(self):
        """이미지 RAG 초기화"""
        if not self.image_rag:
            self.image_rag = ImageRAG(model_name=self.model_name)
            logger.info("ImageRAG 초기화 완료")
    
    def process_documents(self, uploaded_files, reset_existing: bool = False) -> int:
        """
        문서 파일들을 처리하고 인덱싱
        
        Args:
            uploaded_files: 업로드된 문서 파일들
            reset_existing: 기존 벡터스토어를 초기화할지 여부 (기본값: False - 보존)
            
        Returns:
            int: 처리된 문서 청크 수
        """
        try:
            self.initialize_document_rag()
            chunk_count = self.document_rag.process_and_index_files(uploaded_files, reset_existing=reset_existing)
            self.has_documents = chunk_count > 0
            # 문서 파일 개수 업데이트
            if reset_existing:
                self._document_count = len(uploaded_files) if uploaded_files else 0
            else:
                # 기존 데이터 보존 시 파일 개수 누적
                self._document_count += len(uploaded_files) if uploaded_files else 0
            logger.info(f"문서 처리 완료: {len(uploaded_files)}개 파일, {chunk_count}개 청크 (기존 데이터 {'초기화' if reset_existing else '보존'})")
            return chunk_count
        except Exception as e:
            logger.error(f"문서 처리 중 오류: {e}", exc_info=True)
            raise e
    
    def process_images(self, uploaded_files, query: str = None) -> List[Dict[str, str]]:
        """
        이미지 파일들을 처리하고 분석
        
        Args:
            uploaded_files: 업로드된 이미지 파일들
            query: 이미지 분석을 위한 특정 질문
            
        Returns:
            List[Dict[str, str]]: 이미지 분석 결과 리스트
        """
        try:
            self.initialize_image_rag()
            results = self.image_rag.process_multiple_images(uploaded_files, query)
            self.has_images = len(results) > 0
            # 이미지 파일 개수 업데이트
            self._image_count = len(uploaded_files) if uploaded_files else 0
            logger.info(f"이미지 처리 완료: {len(uploaded_files)}개 파일")
            return results
        except Exception as e:
            logger.error(f"이미지 처리 중 오류: {e}", exc_info=True)
            raise e
    
    def get_context_for_query(self, query: str) -> Tuple[str, str]:
        """
        쿼리에 대한 문서와 이미지 컨텍스트를 모두 검색
        
        Args:
            query: 검색 쿼리
            
        Returns:
            Tuple[str, str]: (문서 컨텍스트, 이미지 컨텍스트)
        """
        doc_context = ""
        img_context = ""
        
        try:
            # 문서 컨텍스트 검색
            if self.has_documents and self.document_rag:
                doc_context = self.document_rag.get_context_for_query(query)
                logger.info(f"문서 컨텍스트 검색 완료: {len(doc_context)} 문자")
            
            # 이미지 컨텍스트 검색
            if self.has_images and self.image_rag:
                img_context = self.image_rag.get_image_context_for_query(query)
                logger.info(f"이미지 컨텍스트 검색 완료: {len(img_context)} 문자")
                
        except Exception as e:
            logger.error(f"컨텍스트 검색 중 오류: {e}", exc_info=True)
        
        return doc_context, img_context
    
    def create_enhanced_message(self, user_query: str) -> str:
        """
        사용자 쿼리에 RAG 컨텍스트를 추가한 향상된 메시지 생성
        
        Args:
            user_query: 사용자의 원래 질문
            
        Returns:
            str: 컨텍스트가 추가된 향상된 질문
        """
        try:
            doc_context, img_context = self.get_context_for_query(user_query)
            
            # 컨텍스트가 있는 경우에만 향상된 메시지 생성
            if not doc_context and not img_context:
                return user_query
            
            enhanced_message = f"사용자 질문: {user_query}\n\n"
            
            if doc_context:
                enhanced_message += f"=== 관련 문서 정보 ===\n{doc_context}\n\n"
            
            if img_context:
                enhanced_message += f"=== 관련 이미지 정보 ===\n{img_context}\n\n"
            
            enhanced_message += """위의 문서와 이미지 정보를 참고하여 사용자의 질문에 답변해주세요. 
관련 정보가 있다면 어떤 문서나 이미지에서 가져온 정보인지 명시해주세요.
관련 정보가 없다면 일반적인 지식으로 답변해주세요."""
            
            logger.info(f"향상된 메시지 생성 완료: {len(enhanced_message)} 문자")
            return enhanced_message
            
        except Exception as e:
            logger.error(f"향상된 메시지 생성 중 오류: {e}", exc_info=True)
            return user_query
    
    def get_status(self) -> Dict[str, Any]:
        """
        현재 RAG 상태 정보 반환
        
        Returns:
            Dict[str, Any]: 상태 정보
        """
        status = {
            "has_documents": self.has_documents,
            "has_images": self.has_images,
            "document_count": 0,
            "image_count": 0
        }
        
        try:
            if self.document_rag and self.document_rag.vectorstore:
                # 벡터스토어의 문서 수를 정확히 가져오기는 어려우므로 추정
                status["document_count"] = "인덱싱됨"
            
            if self.image_rag:
                status["image_count"] = len(self.image_rag.processed_images)
                
        except Exception as e:
            logger.error(f"상태 정보 조회 중 오류: {e}")
        
        return status
    
    def clear_all(self):
        """모든 RAG 데이터 초기화"""
        try:
            logger.info("RAG 데이터 완전 초기화 시작")
            
            # 문서 RAG 완전 초기화 (인스턴스 삭제)
            if self.document_rag:
                try:
                    # 벡터스토어가 있다면 정리 시도
                    if hasattr(self.document_rag, 'vectorstore') and self.document_rag.vectorstore:
                        del self.document_rag.vectorstore
                except Exception as e:
                    logger.warning(f"벡터스토어 정리 중 오류 (무시됨): {e}")
                
                self.document_rag = None
                logger.info("DocumentRAG 인스턴스 삭제 완료")
                
            # 이미지 RAG 완전 초기화
            if self.image_rag:
                try:
                    self.image_rag.clear_processed_images()
                    logger.info("ImageRAG 처리된 이미지 목록 초기화 완료")
                except Exception as e:
                    logger.warning(f"이미지 목록 정리 중 오류 (무시됨): {e}")
                
                self.image_rag = None
                logger.info("ImageRAG 인스턴스 삭제 완료")
            
            # 상태 플래그 초기화
            self.has_documents = False
            self.has_images = False
            # 파일 개수도 초기화
            self._document_count = 0
            self._image_count = 0
            
            logger.info("RAG 데이터 완전 초기화 완료")
            
        except Exception as e:
            logger.error(f"RAG 데이터 초기화 중 오류: {e}", exc_info=True)
            # 오류가 발생해도 강제로 상태를 초기화
            self.document_rag = None
            self.image_rag = None
            self.has_documents = False
            self.has_images = False
            # 파일 개수도 강제 초기화
            self._document_count = 0
            self._image_count = 0
            logger.warning("오류 발생으로 인한 강제 초기화 완료")


class RAGTool(BaseTool):
    """RAG 검색을 위한 도구"""
    
    name: str = "rag_search"
    description: str = "업로드된 문서와 이미지에서 관련 정보를 검색합니다. 문서와 이미지에 대해 물어보는 모든 사용자 질문은 이 Tool을 사용합니다."
    rag_handler: RAGHandler
    
    def __init__(self, rag_handler: RAGHandler):
        super().__init__(rag_handler=rag_handler)
    
    def _run(self, query: str) -> str:
        """RAG 검색 실행"""
        try:
            doc_context, img_context = self.rag_handler.get_context_for_query(query)
            
            if not doc_context and not img_context:
                return "업로드된 문서나 이미지에서 관련 정보를 찾을 수 없습니다."
            
            result = f"검색 결과:\n\n"
            
            if doc_context:
                result += f"📄 문서 정보:\n{doc_context}\n\n"
            
            if img_context:
                result += f"🖼️ 이미지 정보:\n{img_context}\n\n"
            
            return result
            
        except Exception as e:
            logger.error(f"RAG 검색 중 오류: {e}", exc_info=True)
            return f"검색 중 오류가 발생했습니다: {str(e)}"


def create_rag_handler(model_name: str = "gpt-4o") -> RAGHandler:
    """RAGHandler 인스턴스 생성 팩토리 함수"""
    return RAGHandler(model_name=model_name)


def create_rag_tool(rag_handler: RAGHandler) -> RAGTool:
    """RAGTool 인스턴스 생성 팩토리 함수"""
    return RAGTool(rag_handler=rag_handler) 