import streamlit as st
from typing import Dict, Any, List, Tuple
from .deep_research_agent import DeepResearchAgent
from logging_config import get_logger
import os

logger = get_logger(__name__)


def deep_research_stream_handler(
    streamlit_container,
    agent: DeepResearchAgent,
    query: str,
    breadth: int = 2,
    depth: int = 2,
    feedback_answers: List[str] = None
) -> Tuple[str, Dict[str, Any]]:
    """
    딥리서치를 스트리밍 방식으로 실행하고 결과를 Streamlit에 표시합니다.
    
    Args:
        streamlit_container: Streamlit 컨테이너
        agent: 딥리서치 에이전트
        query: 연구 주제
        breadth: 연구 폭
        depth: 연구 깊이
        feedback_answers: 피드백 답변 목록
        
    Returns:
        (최종_보고서, 딥리서치_결과) 튜플
    """
    logger.info(f"딥리서치 스트리밍 시작 - 질문: {query[:100]}...")
    logger.info(f"딥리서치 파라미터 - breadth: {breadth}, depth: {depth}")
    
    if feedback_answers:
        logger.info(f"피드백 답변 수: {len(feedback_answers)}")
    
    final_report = ""
    research_result = {"learnings": [], "visited_urls": []}
    current_step = "initial"
    
    try:
        with streamlit_container:
            # 진행 상황 표시
            progress_placeholder = st.empty()
            status_placeholder = st.empty()
            result_placeholder = st.empty()
            
            # 딥리서치 스트리밍 실행 - values와 updates 모드를 모두 사용
            stream_completed = False
            step_count = 0
            max_steps = 10  # 무한 루프 방지
            
            for chunk in agent.stream_research(
                query=query,
                breadth=breadth,
                depth=depth,
                feedback_answers=feedback_answers
            ):
                step_count += 1
                if step_count > max_steps:
                    logger.warning(f"최대 스트리밍 단계 수({max_steps})를 초과했습니다.")
                    break
                
                # 에러 처리
                if "error" in chunk:
                    error_msg = chunk['error'].get('error_message', '알 수 없는 오류')
                    logger.error(f"딥리서치 실행 중 오류: {error_msg}")
                    status_placeholder.error(f"❌ 오류 발생: {error_msg}")
                    current_step = "error"
                    break
                
                # 각 노드별 처리
                for node_name, node_result in chunk.items():
                    logger.info(f"노드 '{node_name}' 처리 중 - 결과 타입: {type(node_result)}")
                    
                    # 상태 업데이트 표시
                    if node_name == "generate_feedback":
                        current_step = "feedback_generated"
                        progress_placeholder.progress(0.2)
                        status_placeholder.info("🤔 피드백 질문을 생성하는 중...")
                        
                    elif node_name == "conduct_research":
                        current_step = "research_completed"
                        progress_placeholder.progress(0.6)
                        status_placeholder.info("🔍 딥리서치를 수행하는 중...")
                        
                        # 연구 결과 처리
                        if isinstance(node_result, dict):
                            research_data = node_result.get("research_result", {})
                            if isinstance(research_data, dict):
                                learnings = research_data.get("learnings", [])
                                visited_urls = research_data.get("visited_urls", [])
                                
                                # 결과 유효성 검증
                                if isinstance(learnings, list):
                                    research_result["learnings"] = learnings
                                else:
                                    logger.warning(f"학습 내용이 리스트가 아님: {type(learnings)}")
                                    research_result["learnings"] = []
                                
                                if isinstance(visited_urls, list):
                                    research_result["visited_urls"] = visited_urls
                                else:
                                    logger.warning(f"방문 URL이 리스트가 아님: {type(visited_urls)}")
                                    research_result["visited_urls"] = []
                                
                                logger.info(f"연구 결과 - 학습내용: {len(research_result['learnings'])}개, 참조자료: {len(research_result['visited_urls'])}개")
                        
                        # 중간 결과 표시
                        with result_placeholder.container():
                            st.subheader("🧠 학습 내용")
                            learnings = research_result.get("learnings", [])
                            if learnings:
                                for i, learning in enumerate(learnings, 1):
                                    if learning and learning.strip():  # 빈 학습 내용 제외
                                        st.write(f"**{i}.** {learning}")
                            else:
                                st.info("📝 학습 내용이 아직 생성되지 않았습니다.")
                            
                            st.subheader("🔗 참조 자료")
                            visited_urls = research_result.get("visited_urls", [])
                            if visited_urls:
                                st.write(f"**참조 자료 ({len(visited_urls)}개):**")
                                for i, url in enumerate(visited_urls, 1):
                                    if url and url.strip():  # 빈 URL 제외
                                        st.write(f"[{i}] {url}")
                            else:
                                st.info("🔗 참조 자료가 아직 수집되지 않았습니다.")
                            
                            # 연구 진행 상태 표시
                            if not learnings and not visited_urls:
                                st.warning("⚠️ 연구 결과가 없습니다. 검색 도구의 연결 상태를 확인해 주세요.")
                                # 디버깅 정보 표시
                                with st.expander("🔧 디버깅 정보", expanded=False):
                                    st.write("**노드 결과:**")
                                    st.json(node_result)
                            elif learnings and not visited_urls:
                                st.info("📝 학습 내용은 생성되었지만 참조 자료가 없습니다.")
                            elif not learnings and visited_urls:
                                st.info("🔗 참조 자료는 수집되었지만 학습 내용이 생성되지 않았습니다.")
                        
                    elif node_name == "generate_report":
                        current_step = "report_completed"
                        progress_placeholder.progress(1.0)
                        status_placeholder.success("📋 최종 보고서를 생성하는 중...")
                        
                        # 최종 보고서 처리
                        if isinstance(node_result, dict):
                            final_report = node_result.get("final_report", "")
                            if final_report:
                                logger.info(f"최종 보고서 생성 완료 - 길이: {len(final_report)} 문자")
                            else:
                                logger.warning("최종 보고서가 비어있습니다.")
                                final_report = "# 보고서 생성 실패\n\n연구 결과를 보고서로 변환하는 중 문제가 발생했습니다."
                        
                        stream_completed = True
                        
            # 스트리밍 완료 후 처리
            if stream_completed:
                status_placeholder.success("✅ 딥리서치가 완료되었습니다!")
                logger.info("딥리서치 1단계: 연구 수행 완료 (피드백 건너뜀)")
            elif current_step == "error":
                logger.error("딥리서치가 오류로 인해 중단되었습니다.")
            else:
                logger.warning("딥리서치 스트리밍이 예상보다 일찍 종료되었습니다.")
                status_placeholder.warning("⚠️ 딥리서치가 불완전하게 종료되었습니다.")
                
                # 부분적 결과라도 보고서 생성 시도
                if research_result.get("learnings") or research_result.get("visited_urls"):
                    try:
                        from modules.deep_research import generate_final_report
                        from langchain_openai import ChatOpenAI
                        
                        model = ChatOpenAI(model="gpt-4o")
                        final_report = generate_final_report(
                            query=query,
                            learnings=research_result.get("learnings", []),
                            visited_urls=research_result.get("visited_urls", []),
                            model=model
                        )
                        logger.info("부분적 결과로 보고서를 생성했습니다.")
                    except Exception as e:
                        logger.error(f"부분 보고서 생성 실패: {e}")
                        final_report = "# 부분 연구 결과\n\n연구가 완전히 완료되지 않았지만 수집된 정보를 정리했습니다."
            
            # 최종 결과 로깅
            logger.info(f"연구 결과 - 학습내용: {len(research_result.get('learnings', []))}개, 참조자료: {len(research_result.get('visited_urls', []))}개")
            
            return final_report, research_result
    
    except Exception as e:
        logger.error(f"딥리서치 스트리밍 핸들러 오류: {e}")
        import traceback
        traceback.print_exc()
        
        # streamlit_container가 유효한 경우에만 사용
        try:
            with streamlit_container:
                st.error(f"❌ 딥리서치 실행 중 오류가 발생했습니다: {str(e)}")
                
                # 오류 상세 정보 (개발용)
                with st.expander("🔧 오류 상세 정보", expanded=False):
                    st.text(traceback.format_exc())
        except Exception as container_error:
            logger.error(f"streamlit_container 사용 중 오류: {container_error}")
            # container 사용이 실패하면 직접 streamlit 사용
            st.error(f"❌ 딥리서치 실행 중 오류가 발생했습니다: {str(e)}")
            with st.expander("🔧 오류 상세 정보", expanded=False):
                st.text(traceback.format_exc())
        
        return f"# 딥리서치 실행 실패\n\n오류: {str(e)}", {"learnings": [], "visited_urls": []}


def show_feedback_questions_ui(feedback_questions: List[str]) -> List[str]:
    """
    피드백 질문 UI 표시 및 답변 수집
    
    Args:
        feedback_questions: 피드백 질문 목록
        
    Returns:
        사용자의 답변 목록
    """
    
    if not feedback_questions:
        return []
    
    st.write("### 🤔 추가 질문에 답변해 주세요")
    st.write("더 정확한 리서치를 위해 다음 질문들에 답변해 주세요:")
    
    answers = []
    
    for i, question in enumerate(feedback_questions, 1):
        st.write(f"**질문 {i}:** {question}")
        answer = st.text_input(
            f"답변 {i}:",
            key=f"feedback_answer_{i}",
            placeholder="답변을 입력하세요..."
        )
        answers.append(answer)
    
    return answers 