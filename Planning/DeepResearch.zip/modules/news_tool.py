import json
import logging
from typing import Any, List, Optional
from langchain_core.tools import BaseTool as LangChainBaseTool
from langchain_utils.tools.news import GoogleNews
from .base import BaseTool

# 로거 설정
try:
    from logging_config import get_logger
    logger = get_logger(__name__)
except ImportError:
    logger = logging.getLogger(__name__)

class EnhancedNewsSearchTool(BaseTool[LangChainBaseTool]):
    """Kiwi 형태소 분석기를 활용한 향상된 뉴스 검색 도구 클래스"""

    def __init__(
        self,
        max_results: int = 3,
        search_type: str = "keyword",  # "keyword" or "latest"
        use_morphological_analysis: bool = True,
        optimize_query: bool = True,
    ):
        """EnhancedNewsSearchTool 초기화 메서드"""
        logger.info(f"EnhancedNewsSearchTool 초기화 - max_results: {max_results}, "
                   f"search_type: {search_type}, morphological_analysis: {use_morphological_analysis}")
        super().__init__()
        self.max_results = max_results
        self.search_type = search_type
        self.use_morphological_analysis = use_morphological_analysis
        self.optimize_query = optimize_query
        
        try:
            self.google_news = GoogleNews(
                use_morphological_analysis=use_morphological_analysis
            )
            
            # 분석기 정보 로깅
            analysis_info = self.google_news.get_analysis_info()
            logger.info(f"Kiwi 분석기 상태: {analysis_info}")
            
        except Exception as e:
            logger.error(f"EnhancedGoogleNews 인스턴스 생성 실패: {e}")
            raise

    def _create_tool(self) -> LangChainBaseTool:
        """EnhancedNewsSearcher 도구를 생성하고 설정하는 내부 메서드"""
        logger.info("EnhancedNewsSearcher 도구 생성 시작")
        
        class EnhancedNewsSearcher(LangChainBaseTool):
            name: str = "news_search"
            description: str = """Search for recent news articles and current events. 
            This tool is specifically designed for finding latest news, breaking news, current events, and recent updates. 
            It provides more accurate and up-to-date news content compared to general web search.
            Use this tool when users ask about news, current events, recent happenings, or when you need the most recent information."""
            
            max_results: int = 3
            search_type: str = "keyword"
            optimize_query: bool = True
            google_news: GoogleNews = None

            def __init__(self, max_results: int, search_type: str, optimize_query: bool, google_news: GoogleNews):
                # 부모 클래스 초기화를 먼저 수행 (필드와 함께)
                super().__init__(
                    max_results=max_results,
                    search_type=search_type,
                    optimize_query=optimize_query,
                    google_news=google_news
                )
                logger.info(f"EnhancedNewsSearcher 초기화 완료 - max_results: {max_results}, "
                           f"search_type: {search_type}, optimize_query: {optimize_query}")

            def _run(self, query: str = None) -> str:
                """향상된 뉴스 검색 실행"""
                logger.info(f"향상된 뉴스 검색 실행 - query: '{query}', search_type: {self.search_type}")
                
                try:
                    # 쿼리 최적화 정보 로깅
                    if query and self.optimize_query and self.google_news.use_morphological_analysis:
                        keywords = self.google_news.extract_keywords(query)
                        optimized_query = self.google_news.create_optimized_query(query)
                        logger.info(f"키워드 추출 결과: {keywords}")
                        logger.info(f"최적화된 쿼리: '{query}' -> '{optimized_query}'")
                    
                    if self.search_type == "latest":
                        logger.info("최신 뉴스 검색 실행")
                        results = self.google_news.search_latest(k=self.max_results)
                    else:
                        logger.info(f"키워드 뉴스 검색 실행 - keyword: '{query}'")
                        results = self.google_news.search_by_keyword(
                            keyword=query, 
                            k=self.max_results,
                            optimize_query=self.optimize_query
                        )
                    
                    logger.info(f"검색 결과 수: {len(results) if results else 0}")
                    
                    if not results:
                        logger.warning("검색 결과가 없습니다")
                        return json.dumps([{
                            "title": "No news found", 
                            "url": "", 
                            "content": "No news articles found for the given query.", 
                            "score": 0.0,
                            "analysis_used": self.google_news.use_morphological_analysis
                        }])
                    
                    # 결과를 검색 도구와 동일한 형식으로 변환하면서 분석 정보 추가
                    formatted_results = []
                    """
                    result.append({"url": news["link"], "content": news["title"] /n "published": news["published"], "summary": news["summary"]})

                    """
                    for i, result in enumerate(results):
                        logger.debug(f"결과 {i+1} 처리: {result.get('url', 'No URL')}")
                        
                        formatted_result = {
                            "title": result.get("content", ""),  # content가 제목 역할
                            "url": result.get("url", ""),
                            #"published": result.get("published", ""),
                            #"summary": result.get("summary", ""),
                            "content": f'published : {result.get("published", "")} \n\n summary : {result.get("summary", "")}',   # content를 본문으로도 사용
                            "score": 0.8,  # 기본 신뢰도 점수
                            "source_type": "NEWS",  # 추가
                            "recency": "CURRENT",   # 추가
                            "priority": "HIGH",     # 추가
                            "analysis_used": self.google_news.use_morphological_analysis
                        }
                        
                        # 첫 번째 결과에 키워드 분석 정보 추가
                        if i == 0 and query and self.google_news.use_morphological_analysis:
                            keywords = self.google_news.extract_keywords(query)
                            formatted_result["extracted_keywords"] = keywords
                            formatted_result["original_query"] = query
                            formatted_result["optimized_query"] = self.google_news.create_optimized_query(query)
                        
                        formatted_results.append(formatted_result)
                    
                    logger.info(f"향상된 뉴스 검색 완료 - {len(formatted_results)}개 결과 반환")
                    return json.dumps(formatted_results, ensure_ascii=False, indent=2)
                    
                except Exception as e:
                    logger.error(f"향상된 뉴스 검색 중 오류 발생: {str(e)}", exc_info=True)
                    return json.dumps([{
                        "title": "Error", 
                        "url": "", 
                        "content": f"Error occurred during enhanced news search: {str(e)}", 
                        "score": 0.0,
                        "analysis_used": False
                    }])

            async def _arun(self, query: str = None) -> str:
                """비동기 향상된 뉴스 검색 실행"""
                logger.info(f"비동기 향상된 뉴스 검색 실행 - query: '{query}'")
                return self._run(query)

        try:
            enhanced_news_searcher = EnhancedNewsSearcher(
                max_results=self.max_results,
                search_type=self.search_type,
                optimize_query=self.optimize_query,
                google_news=self.google_news
            )
            enhanced_news_searcher.name = "news_search"
            logger.info("EnhancedNewsSearcher 인스턴스 생성 완료")
            return enhanced_news_searcher
        except Exception as e:
            logger.error(f"EnhancedNewsSearcher 생성 실패: {e}", exc_info=True)
            raise

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """도구를 실행하는 메서드"""
        logger.info(f"EnhancedNewsSearchTool 호출 - args: {args}, kwargs: {kwargs}")
        tool = self._create_tool()
        return tool(*args, **kwargs)


# 기존 NewsSearchTool과의 호환성을 위한 별칭 및 래퍼
class NewsSearchTool(EnhancedNewsSearchTool):
    """기존 NewsSearchTool과 호환되는 래퍼 클래스"""
    
    def __init__(
        self,
        max_results: int = 3,
        search_type: str = "keyword",
    ):
        # 기본적으로 형태소 분석 기능을 활성화
        super().__init__(
            max_results=max_results,
            search_type=search_type,
            use_morphological_analysis=True,
            optimize_query=True
        )


# 사용 예제
if __name__ == "__main__":
    # 향상된 뉴스 검색 도구 생성
    enhanced_tool = EnhancedNewsSearchTool(
        max_results=5,
        use_morphological_analysis=True,
        optimize_query=True
    )
    
    # 도구 정보 출력
    print("=== 도구 정보 ===")
    tool_info = enhanced_tool.get_tool_info()
    for key, value in tool_info.items():
        print(f"{key}: {value}")
    print()
    
    # LangChain 도구 생성
    news_tool = enhanced_tool.create()
    
    # 검색 테스트
    print("=== 검색 테스트 ===")
    test_queries = [
        "삼성전자의 주가가 상승했습니다",
        "한국 정부의 부동산 정책 발표"
    ]
    
    for query in test_queries:
        print(f"\n검색 쿼리: '{query}'")
        print("-" * 50)
        
        try:
            result = news_tool.invoke(query)
            
            # JSON 결과 파싱하여 보기 좋게 출력
            import json
            parsed_result = json.loads(result)
            
            for i, article in enumerate(parsed_result, 1):
                print(f"{i}. {article.get('title', 'No Title')}")
                if 'extracted_keywords' in article:
                    print(f"   추출 키워드: {article['extracted_keywords']}")
                if 'optimized_query' in article:
                    print(f"   최적화 쿼리: {article['optimized_query']}")
                print(f"   분석기 사용: {article.get('analysis_used', False)}")
                print(f"   URL: {article.get('url', 'No URL')}")
                print()
                
        except Exception as e:
            print(f"검색 중 오류 발생: {e}")
    
    print("\n=== 기존 방식과 비교 ===")
    # 기존 방식 (형태소 분석 없음)
    basic_tool = EnhancedNewsSearchTool(
        max_results=3,
        use_morphological_analysis=False,
        optimize_query=False
    )
    
    basic_news_tool = basic_tool.create()
    query = "삼성전자의 주가가 상승했습니다"
    
    print(f"테스트 쿼리: '{query}'")
    print("\n[기존 방식 - 형태소 분석 없음]")
    try:
        result = basic_news_tool.invoke(query)
        parsed = json.loads(result)
        print(f"결과 수: {len(parsed)}")
        for i, article in enumerate(parsed, 1):
            print(f"{i}. {article.get('title', 'No Title')[:50]}...")
    except Exception as e:
        print(f"오류: {e}")
    
    print("\n[향상된 방식 - Kiwi 형태소 분석]")
    try:
        result = news_tool.invoke(query)
        parsed = json.loads(result)
        print(f"결과 수: {len(parsed)}")
        for i, article in enumerate(parsed, 1):
            print(f"{i}. {article.get('title', 'No Title')[:50]}...")
            if i == 1:  # 첫 번째 결과에서 키워드 정보 표시
                if 'extracted_keywords' in article:
                    print(f"   키워드: {article['extracted_keywords']}")
                if 'optimized_query' in article:
                    print(f"   최적화: {article['optimized_query']}")
    except Exception as e:
        print(f"오류: {e}")