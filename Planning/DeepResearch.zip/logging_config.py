import logging
import sys
from pathlib import Path
from typing import Optional
import os

# DB 로깅 모듈 import
try:
    from db_logger import init_database, log_system_event, is_db_logging_enabled, get_db_info
    DB_LOGGER_AVAILABLE = True
except ImportError:
    DB_LOGGER_AVAILABLE = False
    print("DB 로깅 모듈을 사용할 수 없습니다. SQLAlchemy가 설치되어 있는지 확인하세요.")


class DatabaseLogHandler(logging.Handler):
    """데이터베이스에 로그를 저장하는 커스텀 핸들러"""
    
    def __init__(self, session_id: Optional[str] = None):
        super().__init__()
        self.session_id = session_id
    
    def emit(self, record):
        """로그 레코드를 데이터베이스에 저장"""
        if not DB_LOGGER_AVAILABLE or not is_db_logging_enabled():
            return
        
        try:
            # 로그 메시지 포맷팅
            message = self.format(record)
            
            # 메타데이터 수집
            metadata = {
                "filename": record.filename,
                "lineno": record.lineno,
                "funcName": record.funcName,
                "pathname": record.pathname,
                "process": record.process,
                "thread": record.thread,
                "threadName": record.threadName
            }
            
            # 예외 정보가 있으면 추가
            if record.exc_info:
                metadata["exc_info"] = str(record.exc_info)
            
            # 데이터베이스에 로그 저장
            log_system_event(
                log_level=record.levelname,
                module=record.name,
                message=message,
                session_id=self.session_id,
                metadata=metadata
            )
            
        except Exception:
            # 로깅 중 오류가 발생해도 애플리케이션을 중단시키지 않음
            pass
    
    def set_session_id(self, session_id: str):
        """세션 ID 설정"""
        self.session_id = session_id

def setup_logging(
    level: str = "INFO",
    log_to_file: bool = True,
    log_file_path: Optional[str] = None,
    format_string: Optional[str] = None,
    init_db_logging: bool = True
) -> logging.Logger:
    """
    프로젝트 전체에서 사용할 logging 설정
    
    Args:
        level: 로깅 레벨 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_to_file: 파일에 로그를 저장할지 여부
        log_file_path: 로그 파일 경로 (None이면 자동 생성)
        format_string: 커스텀 포맷 문자열
        init_db_logging: DB 로깅 초기화 여부
    
    Returns:
        설정된 root logger
    """
    
    # 로깅 레벨 설정
    log_level = getattr(logging, level.upper(), logging.INFO)
    
    # 기본 포맷 설정
    if format_string is None:
        format_string = (
            '%(asctime)s - %(name)s - %(levelname)s - '
            '%(filename)s:%(lineno)d - %(funcName)s - %(message)s'
        )
    
    # 기존 핸들러 제거 (중복 방지)
    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    # 포매터 생성
    formatter = logging.Formatter(format_string)
    
    # 콘솔 핸들러 설정
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(log_level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    
    # 파일 핸들러 설정
    if log_to_file:
        if log_file_path is None:
            # logs 디렉토리 생성
            log_dir = Path("logs")
            log_dir.mkdir(exist_ok=True)
            log_file_path = log_dir / "deep_research.log"
        
        file_handler = logging.FileHandler(log_file_path, encoding='utf-8')
        file_handler.setLevel(log_level)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)
    
    # 루트 로거 레벨 설정
    root_logger.setLevel(log_level)
    
    # 특정 라이브러리의 로깅 레벨 조정 (노이즈 감소)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    
    # DB 로깅 초기화
    if init_db_logging and DB_LOGGER_AVAILABLE:
        try:
            init_database()
            root_logger.info("데이터베이스 로깅 시스템이 초기화되었습니다.")
            
            # DB 정보 로깅
            db_info = get_db_info()
            root_logger.info(f"DB 로깅 설정: {db_info}")
            
        except Exception as e:
            root_logger.warning(f"데이터베이스 로깅 초기화 실패: {e}")
    elif init_db_logging and not DB_LOGGER_AVAILABLE:
        root_logger.warning("DB 로깅 모듈을 사용할 수 없습니다.")
    
    return root_logger

def get_logger(name: str) -> logging.Logger:
    """
    특정 모듈용 로거 생성
    
    Args:
        name: 로거 이름 (보통 __name__ 사용)
    
    Returns:
        설정된 로거
    """
    return logging.getLogger(name)


def add_db_handler_to_logger(logger: logging.Logger, session_id: Optional[str] = None) -> Optional[DatabaseLogHandler]:
    """
    로거에 데이터베이스 핸들러 추가
    
    Args:
        logger: 대상 로거
        session_id: 세션 식별자
    
    Returns:
        추가된 DatabaseLogHandler (실패 시 None)
    """
    if not DB_LOGGER_AVAILABLE:
        return None
    
    try:
        db_handler = DatabaseLogHandler(session_id)
        db_handler.setLevel(logging.INFO)  # DB에는 INFO 레벨 이상만 저장
        
        # 간단한 포맷 설정 (DB에는 상세 정보가 메타데이터로 저장됨)
        formatter = logging.Formatter('%(message)s')
        db_handler.setFormatter(formatter)
        
        logger.addHandler(db_handler)
        return db_handler
        
    except Exception as e:
        print(f"DB 핸들러 추가 실패: {e}")
        return None


def remove_db_handlers_from_logger(logger: logging.Logger):
    """로거에서 데이터베이스 핸들러 제거"""
    handlers_to_remove = [h for h in logger.handlers if isinstance(h, DatabaseLogHandler)]
    for handler in handlers_to_remove:
        logger.removeHandler(handler)

# 환경 변수로 로깅 레벨 설정 가능
DEFAULT_LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

# 개발/운영 환경 구분
IS_DEVELOPMENT = os.getenv("ENVIRONMENT", "development").lower() == "development"

if __name__ == "__main__":
    # 테스트용 로깅 설정
    logger = setup_logging(
        level=DEFAULT_LOG_LEVEL,
        log_to_file=True
    )
    
    test_logger = get_logger(__name__)
    test_logger.debug("Debug 메시지 테스트")
    test_logger.info("Info 메시지 테스트")
    test_logger.warning("Warning 메시지 테스트")
    test_logger.error("Error 메시지 테스트")
    
    print("로깅 설정이 완료되었습니다.") 