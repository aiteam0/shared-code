"""
데이터베이스 로깅 함수들

사용자-에이전트 상호작용을 데이터베이스에 로깅하는 함수들을 제공합니다.
"""

import time
from datetime import datetime
from typing import Optional, Dict, Any, List
from contextlib import contextmanager

from sqlalchemy.orm import Session
from sqlalchemy import desc, and_

from .database import get_db_session, is_db_logging_enabled
from .models import Conversation, SearchLog, AgentAction, SystemLog


def log_conversation(
    session_id: str,
    role: str,
    content: str,
    mode: str = "NORMAL_CHAT",
    user_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> Optional[int]:
    """
    대화 내역을 데이터베이스에 로깅
    
    Args:
        session_id: 세션 식별자
        role: 역할 (user, assistant, system)
        content: 메시지 내용
        mode: 모드 (NORMAL_CHAT, DEEP_RESEARCH, RAG)
        user_id: 사용자 식별자 (선택적)
        metadata: 추가 메타데이터
    
    Returns:
        생성된 레코드의 ID (로깅 비활성화 시 None)
    """
    if not is_db_logging_enabled():
        return None
    
    try:
        with get_db_session() as session:
            if session is None:
                return None
                
            conversation = Conversation(
                session_id=session_id,
                user_id=user_id,
                mode=mode,
                role=role,
                content=content,
                metadata=metadata
            )
            
            session.add(conversation)
            session.flush()  # ID 생성을 위해 flush
            return conversation.id
            
    except Exception as e:
        print(f"대화 로깅 실패: {e}")
        return None


def log_search(
    session_id: str,
    search_type: str,
    query: str,
    results: Optional[Dict[str, Any]] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> Optional[int]:
    """
    검색 로그를 데이터베이스에 저장
    
    Args:
        session_id: 세션 식별자
        search_type: 검색 타입 (web, news, rag, etc.)
        query: 검색 쿼리
        results: 검색 결과
        metadata: 추가 메타데이터
    
    Returns:
        생성된 레코드의 ID (로깅 비활성화 시 None)
    """
    if not is_db_logging_enabled():
        return None
    
    try:
        with get_db_session() as session:
            if session is None:
                return None
                
            search_log = SearchLog(
                session_id=session_id,
                search_type=search_type,
                query=query,
                results=results,
                metadata=metadata
            )
            
            session.add(search_log)
            session.flush()
            return search_log.id
            
    except Exception as e:
        print(f"검색 로깅 실패: {e}")
        return None


def log_agent_action(
    session_id: str,
    action_type: str,
    tool_name: Optional[str] = None,
    input_data: Optional[Dict[str, Any]] = None,
    output_data: Optional[Dict[str, Any]] = None,
    duration: Optional[float] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> Optional[int]:
    """
    에이전트 행동을 데이터베이스에 로깅
    
    Args:
        session_id: 세션 식별자
        action_type: 행동 타입 (tool_use, state_change, etc.)
        tool_name: 사용된 도구명
        input_data: 입력 데이터
        output_data: 출력 데이터
        duration: 실행 시간 (초)
        metadata: 추가 메타데이터
    
    Returns:
        생성된 레코드의 ID (로깅 비활성화 시 None)
    """
    if not is_db_logging_enabled():
        return None
    
    try:
        with get_db_session() as session:
            if session is None:
                return None
                
            agent_action = AgentAction(
                session_id=session_id,
                action_type=action_type,
                tool_name=tool_name,
                input_data=input_data,
                output_data=output_data,
                duration=duration,
                metadata=metadata
            )
            
            session.add(agent_action)
            session.flush()
            return agent_action.id
            
    except Exception as e:
        print(f"에이전트 행동 로깅 실패: {e}")
        return None


def log_system_event(
    log_level: str,
    module: str,
    message: str,
    session_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> Optional[int]:
    """
    시스템 이벤트를 데이터베이스에 로깅
    
    Args:
        log_level: 로그 레벨 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        module: 모듈명
        message: 로그 메시지
        session_id: 세션 식별자 (선택적)
        metadata: 추가 메타데이터
    
    Returns:
        생성된 레코드의 ID (로깅 비활성화 시 None)
    """
    if not is_db_logging_enabled():
        return None
    
    try:
        with get_db_session() as session:
            if session is None:
                return None
                
            system_log = SystemLog(
                session_id=session_id,
                log_level=log_level,
                module=module,
                message=message,
                metadata=metadata
            )
            
            session.add(system_log)
            session.flush()
            return system_log.id
            
    except Exception as e:
        print(f"시스템 로깅 실패: {e}")
        return None


@contextmanager
def log_agent_action_with_timing(
    session_id: str,
    action_type: str,
    tool_name: Optional[str] = None,
    input_data: Optional[Dict[str, Any]] = None,
    metadata: Optional[Dict[str, Any]] = None
):
    """
    실행 시간을 자동으로 측정하여 에이전트 행동을 로깅하는 컨텍스트 매니저
    
    Usage:
        with log_agent_action_with_timing(session_id, "tool_use", "web_search", {"query": "test"}) as logger:
            # 작업 수행
            result = perform_search()
            logger.set_output(result)
    """
    start_time = time.time()
    output_data = None
    
    class ActionLogger:
        def set_output(self, data: Dict[str, Any]):
            nonlocal output_data
            output_data = data
    
    logger = ActionLogger()
    
    try:
        yield logger
    finally:
        duration = time.time() - start_time
        log_agent_action(
            session_id=session_id,
            action_type=action_type,
            tool_name=tool_name,
            input_data=input_data,
            output_data=output_data,
            duration=duration,
            metadata=metadata
        )


# 조회 함수들

def get_session_conversations(
    session_id: str,
    limit: Optional[int] = None,
    offset: int = 0
) -> List[Dict[str, Any]]:
    """세션의 대화 내역 조회"""
    if not is_db_logging_enabled():
        return []
    
    try:
        with get_db_session() as session:
            if session is None:
                return []
                
            query = session.query(Conversation).filter(
                Conversation.session_id == session_id
            ).order_by(Conversation.timestamp)
            
            if limit:
                query = query.limit(limit).offset(offset)
            
            conversations = query.all()
            return [conv.to_dict() for conv in conversations]
            
    except Exception as e:
        print(f"대화 내역 조회 실패: {e}")
        return []


def get_search_history(
    session_id: str,
    search_type: Optional[str] = None,
    limit: Optional[int] = None
) -> List[Dict[str, Any]]:
    """검색 이력 조회"""
    if not is_db_logging_enabled():
        return []
    
    try:
        with get_db_session() as session:
            if session is None:
                return []
                
            query = session.query(SearchLog).filter(
                SearchLog.session_id == session_id
            )
            
            if search_type:
                query = query.filter(SearchLog.search_type == search_type)
            
            query = query.order_by(desc(SearchLog.timestamp))
            
            if limit:
                query = query.limit(limit)
            
            searches = query.all()
            return [search.to_dict() for search in searches]
            
    except Exception as e:
        print(f"검색 이력 조회 실패: {e}")
        return []


def get_agent_actions(
    session_id: str,
    action_type: Optional[str] = None,
    tool_name: Optional[str] = None,
    limit: Optional[int] = None
) -> List[Dict[str, Any]]:
    """에이전트 행동 이력 조회"""
    if not is_db_logging_enabled():
        return []
    
    try:
        with get_db_session() as session:
            if session is None:
                return []
                
            query = session.query(AgentAction).filter(
                AgentAction.session_id == session_id
            )
            
            if action_type:
                query = query.filter(AgentAction.action_type == action_type)
            
            if tool_name:
                query = query.filter(AgentAction.tool_name == tool_name)
            
            query = query.order_by(desc(AgentAction.timestamp))
            
            if limit:
                query = query.limit(limit)
            
            actions = query.all()
            return [action.to_dict() for action in actions]
            
    except Exception as e:
        print(f"에이전트 행동 조회 실패: {e}")
        return []


def get_session_summary(session_id: str) -> Dict[str, Any]:
    """세션 요약 정보 조회"""
    if not is_db_logging_enabled():
        return {}
    
    try:
        with get_db_session() as session:
            if session is None:
                return {}
            
            # 대화 수
            conversation_count = session.query(Conversation).filter(
                Conversation.session_id == session_id
            ).count()
            
            # 검색 수
            search_count = session.query(SearchLog).filter(
                SearchLog.session_id == session_id
            ).count()
            
            # 에이전트 행동 수
            action_count = session.query(AgentAction).filter(
                AgentAction.session_id == session_id
            ).count()
            
            # 첫 번째와 마지막 활동 시간
            first_activity = session.query(Conversation.timestamp).filter(
                Conversation.session_id == session_id
            ).order_by(Conversation.timestamp).first()
            
            last_activity = session.query(Conversation.timestamp).filter(
                Conversation.session_id == session_id
            ).order_by(desc(Conversation.timestamp)).first()
            
            return {
                "session_id": session_id,
                "conversation_count": conversation_count,
                "search_count": search_count,
                "action_count": action_count,
                "first_activity": first_activity[0].isoformat() if first_activity else None,
                "last_activity": last_activity[0].isoformat() if last_activity else None
            }
            
    except Exception as e:
        print(f"세션 요약 조회 실패: {e}")
        return {} 