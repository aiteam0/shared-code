"""
데이터베이스 모델 정의

사용자-에이전트 상호작용 로깅을 위한 SQLAlchemy 모델들
"""

from datetime import datetime
from typing import Optional, Dict, Any
import json

from sqlalchemy import Column, Integer, String, Text, DateTime, JSON, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func

Base = declarative_base()


class Conversation(Base):
    """대화 내역 테이블"""
    __tablename__ = 'conversations'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String(255), nullable=False, index=True)
    user_id = Column(String(255), nullable=True, index=True)
    mode = Column(String(50), nullable=False)  # NORMAL_CHAT, DEEP_RESEARCH, RAG
    timestamp = Column(DateTime, default=func.now(), nullable=False)
    role = Column(String(20), nullable=False)  # user, assistant, system
    content = Column(Text, nullable=False)
    meta_data = Column(JSON, nullable=True)
    
    def __repr__(self):
        return f"<Conversation(id={self.id}, session_id='{self.session_id}', role='{self.role}')>"
    
    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환"""
        return {
            'id': self.id,
            'session_id': self.session_id,
            'user_id': self.user_id,
            'mode': self.mode,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'role': self.role,
            'content': self.content,
            'metadata': self.meta_data
        }


class SearchLog(Base):
    """검색 로그 테이블"""
    __tablename__ = 'search_logs'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String(255), nullable=False, index=True)
    search_type = Column(String(50), nullable=False)  # web, news, rag, etc.
    query = Column(Text, nullable=False)
    results = Column(JSON, nullable=True)
    timestamp = Column(DateTime, default=func.now(), nullable=False)
    meta_data = Column(JSON, nullable=True)
    
    def __repr__(self):
        return f"<SearchLog(id={self.id}, session_id='{self.session_id}', search_type='{self.search_type}')>"
    
    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환"""
        return {
            'id': self.id,
            'session_id': self.session_id,
            'search_type': self.search_type,
            'query': self.query,
            'results': self.results,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'metadata': self.meta_data
        }


class AgentAction(Base):
    """에이전트 행동 로그 테이블"""
    __tablename__ = 'agent_actions'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String(255), nullable=False, index=True)
    action_type = Column(String(100), nullable=False)  # tool_use, state_change, etc.
    tool_name = Column(String(100), nullable=True)
    input_data = Column(JSON, nullable=True)
    output_data = Column(JSON, nullable=True)
    timestamp = Column(DateTime, default=func.now(), nullable=False)
    duration = Column(Float, nullable=True)  # 실행 시간 (초)
    meta_data = Column(JSON, nullable=True)
    
    def __repr__(self):
        return f"<AgentAction(id={self.id}, session_id='{self.session_id}', action_type='{self.action_type}')>"
    
    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환"""
        return {
            'id': self.id,
            'session_id': self.session_id,
            'action_type': self.action_type,
            'tool_name': self.tool_name,
            'input_data': self.input_data,
            'output_data': self.output_data,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'duration': self.duration,
            'metadata': self.meta_data
        }


class SystemLog(Base):
    """시스템 로그 테이블"""
    __tablename__ = 'system_logs'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String(255), nullable=True, index=True)
    log_level = Column(String(20), nullable=False)  # DEBUG, INFO, WARNING, ERROR, CRITICAL
    module = Column(String(100), nullable=False)
    message = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=func.now(), nullable=False)
    meta_data = Column(JSON, nullable=True)
    
    def __repr__(self):
        return f"<SystemLog(id={self.id}, log_level='{self.log_level}', module='{self.module}')>"
    
    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환"""
        return {
            'id': self.id,
            'session_id': self.session_id,
            'log_level': self.log_level,
            'module': self.module,
            'message': self.message,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'metadata': self.meta_data
        } 