"""
데이터베이스 연결 및 세션 관리

SQLite 데이터베이스 연결과 세션 관리를 담당합니다.
"""

import os
from pathlib import Path
from typing import Optional
from contextlib import contextmanager

from sqlalchemy import create_engine, Engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool

from .models import Base

# 전역 변수들
_engine: Optional[Engine] = None
_SessionLocal: Optional[sessionmaker] = None

# 기본 설정
DEFAULT_DB_PATH = "logs/interactions.db"
DB_LOGGING_ENABLED = os.getenv("DB_LOGGING_ENABLED", "true").lower() == "true"
DB_LOG_LEVEL = os.getenv("DB_LOG_LEVEL", "INFO")


def get_database_url(db_path: Optional[str] = None) -> str:
    """데이터베이스 URL 생성"""
    if db_path is None:
        db_path = os.getenv("DB_PATH", DEFAULT_DB_PATH)
    
    # 절대 경로로 변환
    db_path = Path(db_path).resolve()
    
    # 디렉토리 생성
    db_path.parent.mkdir(parents=True, exist_ok=True)
    
    return f"sqlite:///{db_path}"


def init_database(db_path: Optional[str] = None, echo: bool = False) -> Engine:
    """
    데이터베이스 초기화
    
    Args:
        db_path: 데이터베이스 파일 경로
        echo: SQL 쿼리 로깅 여부
    
    Returns:
        SQLAlchemy Engine 객체
    """
    global _engine, _SessionLocal
    
    if not DB_LOGGING_ENABLED:
        raise RuntimeError("DB 로깅이 비활성화되어 있습니다. DB_LOGGING_ENABLED=true로 설정하세요.")
    
    database_url = get_database_url(db_path)
    
    # SQLite 설정
    _engine = create_engine(
        database_url,
        echo=echo,
        poolclass=StaticPool,
        connect_args={
            "check_same_thread": False,  # SQLite 멀티스레드 지원
            "timeout": 20  # 20초 타임아웃
        }
    )
    
    # 테이블 생성
    Base.metadata.create_all(bind=_engine)
    
    # 세션 팩토리 생성
    _SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=_engine)
    
    return _engine


def get_engine() -> Engine:
    """현재 엔진 반환"""
    if _engine is None:
        init_database()
    return _engine


def get_session_factory() -> sessionmaker:
    """세션 팩토리 반환"""
    if _SessionLocal is None:
        init_database()
    return _SessionLocal


@contextmanager
def get_db_session():
    """
    데이터베이스 세션 컨텍스트 매니저
    
    Usage:
        with get_db_session() as session:
            # 데이터베이스 작업 수행
            session.add(obj)
            session.commit()
    """
    if not DB_LOGGING_ENABLED:
        # DB 로깅이 비활성화된 경우 None 반환
        yield None
        return
    
    session_factory = get_session_factory()
    session = session_factory()
    
    try:
        yield session
        session.commit()
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()


def is_db_logging_enabled() -> bool:
    """DB 로깅 활성화 여부 확인"""
    return DB_LOGGING_ENABLED


def get_db_info() -> dict:
    """데이터베이스 정보 반환"""
    return {
        "enabled": DB_LOGGING_ENABLED,
        "db_path": os.getenv("DB_PATH", DEFAULT_DB_PATH),
        "log_level": DB_LOG_LEVEL,
        "engine_initialized": _engine is not None
    }


# 초기화 함수 (선택적)
def auto_init_database():
    """자동 데이터베이스 초기화 (모듈 로드 시)"""
    if DB_LOGGING_ENABLED:
        try:
            init_database()
        except Exception as e:
            print(f"데이터베이스 자동 초기화 실패: {e}")


# 모듈 로드 시 자동 초기화 (선택적)
# auto_init_database() 