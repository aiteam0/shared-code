# 🗄️ DB 로깅 시스템

사용자와 에이전트 간의 모든 상호작용을 구조화된 형태로 데이터베이스에 저장하는 로깅 시스템입니다.

## 📋 주요 기능

- **대화 로깅**: 사용자-에이전트 간 모든 대화 내역 저장
- **검색 로깅**: 웹검색, 뉴스검색, RAG 검색 등 모든 검색 활동 기록
- **에이전트 행동 로깅**: 도구 사용, 상태 변화 등 에이전트의 모든 행동 추적
- **시스템 로깅**: 시스템 이벤트 및 오류 로그 저장
- **세션 추적**: 세션별 활동 내역 관리
- **데이터 조회**: 저장된 로그 데이터 조회 및 분석

## 🏗️ 아키텍처

```
db_logger/
├── __init__.py          # 모듈 초기화
├── models.py            # SQLAlchemy 모델 정의
├── database.py          # 데이터베이스 연결 관리
├── logger.py            # 로깅 함수들
└── README.md           # 사용법 가이드
```

### 데이터베이스 스키마

#### 1. conversations (대화 테이블)
- `id`: 기본키
- `session_id`: 세션 식별자
- `user_id`: 사용자 식별자 (선택적)
- `mode`: 모드 (NORMAL_CHAT, DEEP_RESEARCH, RAG)
- `timestamp`: 생성 시간
- `role`: 역할 (user, assistant, system)
- `content`: 메시지 내용
- `metadata`: 추가 메타데이터 (JSON)

#### 2. search_logs (검색 로그 테이블)
- `id`: 기본키
- `session_id`: 세션 식별자
- `search_type`: 검색 타입 (web, news, rag)
- `query`: 검색 쿼리
- `results`: 검색 결과 (JSON)
- `timestamp`: 생성 시간
- `metadata`: 추가 메타데이터 (JSON)

#### 3. agent_actions (에이전트 행동 테이블)
- `id`: 기본키
- `session_id`: 세션 식별자
- `action_type`: 행동 타입 (tool_use, state_change)
- `tool_name`: 사용된 도구명
- `input_data`: 입력 데이터 (JSON)
- `output_data`: 출력 데이터 (JSON)
- `timestamp`: 생성 시간
- `duration`: 실행 시간 (초)
- `metadata`: 추가 메타데이터 (JSON)

#### 4. system_logs (시스템 로그 테이블)
- `id`: 기본키
- `session_id`: 세션 식별자 (선택적)
- `log_level`: 로그 레벨 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
- `module`: 모듈명
- `message`: 로그 메시지
- `timestamp`: 생성 시간
- `metadata`: 추가 메타데이터 (JSON)

## 🚀 사용법

### 1. 환경 설정

```bash
# 환경 변수 설정 (.env 파일 또는 시스템 환경변수)
DB_LOGGING_ENABLED=true          # DB 로깅 활성화 (기본: true)
DB_PATH=logs/interactions.db     # 데이터베이스 파일 경로 (기본: logs/interactions.db)
DB_LOG_LEVEL=INFO               # DB 로깅 레벨 (기본: INFO)
```

### 2. 기본 사용법

```python
from db_logger import (
    init_database,
    log_conversation,
    log_search,
    log_agent_action,
    get_session_conversations
)

# 데이터베이스 초기화
init_database()

# 대화 로깅
log_conversation(
    session_id="session_123",
    role="user",
    content="안녕하세요!",
    mode="NORMAL_CHAT"
)

# 검색 로깅
log_search(
    session_id="session_123",
    search_type="web",
    query="AI 기술 동향",
    results={"results": [...]}
)

# 에이전트 행동 로깅
log_agent_action(
    session_id="session_123",
    action_type="tool_use",
    tool_name="web_search",
    input_data={"query": "AI 기술"},
    output_data={"results_count": 5},
    duration=2.5
)

# 데이터 조회
conversations = get_session_conversations("session_123")
```

### 3. 로깅 설정과 통합

```python
from logging_config import setup_logging, add_db_handler_to_logger

# 로깅 설정 (DB 로깅 포함)
logger = setup_logging(level="INFO", init_db_logging=True)

# 특정 로거에 DB 핸들러 추가
test_logger = get_logger("my_module")
db_handler = add_db_handler_to_logger(test_logger, "session_123")

# 이제 일반 로깅도 DB에 저장됨
test_logger.info("이 메시지는 파일과 DB 모두에 저장됩니다")
```

### 4. 실행 시간 측정과 함께 로깅

```python
from db_logger import log_agent_action_with_timing

# 컨텍스트 매니저를 사용한 자동 시간 측정
with log_agent_action_with_timing(
    session_id="session_123",
    action_type="tool_use",
    tool_name="web_search",
    input_data={"query": "test"}
) as logger:
    # 작업 수행
    result = perform_search()
    logger.set_output({"results": result})
# 실행 시간이 자동으로 측정되어 저장됨
```

## 🔧 설정 옵션

### 환경 변수

| 변수명 | 기본값 | 설명 |
|--------|--------|------|
| `DB_LOGGING_ENABLED` | `true` | DB 로깅 활성화 여부 |
| `DB_PATH` | `logs/interactions.db` | SQLite 데이터베이스 파일 경로 |
| `DB_LOG_LEVEL` | `INFO` | DB 로깅 레벨 |

### 프로그래밍 방식 설정

```python
from db_logger.database import init_database

# 커스텀 경로로 데이터베이스 초기화
engine = init_database(
    db_path="custom/path/my_logs.db",
    echo=True  # SQL 쿼리 로깅 활성화
)
```

## 📊 데이터 조회 및 분석

### 기본 조회 함수들

```python
from db_logger import (
    get_session_conversations,
    get_search_history,
    get_agent_actions,
    get_session_summary
)

# 세션의 모든 대화 조회
conversations = get_session_conversations("session_123")

# 검색 이력 조회 (특정 타입만)
web_searches = get_search_history("session_123", search_type="web")

# 에이전트 행동 조회 (특정 도구만)
web_actions = get_agent_actions("session_123", tool_name="web_search")

# 세션 요약 정보
summary = get_session_summary("session_123")
print(f"대화 수: {summary['conversation_count']}")
print(f"검색 수: {summary['search_count']}")
```

### 직접 SQL 쿼리

```python
from db_logger.database import get_db_session
from db_logger.models import Conversation, SearchLog

with get_db_session() as session:
    # 최근 24시간 대화 조회
    from datetime import datetime, timedelta
    yesterday = datetime.now() - timedelta(days=1)
    
    recent_conversations = session.query(Conversation).filter(
        Conversation.timestamp >= yesterday
    ).all()
    
    # 가장 많이 검색된 쿼리 TOP 10
    from sqlalchemy import func
    top_queries = session.query(
        SearchLog.query,
        func.count(SearchLog.id).label('count')
    ).group_by(SearchLog.query).order_by(
        func.count(SearchLog.id).desc()
    ).limit(10).all()
```

## 🧪 테스트

테스트 스크립트를 실행하여 시스템이 제대로 작동하는지 확인:

```bash
python test_db_logging.py
```

## 🔒 보안 고려사항

1. **데이터 암호화**: 민감한 데이터는 저장 전 암호화 고려
2. **접근 제어**: 데이터베이스 파일에 대한 적절한 권한 설정
3. **데이터 보존**: 개인정보 보호 정책에 따른 데이터 보존 기간 설정
4. **백업**: 정기적인 데이터베이스 백업

## 🚀 확장성

### PostgreSQL로 마이그레이션

SQLite에서 PostgreSQL로 쉽게 마이그레이션 가능:

```python
# database.py에서 데이터베이스 URL만 변경
database_url = "postgresql://user:password@localhost/dbname"
```

### 추가 테이블

새로운 로깅 요구사항에 따라 테이블 추가 가능:

```python
# models.py에 새 모델 추가
class CustomLog(Base):
    __tablename__ = 'custom_logs'
    # 필드 정의...
```

## 📈 성능 최적화

1. **인덱스**: 자주 조회되는 컬럼에 인덱스 추가
2. **배치 처리**: 대량 데이터 삽입 시 배치 처리 사용
3. **연결 풀링**: 고부하 환경에서 연결 풀링 고려
4. **파티셔닝**: 대용량 데이터의 경우 테이블 파티셔닝 고려

## 🐛 문제 해결

### 일반적인 문제들

1. **SQLAlchemy 설치 오류**
   ```bash
   pip install sqlalchemy>=2.0.0
   ```

2. **데이터베이스 권한 오류**
   ```bash
   # logs 디렉토리 권한 확인
   chmod 755 logs/
   ```

3. **DB 로깅 비활성화**
   ```bash
   export DB_LOGGING_ENABLED=true
   ```

## 📞 지원

문제가 발생하거나 기능 요청이 있으시면 프로젝트 이슈 트래커를 이용해주세요. 