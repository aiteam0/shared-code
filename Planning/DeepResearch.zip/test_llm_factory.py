"""
LLM Factory 테스트
TDD 방식으로 LLM Factory 기능을 테스트합니다.
"""

import pytest
from unittest.mock import patch, MagicMock
import os
from langchain_utils.llm_factory import LLMFactory, ModelConfig


def test_llm_factory_yaml_config_로드():
    """YAML 설정 파일을 정상적으로 로드하는지 테스트"""
    factory = LLMFactory()
    models = factory.get_available_models()
    
    # 사용자가 요청한 모델들이 포함되어 있는지 확인
    model_names = [model.name for model in models]
    assert "gpt-4o-mini" in model_names
    assert "gemma3:12b" in model_names
    assert "qwen2.5vl:72b" in model_names


def test_chatgpt_모델_생성():
    """ChatOpenAI 모델이 정상적으로 생성되는지 테스트"""
    factory = LLMFactory()
    
    with patch.dict(os.environ, {'OPENAI_API_KEY': 'test-key'}):
        llm = factory.create_llm("gpt-4o-mini")
        
        # ChatOpenAI 타입인지 확인
        assert llm.__class__.__name__ == "ChatOpenAI"
        assert llm.model_name == "gpt-4o-mini"


def test_azure_chatgpt_모델_생성():
    """AzureChatOpenAI 모델이 정상적으로 생성되는지 테스트"""
    factory = LLMFactory()
    
    with patch.dict(os.environ, {
        'AZURE_OPENAI_API_KEY': 'test-key',
        'AZURE_OPENAI_ENDPOINT': 'test-endpoint'
    }):
        llm = factory.create_llm("azure-gpt-4o-mini")
        
        # AzureChatOpenAI 타입인지 확인
        assert llm.__class__.__name__ == "AzureChatOpenAI"


def test_ollama_모델_생성():
    """ChatOllama 모델이 정상적으로 생성되는지 테스트"""
    factory = LLMFactory()
    
    llm = factory.create_llm("gemma3:12b")
    
    # ChatOllama 타입인지 확인
    assert llm.__class__.__name__ == "ChatOllama"
    assert llm.model == "gemma3:12b"


def test_이미지_처리_capability_확인():
    """멀티모달 모델의 이미지 처리 capability 확인"""
    factory = LLMFactory()
    
    # 멀티모달 지원 모델
    multimodal_models = ["gpt-4o-mini", "gemma3:12b", "qwen2.5vl:72b"]
    
    for model_name in multimodal_models:
        model_config = factory.get_model_config(model_name)
        assert model_config.capabilities.multimodal is True


def test_tool_calling_capability_확인():
    """Tool calling capability 확인"""
    factory = LLMFactory()
    
    # Tool calling 지원 모델
    tool_calling_models = ["gpt-4o-mini", "qwen3:32b", "llama4:scout"]
    
    for model_name in tool_calling_models:
        model_config = factory.get_model_config(model_name)
        assert model_config.capabilities.tool_calling is True


def test_fallback_로직_이미지_처리():
    """이미지 처리 fallback 로직 테스트"""
    factory = LLMFactory()
    
    # Tool calling은 지원하지만 multimodal은 지원하지 않는 모델
    with patch.dict(os.environ, {'OPENAI_API_KEY': 'test-key'}):
        fallback_llm = factory.get_fallback_for_capability("text-only-model", "multimodal")
        
        # fallback 모델이 gpt-4o-mini인지 확인
        assert fallback_llm.model_name == "gpt-4o-mini"


def test_fallback_로직_tool_calling():
    """Tool calling fallback 로직 테스트"""
    factory = LLMFactory()
    
    # Multimodal은 지원하지만 tool calling은 지원하지 않는 모델
    with patch.dict(os.environ, {'OPENAI_API_KEY': 'test-key'}):
        fallback_llm = factory.get_fallback_for_capability("multimodal-only-model", "tool_calling")
        
        # fallback 모델이 gpt-4o-mini인지 확인
        assert fallback_llm.model_name == "gpt-4o-mini"


def test_존재하지_않는_모델_에러():
    """존재하지 않는 모델 요청시 에러 발생 테스트"""
    factory = LLMFactory()
    
    with pytest.raises(ValueError):
        factory.create_llm("non-existent-model")


def test_api_key_누락_에러():
    """필요한 API 키가 누락된 경우 에러 발생 테스트"""
    factory = LLMFactory()
    
    # OpenAI API 키 없이 OpenAI 모델 생성 시도
    with patch.dict(os.environ, {}, clear=True):
        with pytest.raises(ValueError):
            factory.create_llm("gpt-4o-mini") 