#!/usr/bin/env python3
"""
데이터베이스 Export 도구 사용 예제

프로그래밍 방식으로 DatabaseExporter를 사용하는 방법을 보여줍니다.
"""

import pandas as pd
from datetime import datetime, timedelta

# db_exporter 모듈에서 DatabaseExporter 클래스 import
try:
    from db_exporter import DatabaseExporter
except ImportError:
    print("Error: db_exporter.py 파일이 같은 디렉토리에 있는지 확인하세요.")
    exit(1)


def example_basic_usage():
    """기본 사용법 예제"""
    print("=== 기본 사용법 예제 ===")
    
    # Exporter 초기화 및 연결
    exporter = DatabaseExporter()
    if not exporter.connect():
        return
    
    # 테이블 정보 확인
    table_info = exporter.get_table_info()
    print("테이블 정보:")
    for table_name, count in table_info.items():
        print(f"  {table_name}: {count:,} 레코드")
    
    # 대화 테이블을 DataFrame으로 조회 (최신 10개)
    df = exporter.query_table_to_dataframe('conversations', limit=10)
    if df is not None and not df.empty:
        print(f"\n대화 테이블 데이터 (최신 10개):")
        print(df[['session_id', 'role', 'timestamp']].head())
        
        # CSV로 export
        success = exporter.export_dataframe(df, 'conversations_sample', 'csv')
        if success:
            print("✅ CSV export 성공")
    else:
        print("❌ 대화 데이터가 없습니다.")


def example_filtered_query():
    """필터링된 쿼리 예제"""
    print("\n=== 필터링된 쿼리 예제 ===")
    
    exporter = DatabaseExporter()
    if not exporter.connect():
        return
    
    # 특정 세션의 데이터만 조회
    session_id = "example_session_123"  # 실제 세션 ID로 변경
    
    df = exporter.query_table_to_dataframe(
        'conversations',
        session_id=session_id,
        limit=100
    )
    
    if df is not None and not df.empty:
        print(f"세션 {session_id}의 대화 데이터: {len(df)} 레코드")
        
        # 역할별 메시지 수 계산
        role_counts = df['role'].value_counts()
        print("역할별 메시지 수:")
        for role, count in role_counts.items():
            print(f"  {role}: {count}")
        
        # Excel로 export
        exporter.export_dataframe(df, f'session_{session_id}', 'excel')
    else:
        print(f"세션 {session_id}에 대한 데이터가 없습니다.")


def example_date_range_query():
    """날짜 범위 쿼리 예제"""
    print("\n=== 날짜 범위 쿼리 예제 ===")
    
    exporter = DatabaseExporter()
    if not exporter.connect():
        return
    
    # 최근 7일간의 데이터
    end_date = datetime.now()
    start_date = end_date - timedelta(days=7)
    
    df = exporter.query_table_to_dataframe(
        'search_logs',
        start_date=start_date.isoformat(),
        end_date=end_date.isoformat()
    )
    
    if df is not None and not df.empty:
        print(f"최근 7일간 검색 로그: {len(df)} 레코드")
        
        # 검색 타입별 통계
        if 'search_type' in df.columns:
            search_type_counts = df['search_type'].value_counts()
            print("검색 타입별 통계:")
            for search_type, count in search_type_counts.items():
                print(f"  {search_type}: {count}")
        
        # JSON으로 export
        exporter.export_dataframe(df, 'recent_searches', 'json')
    else:
        print("최근 7일간 검색 데이터가 없습니다.")


def example_data_analysis():
    """데이터 분석 예제"""
    print("\n=== 데이터 분석 예제 ===")
    
    exporter = DatabaseExporter()
    if not exporter.connect():
        return
    
    # 모든 대화 데이터 조회
    df = exporter.query_table_to_dataframe('conversations')
    
    if df is not None and not df.empty:
        print(f"전체 대화 데이터: {len(df)} 레코드")
        
        # 기본 통계
        print("\n기본 통계:")
        print(f"  총 세션 수: {df['session_id'].nunique()}")
        print(f"  평균 메시지 길이: {df['content'].str.len().mean():.1f} 문자")
        
        # 시간대별 활동 분석
        if 'timestamp' in df.columns:
            df['hour'] = pd.to_datetime(df['timestamp']).dt.hour
            hourly_activity = df['hour'].value_counts().sort_index()
            print("\n시간대별 활동 (상위 3개):")
            for hour, count in hourly_activity.head(3).items():
                print(f"  {hour}시: {count} 메시지")
        
        # 세션별 메시지 수
        session_message_counts = df['session_id'].value_counts()
        print(f"\n가장 활발한 세션: {session_message_counts.index[0]} ({session_message_counts.iloc[0]} 메시지)")
        
    else:
        print("분석할 대화 데이터가 없습니다.")


def example_export_all():
    """모든 테이블 export 예제"""
    print("\n=== 모든 테이블 Export 예제 ===")
    
    exporter = DatabaseExporter()
    if not exporter.connect():
        return
    
    # 모든 테이블을 CSV로 export (각 테이블당 최대 1000개 레코드)
    exporter.export_all_tables(format='csv', limit=1000)


def main():
    """메인 함수 - 모든 예제 실행"""
    print("📊 SQLAlchemy DB Export 도구 사용 예제")
    print("=" * 50)
    
    try:
        # 기본 사용법
        example_basic_usage()
        
        # 필터링된 쿼리
        example_filtered_query()
        
        # 날짜 범위 쿼리
        example_date_range_query()
        
        # 데이터 분석
        example_data_analysis()
        
        # 모든 테이블 export
        # example_export_all()  # 주석 처리 (필요시 활성화)
        
        print("\n✅ 모든 예제 실행 완료!")
        print("생성된 파일들은 'exports/' 디렉토리에서 확인할 수 있습니다.")
        
    except Exception as e:
        print(f"❌ 오류 발생: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main() 