#!/usr/bin/env python3
"""
SQLAlchemy 데이터베이스를 DataFrame으로 조회하고 export하는 도구

Usage:
    python db_exporter.py                    # 모든 테이블을 CSV로 export
    python db_exporter.py --table conversations --format excel  # 특정 테이블을 Excel로 export
"""

import os
import argparse
from pathlib import Path
from typing import Optional, Dict, Any, List
from datetime import datetime

import pandas as pd
from sqlalchemy import text

# db_logger 모듈 import
try:
    from db_logger.database import get_engine, get_db_session, is_db_logging_enabled
    from db_logger.models import Conversation, SearchLog, AgentAction, SystemLog
except ImportError:
    print("Error: db_logger 모듈을 찾을 수 없습니다. PYTHONPATH를 확인하세요.")
    exit(1)


class DatabaseExporter:
    """데이터베이스 테이블을 DataFrame으로 조회하고 export하는 클래스"""
    
    def __init__(self):
        self.engine = None
        self.tables = {
            'conversations': Conversation,
            'search_logs': SearchLog,
            'agent_actions': AgentAction,
            'system_logs': SystemLog
        }
        
    def connect(self) -> bool:
        """데이터베이스 연결"""
        try:
            if not is_db_logging_enabled():
                print("Warning: DB 로깅이 비활성화되어 있습니다.")
                print("DB_LOGGING_ENABLED=true로 설정하고 다시 시도하세요.")
                return False
            
            self.engine = get_engine()
            print(f"데이터베이스에 연결되었습니다: {self.engine.url}")
            return True
        except Exception as e:
            print(f"데이터베이스 연결 실패: {e}")
            return False
    
    def get_table_info(self) -> Dict[str, int]:
        """각 테이블의 레코드 수 조회"""
        if not self.engine:
            return {}
        
        info = {}
        with get_db_session() as session:
            if session is None:
                return {}
            
            for table_name, model_class in self.tables.items():
                try:
                    count = session.query(model_class).count()
                    info[table_name] = count
                except Exception as e:
                    print(f"테이블 {table_name} 정보 조회 실패: {e}")
                    info[table_name] = 0
        
        return info
    
    def query_table_to_dataframe(
        self, 
        table_name: str, 
        limit: Optional[int] = None,
        session_id: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> Optional[pd.DataFrame]:
        """테이블을 DataFrame으로 조회"""
        if table_name not in self.tables:
            print(f"지원하지 않는 테이블: {table_name}")
            print(f"사용 가능한 테이블: {', '.join(self.tables.keys())}")
            return None
        
        if not self.engine:
            if not self.connect():
                return None
        
        try:
            # 기본 쿼리 생성
            model_class = self.tables[table_name]
            
            with get_db_session() as session:
                if session is None:
                    return None
                
                query = session.query(model_class)
                
                # 세션 ID 필터
                if session_id:
                    query = query.filter(model_class.session_id == session_id)
                
                # 날짜 범위 필터 (timestamp 컬럼이 있는 경우)
                if hasattr(model_class, 'timestamp'):
                    if start_date:
                        start_dt = datetime.fromisoformat(start_date)
                        query = query.filter(model_class.timestamp >= start_dt)
                    if end_date:
                        end_dt = datetime.fromisoformat(end_date)
                        query = query.filter(model_class.timestamp <= end_dt)
                
                # 최신 순으로 정렬
                if hasattr(model_class, 'timestamp'):
                    query = query.order_by(model_class.timestamp.desc())
                elif hasattr(model_class, 'id'):
                    query = query.order_by(model_class.id.desc())
                
                # 제한
                if limit:
                    query = query.limit(limit)
                
                # 결과 조회
                results = query.all()
                
                # DataFrame으로 변환
                if results:
                    data = [result.to_dict() for result in results]
                    df = pd.DataFrame(data)
                    
                    # timestamp 컬럼을 datetime 타입으로 변환
                    if 'timestamp' in df.columns:
                        df['timestamp'] = pd.to_datetime(df['timestamp'])
                    
                    return df
                else:
                    print(f"테이블 {table_name}에서 조건에 맞는 데이터를 찾을 수 없습니다.")
                    return pd.DataFrame()
                    
        except Exception as e:
            print(f"테이블 {table_name} 조회 실패: {e}")
            return None
    
    def export_dataframe(
        self, 
        df: pd.DataFrame, 
        filename: str, 
        format: str = 'csv'
    ) -> bool:
        """DataFrame을 파일로 export"""
        if df is None or df.empty:
            print("Export할 데이터가 없습니다.")
            return False
        
        try:
            # 출력 디렉토리 생성
            output_dir = Path("exports")
            output_dir.mkdir(exist_ok=True)
            
            # 파일 경로 생성
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            if format.lower() == 'csv':
                filepath = output_dir / f"{filename}_{timestamp}.csv"
                df.to_csv(filepath, index=False, encoding='utf-8-sig')
            elif format.lower() == 'excel':
                filepath = output_dir / f"{filename}_{timestamp}.xlsx"
                df.to_excel(filepath, index=False, engine='openpyxl')
            elif format.lower() == 'json':
                filepath = output_dir / f"{filename}_{timestamp}.json"
                df.to_json(filepath, orient='records', indent=2, force_ascii=False)
            elif format.lower() == 'parquet':
                filepath = output_dir / f"{filename}_{timestamp}.parquet"
                df.to_parquet(filepath, index=False)
            else:
                print(f"지원하지 않는 형식: {format}")
                return False
            
            print(f"Export 완료: {filepath}")
            print(f"레코드 수: {len(df)}")
            return True
            
        except Exception as e:
            print(f"Export 실패: {e}")
            return False
    
    def export_all_tables(self, format: str = 'csv', limit: Optional[int] = None):
        """모든 테이블을 export"""
        print("=== 데이터베이스 Export 시작 ===")
        
        # 테이블 정보 출력
        table_info = self.get_table_info()
        print("\n테이블 정보:")
        for table_name, count in table_info.items():
            print(f"  {table_name}: {count:,} 레코드")
        
        print(f"\nExport 형식: {format.upper()}")
        if limit:
            print(f"제한: 테이블당 최대 {limit:,} 레코드")
        
        # 각 테이블 export
        success_count = 0
        for table_name in self.tables.keys():
            print(f"\n{table_name} 테이블 처리 중...")
            
            df = self.query_table_to_dataframe(table_name, limit=limit)
            if df is not None and not df.empty:
                if self.export_dataframe(df, table_name, format):
                    success_count += 1
            else:
                print(f"  {table_name}: 데이터 없음 또는 오류")
        
        print(f"\n=== Export 완료: {success_count}/{len(self.tables)} 테이블 성공 ===")
    
    def show_sample_data(self, table_name: str, limit: int = 5):
        """테이블의 샘플 데이터 출력"""
        df = self.query_table_to_dataframe(table_name, limit=limit)
        if df is not None and not df.empty:
            print(f"\n=== {table_name} 샘플 데이터 ({len(df)} 레코드) ===")
            pd.set_option('display.max_columns', None)
            pd.set_option('display.width', None)
            pd.set_option('display.max_colwidth', 50)
            print(df.head(limit))
            print(f"\n컬럼 정보:")
            print(df.dtypes)
        else:
            print(f"{table_name} 테이블에 데이터가 없습니다.")


def main():
    parser = argparse.ArgumentParser(description='SQLAlchemy 데이터베이스 Export 도구')
    parser.add_argument('--table', '-t', 
                       choices=['conversations', 'search_logs', 'agent_actions', 'system_logs', 'all'],
                       default='all',
                       help='Export할 테이블 (기본: all)')
    parser.add_argument('--format', '-f',
                       choices=['csv', 'excel', 'json', 'parquet'],
                       default='csv',
                       help='Export 형식 (기본: csv)')
    parser.add_argument('--limit', '-l', type=int,
                       help='최대 레코드 수 제한')
    parser.add_argument('--session-id', '-s',
                       help='특정 세션 ID만 필터링')
    parser.add_argument('--start-date',
                       help='시작 날짜 (YYYY-MM-DD 또는 YYYY-MM-DD HH:MM:SS)')
    parser.add_argument('--end-date',
                       help='종료 날짜 (YYYY-MM-DD 또는 YYYY-MM-DD HH:MM:SS)')
    parser.add_argument('--sample', action='store_true',
                       help='샘플 데이터만 출력 (export 안함)')
    parser.add_argument('--info', action='store_true',
                       help='테이블 정보만 출력')
    
    args = parser.parse_args()
    
    # Exporter 초기화
    exporter = DatabaseExporter()
    
    if not exporter.connect():
        return
    
    # 정보만 출력
    if args.info:
        table_info = exporter.get_table_info()
        print("=== 데이터베이스 테이블 정보 ===")
        for table_name, count in table_info.items():
            print(f"{table_name}: {count:,} 레코드")
        return
    
    # 샘플 데이터 출력
    if args.sample:
        if args.table == 'all':
            for table_name in exporter.tables.keys():
                exporter.show_sample_data(table_name)
        else:
            exporter.show_sample_data(args.table)
        return
    
    # Export 실행
    if args.table == 'all':
        exporter.export_all_tables(args.format, args.limit)
    else:
        df = exporter.query_table_to_dataframe(
            args.table,
            limit=args.limit,
            session_id=args.session_id,
            start_date=args.start_date,
            end_date=args.end_date
        )
        
        if df is not None:
            exporter.export_dataframe(df, args.table, args.format)


if __name__ == "__main__":
    main() 