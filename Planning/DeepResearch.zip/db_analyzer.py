#!/usr/bin/env python3
"""
SQLAlchemy 데이터베이스 고급 분석 도구

DB 로깅 시스템에 저장된 데이터에 대한 심층 분석을 제공합니다.
"""

import os
import sys
from datetime import datetime
import json

# 프로젝트 루트를 Python 경로에 추가
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def init_db_connection():
    """데이터베이스 연결 초기화"""
    try:
        from db_logger import init_database, get_db_session
        from db_logger.models import Conversation, SearchLog, AgentAction, SystemLog
        
        # 데이터베이스 초기화
        init_database()
        print("✅ 데이터베이스 연결 성공")
        return True
    except Exception as e:
        print(f"❌ 데이터베이스 연결 실패: {e}")
        return False

def analyze_conversation_patterns():
    """대화 패턴 분석"""
    print("\n" + "="*60)
    print("💬 대화 패턴 분석")
    print("="*60)
    
    try:
        from db_logger import get_db_session
        from db_logger.models import Conversation
        from sqlalchemy import func
        
        with get_db_session() as session:
            if session is None:
                print("❌ 데이터베이스 세션을 가져올 수 없습니다.")
                return
            
            # 기본 통계
            total_conversations = session.query(Conversation).count()
            unique_sessions = session.query(func.distinct(Conversation.session_id)).count()
            
            print(f"📊 기본 통계:")
            print(f"   총 대화 수: {total_conversations:,}")
            print(f"   고유 세션 수: {unique_sessions:,}")
            
            # 평균 메시지 길이 계산
            conversations = session.query(Conversation).all()
            if conversations:
                avg_length = sum(len(conv.content) for conv in conversations) / len(conversations)
                max_length = max(len(conv.content) for conv in conversations)
                print(f"   평균 메시지 길이: {avg_length:.1f}자")
                print(f"   최대 메시지 길이: {max_length:,}자")
            
            # 역할별 통계
            print(f"\n👥 역할별 통계:")
            role_stats = session.query(
                Conversation.role,
                func.count(Conversation.id).label('count')
            ).group_by(Conversation.role).all()
            
            for role, count in role_stats:
                percentage = (count / total_conversations) * 100 if total_conversations > 0 else 0
                print(f"   {role}: {count:,}개 ({percentage:.1f}%)")
            
            # 모드별 통계
            print(f"\n🎯 모드별 통계:")
            mode_stats = session.query(
                Conversation.mode,
                func.count(Conversation.id).label('count')
            ).group_by(Conversation.mode).all()
            
            for mode, count in mode_stats:
                percentage = (count / total_conversations) * 100 if total_conversations > 0 else 0
                print(f"   {mode}: {count:,}개 ({percentage:.1f}%)")
            
    except Exception as e:
        print(f"❌ 대화 패턴 분석 실패: {e}")

def analyze_search_patterns():
    """검색 패턴 분석"""
    print("\n" + "="*60)
    print("🔍 검색 패턴 분석")
    print("="*60)
    
    try:
        from db_logger import get_db_session
        from db_logger.models import SearchLog
        from sqlalchemy import func, desc
        
        with get_db_session() as session:
            if session is None:
                print("❌ 데이터베이스 세션을 가져올 수 없습니다.")
                return
            
            # 기본 통계
            total_searches = session.query(SearchLog).count()
            unique_sessions = session.query(func.distinct(SearchLog.session_id)).count()
            
            print(f"📊 기본 통계:")
            print(f"   총 검색 수: {total_searches:,}")
            print(f"   고유 세션 수: {unique_sessions:,}")
            
            # 검색어 길이 통계
            searches = session.query(SearchLog).all()
            if searches:
                avg_query_length = sum(len(search.query) for search in searches) / len(searches)
                avg_results_length = sum(len(search.results or '') for search in searches) / len(searches)
                print(f"   평균 검색어 길이: {avg_query_length:.1f}자")
                print(f"   평균 결과 크기: {avg_results_length:.1f}자")
            
            # 검색 타입별 통계
            print(f"\n🔍 검색 타입별 통계:")
            type_stats = session.query(
                SearchLog.search_type,
                func.count(SearchLog.id).label('count')
            ).group_by(SearchLog.search_type).all()
            
            for search_type, count in type_stats:
                percentage = (count / total_searches) * 100 if total_searches > 0 else 0
                print(f"   {search_type}: {count:,}개 ({percentage:.1f}%)")
            
            # 인기 검색어 TOP 10
            print(f"\n🔥 인기 검색어 TOP 10:")
            top_queries = session.query(
                SearchLog.query,
                func.count(SearchLog.id).label('count')
            ).group_by(SearchLog.query).order_by(
                desc('count')
            ).limit(10).all()
            
            for i, (query, count) in enumerate(top_queries, 1):
                query_preview = query[:50] + "..." if len(query) > 50 else query
                print(f"   {i:2d}. ({count:2d}회) {query_preview}")
            
    except Exception as e:
        print(f"❌ 검색 패턴 분석 실패: {e}")

def interactive_analyzer_menu():
    """대화형 분석 메뉴"""
    while True:
        print("\n" + "="*60)
        print("🔬 SQLAlchemy DB 고급 분석 도구")
        print("="*60)
        print("1. 💬 대화 패턴 분석")
        print("2. 🔍 검색 패턴 분석")
        print("3. 🚪 종료")
        print()
        
        try:
            choice = input("선택하세요 (1-3): ").strip()
            
            if choice == '1':
                analyze_conversation_patterns()
                
            elif choice == '2':
                analyze_search_patterns()
                
            elif choice == '3':
                print("👋 프로그램을 종료합니다.")
                break
                
            else:
                print("❌ 잘못된 선택입니다. 1-3 사이의 숫자를 입력하세요.")
                
        except KeyboardInterrupt:
            print("\n👋 프로그램을 종료합니다.")
            break
        except Exception as e:
            print(f"❌ 오류 발생: {e}")
        
        input("\n계속하려면 엔터를 누르세요...")

def main():
    """메인 함수"""
    print("🚀 SQLAlchemy DB 고급 분석 도구 시작")
    
    # 환경 변수 설정
    os.environ["DB_LOGGING_ENABLED"] = "true"
    if not os.environ.get("DB_PATH"):
        os.environ["DB_PATH"] = "logs/interactions.db"
    
    # 데이터베이스 연결 확인
    if not init_db_connection():
        print("❌ 데이터베이스에 연결할 수 없습니다.")
        return
    
    # 명령행 인수 처리
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == 'conversations':
            analyze_conversation_patterns()
        elif command == 'searches':
            analyze_search_patterns()
        else:
            print("❌ 알 수 없는 명령어입니다.")
            print("사용법:")
            print("  python db_analyzer.py conversations")
            print("  python db_analyzer.py searches")
    else:
        # 대화형 모드
        interactive_analyzer_menu()

if __name__ == "__main__":
    main() 