import asyncio
import functools
import itertools
import os
from typing import List, Optional

import evaluate
import pandas as pd
import torch
from llama_index.core.embeddings import BaseEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.llms.azure_openai import AzureOpenAI
from llama_index.embeddings.azure_openai import AzureOpenAIEmbedding
from openai import AsyncOpenAI, AsyncAzureOpenAI
from rouge_score import tokenizers
from rouge_score.rouge_scorer import RougeScorer
from sacrebleu.metrics.bleu import BLEU

from autoeval import embedding_models
from autoeval.evaluation.generation.generation_util import calculate_cosine_similarity
from autoeval.utils import process_batch, openai_truncate_by_token, convert_inputs_to_list


def generation_metric(func):
    @functools.wraps(func)
    @convert_inputs_to_list
    def wrapper(generation_gt: List[List[str]], generations: List[str], **kwargs) -> List[float]:
        result = list(map(lambda x: func(x[0], x[1], **kwargs), zip(generation_gt, generations)))
        return result

    return wrapper


@convert_inputs_to_list
def huggingface_evaluate(instance, key: str,
                         generation_gt: List[List[str]], generations: List[str],
                         **kwargs) -> List[float]:
    def compute_score(gt: List[str], pred: str) -> float:
        return max(list(map(
            lambda x: instance.compute(predictions=[pred], references=[x], **kwargs)[key], gt)))

    result = list(map(lambda x: compute_score(x[0], x[1]), zip(generation_gt, generations)))
    return result


@convert_inputs_to_list
def bleu(generation_gt: List[List[str]], generations: [str], tokenize: Optional[str] = None,
         smooth_method: str = 'exp', smooth_value: Optional[float] = None, max_ngram_order: int = 4,
         trg_lang: str = '', **kwargs) -> List[float]:
    bleu_instance = BLEU(tokenize=tokenize, smooth_method=smooth_method, smooth_value=smooth_value,
                         max_ngram_order=max_ngram_order, trg_lang=trg_lang, **kwargs)

    result = list(map(lambda x: bleu_instance.sentence_score(x[0], x[1]).score, zip(generations, generation_gt)))
    return result


@convert_inputs_to_list
def meteor(generation_gt: List[List[str]], generations: List[str],
           alpha: float = 0.9,
           beta: float = 3.0,
           gamma: float = 0.5) -> List[float]:
    meteor_instance = evaluate.load("meteor")
    result = huggingface_evaluate(meteor_instance, 'meteor', generation_gt, generations,
                                  alpha=alpha, beta=beta, gamma=gamma)
    del meteor_instance
    return result


@convert_inputs_to_list
def rouge(generation_gt: List[List[str]], generations: List[str],
          rouge_type: Optional[str] = 'rougeL',
          use_stemmer: bool = False,
          split_summaries: bool = False,
          batch: int = os.cpu_count()) -> List[float]:
    rouge_instance = RougeScorer(rouge_types=[rouge_type], use_stemmer=use_stemmer,
                                 split_summaries=split_summaries,
                                 tokenizer=tokenizers.DefaultTokenizer(use_stemmer))

    async def compute(gt: List[str], pred: str) -> float:
        return rouge_instance.score_multi(targets=gt, prediction=pred)[rouge_type].fmeasure

    tasks = [compute(gt, pred) for gt, pred in zip(generation_gt, generations)]
    loop = asyncio.get_event_loop()
    result = loop.run_until_complete(process_batch(tasks, batch_size=batch))

    del rouge_instance
    return result


@convert_inputs_to_list
def sem_score(generation_gt: List[List[str]], generations: List[str],
              embedding_model: Optional[BaseEmbedding] = None,
              batch: int = 128) -> List[float]:
 
    if embedding_model is None:
        embedding_model = embedding_models['huggingface_all_mpnet_base_v2']

    embedding_model.embed_batch_size = batch

    openai_embedding_max_length = 8191
    if isinstance(embedding_model, AzureOpenAIEmbedding):
        generations = openai_truncate_by_token(generations, openai_embedding_max_length,
                                               embedding_model.model_name)

    embedded_pred: List[List[float]] = embedding_model.get_text_embedding_batch(generations,
                                                                                show_progress=True)
    gt_lengths = list(map(len, generation_gt))
    flatten_gt = list(itertools.chain.from_iterable(generation_gt))
    if isinstance(embedding_model, AzureOpenAIEmbedding):
        flatten_gt = openai_truncate_by_token(flatten_gt, openai_embedding_max_length,
                                              embedding_model.model_name)
    embedded_gt_flatten = embedding_model.get_text_embedding_batch(flatten_gt, show_progress=True)
    iterator = iter(embedded_gt_flatten)
    embedded_gt: List[List[List[float]]] = [list(itertools.islice(iterator, length)) for length in gt_lengths]

    result = []
    for gt, pred in zip(embedded_gt, embedded_pred):
        similarity_scores: List[float] = list(
            map(lambda x: calculate_cosine_similarity(x, pred), gt))
        result.append(max(similarity_scores))

    del embedding_model
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    return result


@convert_inputs_to_list
def g_eval(generation_gt: List[List[str]], generations: List[str],
           metrics: Optional[List[str]] = None,
           model: str = 'gpt-4-0125-preview',
           batch_size: int = 8) -> List[float]:
    loop = asyncio.get_event_loop()
    tasks = [async_g_eval(gt, pred, metrics, model) for gt, pred in zip(generation_gt, generations)]
    result = loop.run_until_complete(process_batch(tasks, batch_size=batch_size))
    return result


async def async_g_eval(generation_gt: List[str], pred: str,
                       metrics: Optional[List[str]] = None,
                       model: str = 'gpt-4-0125-preview',
                       ) -> float:
    available_metrics = ['coherence', 'consistency', 'fluency', 'relevance']
    if metrics is None:
        metrics = available_metrics
    else:
        assert len(metrics) > 0, "metrics must be a list of string"
        metrics = [metric for metric in metrics if metric in available_metrics]

    current_path = os.path.dirname(os.path.realpath(__file__))
    prompt_path = os.path.join(current_path, 'g_eval_prompts')
    g_eval_prompts = {
        "coherence": open(os.path.join(prompt_path, "coh_detailed.txt")).read(),
        "consistency": open(os.path.join(prompt_path, "con_detailed.txt")).read(),
        "fluency": open(os.path.join(prompt_path, "flu_detailed.txt")).read(),
        "relevance": open(os.path.join(prompt_path, "rel_detailed.txt")).read(),
    }

    #client = AsyncOpenAI()
    client = AsyncAzureOpenAI()

    async def g_eval_score(prompt: str, gen_gt: List[str], pred: str):
        scores = []
        for gt in gen_gt:
            input_prompt = prompt.replace('{{Document}}', gt).replace('{{Summary}}', pred)
            response = await client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": input_prompt}
                ],
                logprobs=True,
                top_logprobs=5,
                temperature=0,
                max_tokens=2,
                frequency_penalty=0,
                presence_penalty=0,
                stop=None,
                n=20,
            )
            if '(1-3):' in prompt:
                scores.append(get_g_eval_score(response, max_score=3))
            else:
                scores.append(get_g_eval_score(response))
        return max(scores)

    def get_g_eval_score(responses, max_score: int = 5) -> int:
        target_tokens = {str(i): 0 for i in range(1, max_score + 1)}
        for choice in responses.choices:
            first_top_log_probs = choice.logprobs.content[0].top_logprobs
            for i, top_log_prob in enumerate(list(map(lambda x: x.token, first_top_log_probs))):
                if top_log_prob in target_tokens:
                    target_tokens[top_log_prob] += (5 - i)

        return int(max(target_tokens, key=target_tokens.get))

    g_eval_scores = await asyncio.gather(*(g_eval_score(g_eval_prompts[x], generation_gt, pred) for x in metrics))
    return sum(g_eval_scores) / len(g_eval_scores)


@convert_inputs_to_list
def bert_score(generation_gt: List[List[str]], generations: List[str],
               lang: str = 'en',
               batch: int = 128,
               n_threads: int = os.cpu_count()) -> List[float]:
    evaluator = evaluate.load("bertscore")

    df = pd.DataFrame({
        'reference': generation_gt,
        'prediction': generations,
        'lang': lang,
    })

    df = df.explode('reference', ignore_index=False)
    df['bert_score'] = evaluator.compute(predictions=df['prediction'].tolist(),
                                         references=df['reference'].tolist(),
                                         lang=lang, nthreads=n_threads, batch_size=batch)['f1']

    del evaluator
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    return df.groupby(level=0)['bert_score'].max().tolist()