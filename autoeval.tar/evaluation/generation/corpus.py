import uuid
from typing import List, Optional

import pandas as pd
from langchain_core.documents import Document

from autoeval.utils.util import add_essential_metadata, save_parquet_safe


def langchain_documents_to_parquet(langchain_documents: List[Document],
                                   output_filepath: Optional[str] = None,
                                   upsert: bool = False) -> pd.DataFrame:

    corpus_df = pd.DataFrame(list(map(lambda doc: {
        'doc_id': str(uuid.uuid4()),
        'contents': doc.page_content,
        'metadata': add_essential_metadata(doc.metadata)
    }, langchain_documents)))

    if output_filepath is not None:
        save_parquet_safe(corpus_df, output_filepath, upsert=upsert)

    return corpus_df


