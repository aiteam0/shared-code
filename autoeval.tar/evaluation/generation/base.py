import logging
import uuid
from typing import Callable, Optional
import pandas as pd
from tqdm import tqdm
from autoeval.utils.util import save_parquet_safe

logger = logging.getLogger("AutoEval")


def make_basic_qa(corpus_df: pd.DataFrame,
                           content_size: int,
                           qa_creation_func: Callable,
                           output_filepath: Optional[str] = None,
                           upsert: bool = False,
                           random_state: int = 42,
                           cache_batch: int = 32,
                           **kwargs) -> pd.DataFrame:
    
    assert content_size > 0, "content_size must be greater than 0."
    if content_size > len(corpus_df):
        logger.warning(f"content_size {content_size} is larger than the corpus size {len(corpus_df)}. "
                       "Setting content_size to the corpus size.")
        content_size = len(corpus_df)
    sampled_corpus = corpus_df.sample(n=content_size, random_state=random_state)
    sampled_corpus = sampled_corpus.reset_index(drop=True)

    def make_query_generation_gt(row):
        return row['qa']['query'], row['qa']['generation_gt']

    qa_data = pd.DataFrame()
    for idx, i in tqdm(enumerate(range(0, len(sampled_corpus), cache_batch))):
        qa = qa_creation_func(contents=sampled_corpus['contents'].tolist()[i:i + cache_batch], **kwargs)

        temp_qa_data = pd.DataFrame({
            'qa': qa,
            'retrieval_gt': sampled_corpus['doc_id'].tolist()[i:i + cache_batch],
            'context_gt': sampled_corpus['contents'].tolist()[i:i + cache_batch],
            'source': sampled_corpus['metadata'].apply(lambda x : x['source']).tolist()[i:i + cache_batch],
        })
        temp_qa_data = temp_qa_data.explode('qa', ignore_index=True)
        temp_qa_data['qid'] = [str(uuid.uuid4()) for _ in range(len(temp_qa_data))]
        temp_qa_data[['query', 'answer_gt']] = temp_qa_data.apply(make_query_generation_gt, axis=1,
                                                                      result_type='expand')
        temp_qa_data = temp_qa_data.drop(columns=['qa'])

        temp_qa_data['retrieval_gt'] = temp_qa_data['retrieval_gt'].apply(lambda x: [[x]])
        temp_qa_data['answer_gt'] = temp_qa_data['answer_gt'].apply(lambda x: [x])
        temp_qa_data['context_gt'] = temp_qa_data['context_gt'].apply(lambda x: [[x]])

        if idx == 0:
            qa_data = temp_qa_data
        else:
            qa_data = pd.concat([qa_data, temp_qa_data], ignore_index=True)
        if output_filepath is not None:
            save_parquet_safe(qa_data, output_filepath, upsert=upsert)

    return qa_data

import random
from collections import defaultdict


def make_augmented_qa(corpus_df: pd.DataFrame,
                           content_size: int,
                           qa_creation_func: Callable,
                           output_filepath: Optional[str] = None,                           
                           upsert: bool = False,
                           selection : int = 2,
                           random_state: int = 42,
                           cache_batch: int = 32,
                           **kwargs) -> pd.DataFrame:

    assert content_size > 0, "content_size must be greater than 0."
    if content_size > len(corpus_df):
        logger.warning(f"content_size {content_size} is larger than the corpus size {len(corpus_df)}. "
                       "Setting content_size to the corpus size.")
        content_size = len(corpus_df)
    sampled_corpus = corpus_df.sample(n=content_size, random_state=random_state)
    sampled_corpus = sampled_corpus.reset_index(drop=True)
    
    #group by source
    metadata_df = pd.json_normalize(sampled_corpus['metadata'])
    tmp_corpus_df = sampled_corpus.join(metadata_df) #drop(columns=['metadata']).
    grouped_dfs = {source: group.reset_index(drop=True) for source, group in tmp_corpus_df.groupby('source')}
    
    print("Sources :",list(grouped_dfs.keys()))
    
    
    def merge_random_sampled_corpus(df:pd.DataFrame, n:int):
        if n < 2:
            raise ValueError("n must be at least 2 to merge elements.")

        output_ids = []
        output_contents = []
        output_metadata = []

        while len(output_contents) < len(df):

            selected_doc_ids = random.sample(df['doc_id'].tolist(), n)
            selected_elements = [df.loc[df['doc_id'] == doc_id,'contents'].values[0] for doc_id in selected_doc_ids]
            #merged_element = '\n\n\n\n'.join(selected_elements)
            selected_metadata = [df.loc[df['doc_id'] == doc_id,'metadata'].values[0] for doc_id in selected_doc_ids]

            merged_dict = defaultdict(list)
            for metadata in selected_metadata:
                for key, value in metadata.items():
                    merged_dict[key].append(value)
                merged_dict["doc_id"] = selected_doc_ids

            output_ids.append(selected_doc_ids)
            output_contents.append(selected_elements) 
            output_metadata.append(merged_dict)

        return output_ids, output_contents, output_metadata
    
    all_output_ids = []
    all_output_contents = []
    all_output_metadata = []
    
    for source, df_by_source in grouped_dfs.items():
        print(f"{source} has {len(df_by_source)} datas.")
        output_ids, output_contents, output_metadata = merge_random_sampled_corpus(df_by_source, selection)
        
        all_output_ids.extend(output_ids)
        all_output_contents.extend(output_contents)
        all_output_metadata.extend(output_metadata)
        
    aug_sampled_corpus = pd.DataFrame({
                            "doc_id":all_output_ids,
                            "contents":all_output_contents,
                            "metadata":all_output_metadata,
                        })

    def make_query_generation_gt(row):
        return row['qa']['query'], row['qa']['generation_gt']

    qa_data = pd.DataFrame()
    for idx, i in tqdm(enumerate(range(0, len(aug_sampled_corpus), cache_batch))):
        
        qa = qa_creation_func(contents=aug_sampled_corpus['contents'].tolist()[i:i + cache_batch], selection=selection, **kwargs)

        temp_qa_data = pd.DataFrame({
            'qa': qa,
            'retrieval_gt': aug_sampled_corpus['doc_id'].tolist()[i:i + cache_batch],
            'context_gt': aug_sampled_corpus['contents'].tolist()[i:i + cache_batch],
            'source': aug_sampled_corpus['metadata'].apply(lambda x : x['source']).tolist()[i:i + cache_batch],
        })
        temp_qa_data = temp_qa_data.explode('qa', ignore_index=True)
        temp_qa_data['qid'] = [str(uuid.uuid4()) for _ in range(len(temp_qa_data))]
        temp_qa_data[['query', 'answer_gt']] = temp_qa_data.apply(make_query_generation_gt, axis=1,
                                                                      result_type='expand') #generation_gt -> answer_gt
        temp_qa_data = temp_qa_data.drop(columns=['qa'])

        temp_qa_data['retrieval_gt'] = temp_qa_data['retrieval_gt'].apply(lambda x: [x])
        temp_qa_data['answer_gt'] = temp_qa_data['answer_gt'].apply(lambda x: [x])
        temp_qa_data['context_gt'] = temp_qa_data['context_gt'].apply(lambda x: [x])

        if idx == 0:
            qa_data = temp_qa_data
        else:
            qa_data = pd.concat([qa_data, temp_qa_data], ignore_index=True)
        if output_filepath is not None:
            save_parquet_safe(qa_data, output_filepath, upsert=upsert)

    return qa_data



import asyncio
import os.path
import random
import numpy as np
from typing import Optional, List, Dict, Any

import pandas as pd
from langchain_openai import AzureChatOpenAI
from autoeval.utils.util import process_batch
from langchain_core.prompts import PromptTemplate
from langchain.schema import StrOutputParser

package_dir = os.path.dirname(os.path.realpath(__file__))


def generate_qa_langchain(
        llm: AzureChatOpenAI,
        contents: List[str],
        prompt: Optional[str] = None,
        question_num_per_content: int = 1,
        max_retries: int = 3,
        batch: int = 4,
        return_korean: bool = True,
) -> List[List[Dict]]:
    
    # load default prompt
    if ((prompt is None) & (return_korean == False)):
        prompt = open(os.path.join(package_dir, "qa_generation_prompt.txt"), 'r').read()
    elif ((prompt is None) & (return_korean == True)):
        prompt = open(os.path.join(package_dir, "qa_generation_korean_prompt.txt"), 'r').read()

    tasks = [
        async_qa_gen_langchain(content, llm, prompt, question_num_per_content, max_retries)
        for content in contents
    ]
    loops = asyncio.get_event_loop()
    results = loops.run_until_complete(process_batch(tasks, batch))
    return results


def generate_augmented_qa_langchain(
        llm: AzureChatOpenAI,
        contents: List[str],
        prompt: Optional[str] = None,        
        question_num_per_content: int = 1,
        max_retries: int = 3,
        batch: int = 4,
        selection : int = 2,
        return_korean: bool = True,
) -> List[List[Dict]]:

    if ((prompt is None) & (return_korean == False)):
        prompt = open(os.path.join(package_dir, "qa_generation_prompt.txt"), 'r').read()
    elif ((prompt is None) & (return_korean == True)):
        prompt = open(os.path.join(package_dir, "qa_generation_korean_prompt.txt"), 'r').read()

    tasks = [
        async_qa_gen_langchain(content, llm, prompt, question_num_per_content, max_retries)
        for content in contents
    ]
    loops = asyncio.get_event_loop()
    results = loops.run_until_complete(process_batch(tasks, batch))
    return results


async def async_qa_gen_langchain(
        content: str,
        llm: AzureChatOpenAI,
        prompt: str,
        question_num: int = 1,
        max_retries: int = 3
):

    validate_langchain_prompt(prompt)

    async def generate(content: str, llm: AzureChatOpenAI):
        
        chat_prompt = PromptTemplate.from_template(prompt)
        chain = chat_prompt|llm|StrOutputParser()
        for _ in range(max_retries):
            output = await chain.ainvoke({"text":content, "num_questions":str(question_num)})
            result = parse_output(output)
            if len(result) == question_num:
                return result
        raise InterruptedError(f"Failed to generate output of length {question_num} after {max_retries} retries.")

    return await generate(content, llm)


def validate_langchain_prompt(prompt: str) -> bool:

    if "{text}" not in prompt:
        raise ValueError("The prompt must include the placeholder {text}.")
    if "{num_questions}" not in prompt:
        raise ValueError("The prompt must include the placeholder {num_questions}.")
    return True


def parse_output(result: str) -> List[Dict]:
    result = result.strip()
    result = result.split("[Q]:")
    final_result = list()
    for res in result:
        res = res.strip()
        if res and "\n[A]:" in res:
            qa = res.split("\n[A]:")
            final_result.append({
                'query': qa[0].strip(),
                'generation_gt': qa[1].strip()
            })
    return final_result


from autoeval.evaluation.generation import base_model
import pandas as pd
import concurrent.futures

class RowGenerateResult:
    def __init__(self, is_successful, error_msg, **kwargs):
        self.is_successful = is_successful
        self.error_msg = error_msg
        for key, value in kwargs.items():
            setattr(self, key, value)


class BatchGenerateResult:
    num_rows: int
    num_successful_rows: int
    rows: list

    def __init__(self, is_successful, error_msg, **kwargs):
        self.is_successful = is_successful
        self.error_msg = error_msg
        for key, value in kwargs.items():
            setattr(self, key, value)


class GenerateResult:
    num_rows: int
    num_successful_rows: int
    rows: list

    def __init__(self, num_rows, num_successful_rows, rows, **kwargs):
        self.num_rows = num_rows
        self.num_successful_rows = num_successful_rows
        self.rows = rows
        for key, value in kwargs.items():
            setattr(self, key, value)

    def to_dataframe(self):
        row_dicts = [row.__dict__ for row in self.rows]
        eval_result_df = pd.DataFrame(row_dicts)
        return eval_result_df

    def summary(self):
        summary_str = ""
        for key, value in self.__dict__.items():
            if key == "rows":
                continue
            summary_str += f"{key}: {value}\n"
        return summary_str


class BaseModelGenerator:
    def __init__(
        self, 
        prompt_formatter: PromptTemplate, 
        azure_endpoint: str, 
        azure_api_key: str, 
        azure_deployment_name: str, 
        api_version: str,
        batch_size: int = 1, 
        concurrency=1,
        output_filepath : str = None, 
        upsert : bool = False,
    ) -> None:

        self._prompt_formatter = prompt_formatter
        self._batch_size = batch_size
        self._concurrency = concurrency
        self.input_variables = prompt_formatter.input_variables
        
        self.azure_endpoint =azure_endpoint
        self.azure_api_key = azure_api_key
        self.azure_deployment_name = azure_deployment_name
        self.api_version = api_version
        self.output_filepath = output_filepath
        self.upsert = upsert

    def _generate(
        self, 
        prompts: list, 
        temperature: float, 
        max_tokens=256, 
        system_prompt=None,        
    ) -> BatchGenerateResult:
        raise NotImplementedError

    def run_tasks(
        self, 
        input_df, 
        temperature: float, 
        max_tokens=256, 
        system_prompt=None,
        add_variables:list = [],
    ) -> GenerateResult:

        if "retrieval_context" in input_df.columns:
            input_df['retrieval_context'] = input_df['retrieval_context'].apply(lambda x : "/n/n".join(np.hstack(x)))
        
        task_batches = []

        for i in range(0, len(input_df), self._batch_size):

            batch_df = input_df.iloc[i : i + self._batch_size]
            prompts = []
            for index, row in batch_df.iterrows():
                prompt = self._prompt_formatter.format(**row)
                prompts.append(prompt)
            task = {
                "prompts": prompts,
                "df": batch_df,
            }
            task_batches.append(task)
        logger.info(
            f"Generated total number of batches for prompts: {len(task_batches)}"
        )

        with concurrent.futures.ThreadPoolExecutor(
            max_workers=self._concurrency
        ) as executor:
            future_to_batch = {
                executor.submit(
                    self._generate,
                    task["prompts"],
                    temperature,
                    max_tokens,
                    system_prompt,
                ): task
                for task in task_batches
            }
            batch_generate_results = []
            for future in concurrent.futures.as_completed(future_to_batch):
                task = future_to_batch[future]
                try:
                    result = future.result()
                    batch_df = task["df"]
                    
                    for index, row in enumerate(result.rows):
                        for input_variable in (self.input_variables+add_variables):
                            setattr(
                                row,
                                input_variable,
                                batch_df[input_variable].iloc[index],
                            )
                    batch_generate_results.append(result)
                    
                except Exception as exc:
                    logger.error(f"Exception occurred when running the task: {exc}")
                    
                    rows = [
                        RowGenerateResult(is_successful=False, error_msg=str(exc))
                        for _ in range(len(prompts))
                    ]
                    
                    batch_generate_results.append(
                        BatchGenerateResult(
                            num_rows=len(prompts),
                            num_successful_rows=0,
                            rows=rows,
                            is_successful=False,
                            error_msg=str(exc),
                        )
                    )
                    raise exc
        logger.info(f"Generated total number of results: {len(batch_generate_results)}")

        num_rows = 0
        num_successful_rows = 0
        rows = []
        for batch_generate_result in batch_generate_results:
            num_rows += batch_generate_result.num_rows
            num_successful_rows += batch_generate_result.num_successful_rows
            rows.extend(batch_generate_result.rows)
        generate_result = GenerateResult(num_rows, num_successful_rows, rows)
        
        if self.output_filepath is not None:
            print(self.output_filepath)
            save_parquet_safe(generate_result.to_dataframe(), self.output_filepath, upsert=self.upsert)
        return generate_result


class BaseGPTGenerator(BaseModelGenerator):
    ALLOWED_MODEL_NAMES = ["gpt-4o","gpt-4", "gpt-3.5-turbo", "gpt-3.5-turbo-16k"]

    def __init__(
        self,
        prompt_formatter: PromptTemplate,
        azure_endpoint: str, 
        azure_api_key: str, 
        azure_deployment_name: str, 
        api_version: str,
        model_name: str,
        batch_size: int = 1,
        concurrency: int = 1,
        output_filepath : str = None, 
        upsert : bool = False,
    ) -> None:

        super().__init__(prompt_formatter, azure_endpoint, azure_api_key, azure_deployment_name, api_version, batch_size, concurrency,)
        if batch_size != 1:
            raise ValueError(
                "BaseGPTGenerator currently only supports batch size 1"
            )
        if model_name not in self.ALLOWED_MODEL_NAMES:
            raise ValueError(
                f"model_name {model_name} is not supported. Supported model names: {self.ALLOWED_MODEL_NAMES}"
            )
        self._model_name = model_name
        self.azure_endpoint =azure_endpoint
        self.azure_api_key = azure_api_key
        self.azure_deployment_name = azure_deployment_name
        self.api_version = api_version
        self.output_filepath = output_filepath
        self.upsert = upsert

    def _generate(
        self,
        prompts: list, 
        temperature: float,       
        max_tokens=256, 
        system_prompt=None
    ) -> BatchGenerateResult:
        if system_prompt is not None:
            messages = [
                {"role": "system", "content": system_prompt},
            ]
        else:
            messages = []

        user_prompt = prompts[0]
        messages.append({"role": "user", "content": user_prompt})

        response_message = base_model.request_azure(
            messages=messages,
            azure_endpoint = self.azure_endpoint, 
            azure_api_key= self.azure_api_key, 
            azure_deployment_name= self.azure_deployment_name, 
            api_version= self.api_version,
            functions=[],
            temperature=temperature,
            model=self._model_name,           
        )
        content = response_message["content"]
        logger.debug(f"Got response content: {content}")
        row_generate_result = RowGenerateResult(
            is_successful=True,
            error_msg=None,
            answer=content,
            temperature=temperature,
            max_tokens=max_tokens,
            model_name=self._model_name,
            prompt=user_prompt,
        )
        return BatchGenerateResult(
            num_rows=1,
            num_successful_rows=1,
            rows=[row_generate_result],
            is_successful=True,
            error_msg=None,
        )