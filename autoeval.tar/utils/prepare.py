import os
import pandas as pd
import numpy as np
from langchain.schema import Document
from langchain_openai import AzureOpenAIEmbeddings
from langchain_community.vectorstores import FAISS

import datetime
from typing import List, Callable, Any, Tuple, Optional, Union, Dict
from autoeval.evaluation.retrieval.retrieval_evaluation_util import cast_metrics

def create_embeddings(chunk_size=512):
    embeddings = AzureOpenAIEmbeddings(
        deployment="text-embedding-ada-002",
        model="text-embedding-ada-002",
        api_key="your-api-key",
        azure_endpoint="your-endpoint",
        api_version="your-api-version",
        max_retries = 10,
        chunk_size=chunk_size
        )
    return embeddings


def add_retrieval_information(db:FAISS, df:pd.DataFrame, retrieval_k:int):
    retrieval_context = {"retrieval_context":[], "retrieval_k":[], "cid":[], "scores":[]}
    assert 'query' in df.columns, "must 'query' in columns"
    
    for query in df['query']:
        docs_with_scores = db.similarity_search_with_score(query,k=retrieval_k)
        docs = [doc_with_score[0] for doc_with_score in docs_with_scores]
        scores = [doc_with_score[1] for doc_with_score in docs_with_scores]

        context = [doc.page_content for doc in docs]
        cid = [doc.metadata['doc_id'] for doc in docs]

        retrieval_context["retrieval_context"].append([context])
        retrieval_context['cid'].append(cid)
        retrieval_context['scores'].append(scores) 
        retrieval_context["retrieval_k"].append(retrieval_k)

    df_the_dict = pd.DataFrame.from_dict(retrieval_context)
    prepared_qa_df = pd.concat([df, df_the_dict], axis=1)
    return prepared_qa_df


def save_and_summary(save_dir, 
                     save_filename, 
                     result_df : pd.DataFrame, 
                     metrics:Union[List[str], List[Dict]],
                    ):

        if not os.path.exists(save_dir):
            os.makedirs(save_dir, exist_ok=True)
        result_filepath = os.path.join(save_dir,save_filename)
        summary_filepath = save_filename.split(".")[0]+"_summary.csv"
        metric_names, metric_params = cast_metrics(metrics)

        summary_df = pd.DataFrame({
            'filename': save_filename,
            'creation_time': datetime.datetime.now(),
            **{metric: [result_df[metric].mean()] for metric in metric_names},
        })
        
        result_df.to_csv(result_filepath, index=False)
        summary_df.to_csv(os.path.join(save_dir, summary_filepath), index=False)
        
        return summary_df
    

def generate_final_summary(summary_dir:str, 
                     summary_filenames:dict, 
                     generation_scale:int,
                     generation_weight:List[float] = [0.6, 0.2, 0.2],
                     score_weight : List[float] = None 
                    ):

        assert sum(score_weight)==1, "sum ofscore_weight must be 1"
        assert os.path.exists(summary_dir), "must exist summary_dir"
        assert len(summary_filenames.keys())==4, "Input keys must have 'retrieval', 'retrieval_contents', 'generation', 'generation_contents"
            
        for key, value in summary_filenames.items():
            if key == "retrieval":
                retrieval_df = pd.read_csv(os.path.join(summary_dir,value))
            elif key == "retrieval_contents":
                retrieval_contents_df = pd.read_csv(os.path.join(summary_dir,value))
            elif key == "generation":
                generation_df = pd.read_csv(os.path.join(summary_dir,value))
            elif key == "generation_contents":
                generation_contents_df = pd.read_csv(os.path.join(summary_dir,value))
            else:
                raise ValueError(
                    f"Invalid key '{key}'. Input keys have 'retrieval', 'retrieval_contents', 'generation', 'generation_contents'"
                )
        
        retrieval_metrics= ['retrieval_recall', 'retrieval_precision', 'retrieval_f1', "retrieval_ndcg", "retrieval_mrr", "retrieval_map"]
        retrieval_contents_metrics=['retrieval_token_recall', 'retrieval_token_precision', 'retrieval_token_f1']
        generation_metrics = ["bleu","meteor","rouge","sem_score"]    
        generation_contents_metrics = ["accuracy","completeness","clarity"] 
        
        retrieval_metrics = [metric for metric in retrieval_metrics if metric in retrieval_df.columns]
        retrieval_contents_metrics = [metric for metric in retrieval_contents_metrics if metric in retrieval_contents_df.columns]
        generation_metrics = [metric for metric in generation_metrics if metric in generation_df.columns]
        generation_contents_metrics = [metric for metric in generation_contents_metrics if metric in generation_contents_df.columns]
        
        assert generation_contents_metrics == ["accuracy","completeness","clarity"], 'must be generation_contents_metrics == ["accuracy","completeness","clarity"]'
        
        filtered_retrieval = retrieval_df[retrieval_metrics].sum(axis=1) / len(retrieval_df[retrieval_metrics].keys())
        filtered_retrieval_contents = retrieval_contents_df[retrieval_contents_metrics].sum(axis=1) / len(retrieval_contents_df[retrieval_contents_metrics].keys())
        
        filtered_generation = generation_df[generation_metrics].sum(axis=1) / len(generation_df[generation_metrics].keys())
        standardized_generation_contents = generation_contents_df[generation_contents_metrics] / generation_scale
        filtered_generation_contents = pd.DataFrame([np.dot(standardized_generation_contents.values, generation_weight)])
        
        
        
        index_df = pd.DataFrame({
            'filename': ["Overall_summary"],
            'creation_time': [datetime.datetime.now()],
            'metrics' : [[retrieval_df[retrieval_metrics].columns, 
                         retrieval_contents_df[retrieval_contents_metrics].columns, 
                         generation_df[generation_metrics].columns,
                          generation_contents_df[generation_contents_metrics].columns]]
        
        })
        
        concat_df = pd.concat([index_df, 
                                   filtered_retrieval,
                                   filtered_retrieval_contents, 
                                   filtered_generation,
                               filtered_generation_contents], axis=1)
            
        concat_df.columns=['filename', 'creation_time', 'metrics', 'retrieval_score', 'retrieval_contents_score','generation_score','generation_contents_score']
        
        def total_score(df):
            
            if score_weight:
                score = df["retrieval_score"]*score_weight[0] + df["retrieval_contents_score"]*score_weight[1] + df["generation_score"]*score_weight[2] + df["generation_contents_score"]*score_weight[3]                 
                return score
            else:
                sum_score = df["retrieval_score"] + df["retrieval_contents_score"] + df["generation_score"] + df["generation_contents_score"]             
                return total_score

        concat_df['overall_score'] = concat_df.apply(lambda x : total_score(x), axis=1)
        concat_df = concat_df.apply(lambda x : round(x,3))
        
        assert concat_df["generation_score"][0] <= 1, "generation_score must be less than 1"
        
        concat_df.to_csv(os.path.join(summary_dir, f"overall_score_{datetime.datetime.now().strftime('%Y-%m-%d_%H_%M_S')}.csv"), index=False)        
        return concat_df