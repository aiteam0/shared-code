import logging
import logging.config
import os
import sys

import transformers
from llama_index.core.llms.mock import MockLLM
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.embeddings.openai import OpenAIEmbedding

from llama_index.embeddings.azure_openai import AzureOpenAIEmbedding
from llama_index.embeddings.openai import OpenAIEmbeddingModelType
from llama_index.llms.huggingface import HuggingFaceLLM
from llama_index.llms.openai import OpenAI
from llama_index.llms.azure_openai import AzureOpenAI
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai_like import OpenAILike
from rich.logging import RichHandler


class LazyInit:
    def __init__(self, factory, *args, **kwargs):
        self._factory = factory
        self._args = args
        self._kwargs = kwargs
        self._instance = None

    def __call__(self):
        if self._instance is None:
            self._instance = self._factory(*self._args, **self._kwargs)
        return self._instance

    def __getattr__(self, name):
        if self._instance is None:
            self._instance = self._factory(*self._args, **self._kwargs)
        return getattr(self._instance, name)


embedding_models = {
    'openai': LazyInit(AzureOpenAIEmbedding, model_name=OpenAIEmbeddingModelType.TEXT_EMBED_3_LARGE,
                       model="text-embedding-ada-002",
                        deployment_name="text-embedding-ada-002",
                        api_key="your-api-key",
                        azure_endpoint="your-endpoint",
                        api_version="your-api-version",), 
    'openai_embed_3_large': LazyInit(AzureOpenAIEmbedding, model_name=OpenAIEmbeddingModelType.TEXT_EMBED_3_LARGE),
    'openai_embed_3_small': LazyInit(AzureOpenAIEmbedding, model_name=OpenAIEmbeddingModelType.TEXT_EMBED_3_SMALL),
    'huggingface_baai_bge_small': LazyInit(HuggingFaceEmbedding, model_name="BAAI/bge-small-en-v1.5"),
    'huggingface_cointegrated_rubert_tiny2': LazyInit(HuggingFaceEmbedding, model_name="cointegrated/rubert-tiny2"),
    'huggingface_all_mpnet_base_v2': LazyInit(HuggingFaceEmbedding,
                                              model_name="sentence-transformers/all-mpnet-base-v2",
                                              max_length=512, )
}

generator_models = {
    'openai': AzureOpenAI,
    'huggingfacellm': HuggingFaceLLM,
    'openailike': OpenAILike,
    'ollama': Ollama,
    'mock': MockLLM,
}

rich_format = "[%(filename)s:%(lineno)s] >> %(message)s"
logging.basicConfig(
    level="INFO",
    format=rich_format,
    handlers=[RichHandler(rich_tracebacks=True)]
)
logger = logging.getLogger("AutoEval")


def handle_exception(exc_type, exc_value, exc_traceback):
    logger = logging.getLogger("AutoEval")
    logger.error("Unexpected exception",
                 exc_info=(exc_type, exc_value, exc_traceback))


sys.excepthook = handle_exception

transformers.logging.set_verbosity_error()